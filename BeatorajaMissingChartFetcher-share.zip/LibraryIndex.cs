using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace BeatorajaMissingChartFetcher
{
    public sealed class LibraryChartRecord
    {
        public string Path { get; set; }
        public string Directory { get; set; }
        public long Length { get; set; }
        public long LastWriteTicks { get; set; }
        public string MD5 { get; set; }
        public string SHA256 { get; set; }
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public string Artist { get; set; }
        public string Genre { get; set; }
    }

    public sealed class LibraryBuildResult
    {
        public long FileCount { get; set; }
        public int ChartCount { get; set; }
        public int FolderCount { get; set; }
        public int ReusedChartCount { get; set; }
        public int HashedChartCount { get; set; }
        public double ElapsedSeconds { get; set; }
        public string IndexDirectory { get; set; }
    }

    public sealed class LibraryFolderCandidate
    {
        public string Path { get; set; }
        public int Hits { get; set; }
    }

    internal struct ResourceRecord
    {
        public ulong Hash;
        public int FolderId;
    }

    internal sealed class ResourceRecordComparer : IComparer<ResourceRecord>
    {
        public int Compare(ResourceRecord x, ResourceRecord y)
        {
            int hash = x.Hash.CompareTo(y.Hash);
            return hash != 0 ? hash : x.FolderId.CompareTo(y.FolderId);
        }
    }

    public static class LibraryIndex
    {
        public const int Version = 1;
        private static readonly string[] ChartExtensions = { ".bms", ".bme", ".bml", ".pms", ".bmson" };

        public static LibraryBuildResult Build(string[] roots, string indexDirectory, Action<string, int, int> progress)
        {
            return Build(roots, indexDirectory, progress, true);
        }

        public static LibraryBuildResult Build(string[] roots, string indexDirectory, Action<string, int, int> progress, bool reuseUnchangedCharts)
        {
            Stopwatch timer = Stopwatch.StartNew();
            string[] validRoots = roots.Where(Directory.Exists)
                .Select(p => Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar))
                .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (validRoots.Length == 0) throw new InvalidOperationException("登録されたBMSフォルダが見つかりません。");

            Dictionary<string, LibraryChartRecord> oldCharts = reuseUnchangedCharts ? LoadChartMap(indexDirectory) : new Dictionary<string, LibraryChartRecord>(StringComparer.OrdinalIgnoreCase);
            string parent = Path.GetDirectoryName(indexDirectory.TrimEnd(Path.DirectorySeparatorChar));
            if (String.IsNullOrEmpty(parent)) parent = Directory.GetCurrentDirectory();
            Directory.CreateDirectory(parent);
            string temp = Path.Combine(parent, Path.GetFileName(indexDirectory) + ".new-" + Guid.NewGuid().ToString("N"));
            string backup = null;
            Directory.CreateDirectory(temp);

            try
            {
                List<string> chartPaths = EnumerateChartFiles(validRoots).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                HashSet<string> chartDirectories = new HashSet<string>(chartPaths.Select(Path.GetDirectoryName), StringComparer.OrdinalIgnoreCase);
                string[] folders = chartDirectories.OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToArray();
                Dictionary<string, int> folderIds = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < folders.Length; i++) folderIds[folders[i]] = i;

                int reused = 0;
                int hashed = 0;
                List<LibraryChartRecord> charts = new List<LibraryChartRecord>(chartPaths.Count);
                for (int i = 0; i < chartPaths.Count; i++)
                {
                    string path = chartPaths[i];
                    FileInfo info = new FileInfo(path);
                    LibraryChartRecord record;
                    LibraryChartRecord old;
                    if (oldCharts.TryGetValue(path, out old) && old.Length == info.Length && old.LastWriteTicks == info.LastWriteTimeUtc.Ticks)
                    {
                        record = old;
                        reused++;
                    }
                    else
                    {
                        record = ReadChart(info);
                        hashed++;
                    }
                    charts.Add(record);
                    if (progress != null && (i == 0 || (i + 1) % 100 == 0 || i + 1 == chartPaths.Count))
                        progress("譜面のハッシュと情報を確認中", i + 1, chartPaths.Count);
                }

                WriteCharts(Path.Combine(temp, "charts.tsv"), charts);
                WriteBase64Lines(Path.Combine(temp, "folders.txt"), folders);
                WriteBase64Lines(Path.Combine(temp, "roots.txt"), validRoots);
                File.WriteAllText(Path.Combine(temp, "version.txt"), Version.ToString(), new UTF8Encoding(false));

                Dictionary<string, string> parentCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                List<ResourceRecord> resources = new List<ResourceRecord>(Math.Max(1024, chartPaths.Count * 32));
                long fileCount = 0;
                foreach (string root in validRoots)
                {
                    foreach (string path in EnumerateFilesSafe(root, "*"))
                    {
                        fileCount++;
                        string immediate = Path.GetDirectoryName(path);
                        string songFolder = FindChartAncestor(immediate, root, chartDirectories, parentCache);
                        int folderId;
                        if (songFolder != null && folderIds.TryGetValue(songFolder, out folderId))
                        {
                            string stem = Path.GetFileNameWithoutExtension(path);
                            if (!String.IsNullOrEmpty(stem)) resources.Add(new ResourceRecord { Hash = HashStem(stem), FolderId = folderId });
                        }
                        if (progress != null && (fileCount == 1 || fileCount % 20000 == 0))
                            progress("音声・画像の配置索引を作成中", (int)Math.Min(Int32.MaxValue, fileCount), 0);
                    }
                }

                resources.Sort(new ResourceRecordComparer());
                using (BinaryWriter writer = new BinaryWriter(File.Create(Path.Combine(temp, "resources.bin"))))
                {
                    ulong previousHash = 0;
                    int previousFolder = -1;
                    bool hasPrevious = false;
                    foreach (ResourceRecord record in resources)
                    {
                        if (hasPrevious && record.Hash == previousHash && record.FolderId == previousFolder) continue;
                        writer.Write(record.Hash);
                        writer.Write(record.FolderId);
                        previousHash = record.Hash;
                        previousFolder = record.FolderId;
                        hasPrevious = true;
                    }
                }

                backup = indexDirectory + ".old-" + Guid.NewGuid().ToString("N");
                if (Directory.Exists(indexDirectory)) Directory.Move(indexDirectory, backup);
                try { Directory.Move(temp, indexDirectory); }
                catch
                {
                    if (!Directory.Exists(indexDirectory) && Directory.Exists(backup)) Directory.Move(backup, indexDirectory);
                    throw;
                }
                if (Directory.Exists(backup)) Directory.Delete(backup, true);
                backup = null;

                timer.Stop();
                return new LibraryBuildResult
                {
                    FileCount = fileCount,
                    ChartCount = charts.Count,
                    FolderCount = folders.Length,
                    ReusedChartCount = reused,
                    HashedChartCount = hashed,
                    ElapsedSeconds = timer.Elapsed.TotalSeconds,
                    IndexDirectory = indexDirectory
                };
            }
            catch
            {
                if (Directory.Exists(temp)) Directory.Delete(temp, true);
                if (!String.IsNullOrEmpty(backup) && !Directory.Exists(indexDirectory) && Directory.Exists(backup)) Directory.Move(backup, indexDirectory);
                throw;
            }
        }

        public static LibraryChartRecord[] LoadCharts(string indexDirectory)
        {
            return LoadChartMap(indexDirectory).Values.ToArray();
        }

        public static string[] LoadRoots(string indexDirectory)
        {
            string path = Path.Combine(indexDirectory, "roots.txt");
            if (!File.Exists(path)) return new string[0];
            return ReadBase64Lines(path).ToArray();
        }

        public static bool IsUsable(string indexDirectory, string[] roots)
        {
            if (!File.Exists(Path.Combine(indexDirectory, "resources.bin")) || !File.Exists(Path.Combine(indexDirectory, "charts.tsv"))) return false;
            string versionPath = Path.Combine(indexDirectory, "version.txt");
            int version;
            if (!File.Exists(versionPath) || !Int32.TryParse(File.ReadAllText(versionPath).Trim(), out version) || version != Version) return false;
            string[] saved = LoadRoots(indexDirectory).Select(NormalizePath).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToArray();
            string[] requested = (roots ?? new string[0]).Where(p => !String.IsNullOrWhiteSpace(p)).Select(NormalizePath).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToArray();
            return saved.SequenceEqual(requested, StringComparer.OrdinalIgnoreCase);
        }

        public static LibraryFolderCandidate[] FindCandidates(string indexDirectory, string[] references, int maximum)
        {
            string resourcePath = Path.Combine(indexDirectory, "resources.bin");
            string folderPath = Path.Combine(indexDirectory, "folders.txt");
            if (!File.Exists(resourcePath) || !File.Exists(folderPath)) return new LibraryFolderCandidate[0];
            string[] folders = ReadBase64Lines(folderPath).ToArray();
            Dictionary<int, int> hits = new Dictionary<int, int>();
            HashSet<ulong> wanted = new HashSet<ulong>();
            foreach (string reference in references ?? new string[0])
            {
                string stem = Path.GetFileNameWithoutExtension(reference);
                if (!String.IsNullOrEmpty(stem)) wanted.Add(HashStem(stem));
            }
            using (FileStream stream = new FileStream(resourcePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (BinaryReader reader = new BinaryReader(stream))
            {
                long count = stream.Length / 12L;
                foreach (ulong hash in wanted)
                {
                    long first = FindFirst(reader, count, hash);
                    if (first < 0) continue;
                    stream.Position = first * 12L;
                    while (stream.Position < stream.Length)
                    {
                        ulong foundHash = reader.ReadUInt64();
                        int folderId = reader.ReadInt32();
                        if (foundHash != hash) break;
                        int value;
                        hits[folderId] = hits.TryGetValue(folderId, out value) ? value + 1 : 1;
                    }
                }
            }
            return hits.Where(p => p.Key >= 0 && p.Key < folders.Length)
                .OrderByDescending(p => p.Value).ThenBy(p => folders[p.Key], StringComparer.OrdinalIgnoreCase)
                .Take(Math.Max(1, maximum))
                .Select(p => new LibraryFolderCandidate { Path = folders[p.Key], Hits = p.Value }).ToArray();
        }

        private static long FindFirst(BinaryReader reader, long count, ulong wanted)
        {
            long low = 0, high = count - 1, found = -1;
            while (low <= high)
            {
                long mid = low + ((high - low) / 2);
                reader.BaseStream.Position = mid * 12L;
                ulong hash = reader.ReadUInt64();
                reader.ReadInt32();
                if (hash < wanted) low = mid + 1;
                else { if (hash == wanted) found = mid; high = mid - 1; }
            }
            return found;
        }

        private static string FindChartAncestor(string directory, string root, HashSet<string> chartDirectories, Dictionary<string, string> cache)
        {
            string cached;
            if (cache.TryGetValue(directory, out cached)) return cached.Length == 0 ? null : cached;
            List<string> visited = new List<string>();
            string current = directory;
            string result = null;
            while (!String.IsNullOrEmpty(current) && current.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            {
                visited.Add(current);
                if (chartDirectories.Contains(current)) { result = current; break; }
                string next = Path.GetDirectoryName(current);
                if (String.Equals(next, current, StringComparison.OrdinalIgnoreCase)) break;
                current = next;
            }
            foreach (string item in visited) cache[item] = result ?? String.Empty;
            return result;
        }

        private static IEnumerable<string> EnumerateChartFiles(string[] roots)
        {
            foreach (string root in roots)
                foreach (string extension in ChartExtensions)
                    foreach (string path in EnumerateFilesSafe(root, "*" + extension))
                        yield return path;
        }

        private static IEnumerable<string> EnumerateFilesSafe(string root, string pattern)
        {
            Stack<string> pending = new Stack<string>();
            pending.Push(root);
            while (pending.Count > 0)
            {
                string directory = pending.Pop();
                string[] files;
                try { files = Directory.GetFiles(directory, pattern, SearchOption.TopDirectoryOnly); }
                catch { files = new string[0]; }
                foreach (string file in files) yield return file;
                string[] children;
                try { children = Directory.GetDirectories(directory, "*", SearchOption.TopDirectoryOnly); }
                catch { children = new string[0]; }
                foreach (string child in children)
                {
                    try
                    {
                        if ((File.GetAttributes(child) & FileAttributes.ReparsePoint) != 0) continue;
                        pending.Push(child);
                    }
                    catch { }
                }
            }
        }

        private static LibraryChartRecord ReadChart(FileInfo info)
        {
            byte[] bytes = File.ReadAllBytes(info.FullName);
            string md5, sha;
            using (MD5 algorithm = MD5.Create()) md5 = ToHex(algorithm.ComputeHash(bytes));
            using (SHA256 algorithm = SHA256.Create()) sha = ToHex(algorithm.ComputeHash(bytes));
            string text = DecodeChart(bytes);
            return new LibraryChartRecord
            {
                Path = info.FullName,
                Directory = info.DirectoryName,
                Length = info.Length,
                LastWriteTicks = info.LastWriteTimeUtc.Ticks,
                MD5 = md5,
                SHA256 = sha,
                Title = ReadField(text, "TITLE"),
                Subtitle = ReadField(text, "SUBTITLE"),
                Artist = ReadField(text, "ARTIST"),
                Genre = ReadField(text, "GENRE")
            };
        }

        private static string DecodeChart(byte[] bytes)
        {
            if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF) return Encoding.UTF8.GetString(bytes);
            string utf8 = Encoding.UTF8.GetString(bytes);
            if (Regex.IsMatch(utf8, @"(?im)^\s*#TITLE\s+")) return utf8;
            try { return Encoding.GetEncoding(932).GetString(bytes); }
            catch { return utf8; }
        }

        private static string ReadField(string text, string name)
        {
            Match bms = Regex.Match(text, @"(?im)^\s*#" + Regex.Escape(name) + @"\s+(.+?)\s*$", RegexOptions.CultureInvariant);
            if (bms.Success) return bms.Groups[1].Value.Trim();
            Match json = Regex.Match(text, "\\\"" + name.ToLowerInvariant() + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"", RegexOptions.IgnoreCase);
            return json.Success ? json.Groups[1].Value : String.Empty;
        }

        private static string ToHex(byte[] bytes)
        {
            StringBuilder builder = new StringBuilder(bytes.Length * 2);
            foreach (byte value in bytes) builder.Append(value.ToString("x2"));
            return builder.ToString();
        }

        private static ulong HashStem(string stem)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(stem.ToLowerInvariant());
            ulong hash = 14695981039346656037UL;
            foreach (byte value in bytes) { hash ^= value; hash *= 1099511628211UL; }
            return hash;
        }

        private static string NormalizePath(string path)
        {
            return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar).ToLowerInvariant();
        }

        private static string Encode(string value)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(value ?? String.Empty));
        }

        private static string Decode(string value)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(value));
        }

        private static void WriteBase64Lines(string path, IEnumerable<string> values)
        {
            File.WriteAllLines(path, values.Select(Encode), new UTF8Encoding(false));
        }

        private static IEnumerable<string> ReadBase64Lines(string path)
        {
            foreach (string line in File.ReadLines(path, Encoding.UTF8))
                if (!String.IsNullOrWhiteSpace(line)) yield return Decode(line.Trim());
        }

        private static void WriteCharts(string path, IEnumerable<LibraryChartRecord> charts)
        {
            using (StreamWriter writer = new StreamWriter(path, false, new UTF8Encoding(false)))
            {
                foreach (LibraryChartRecord item in charts)
                {
                    writer.WriteLine(String.Join("\t", new[] {
                        Encode(item.Path), Encode(item.Directory), item.Length.ToString(), item.LastWriteTicks.ToString(),
                        item.MD5, item.SHA256, Encode(item.Title), Encode(item.Subtitle), Encode(item.Artist), Encode(item.Genre)
                    }));
                }
            }
        }

        private static Dictionary<string, LibraryChartRecord> LoadChartMap(string indexDirectory)
        {
            Dictionary<string, LibraryChartRecord> result = new Dictionary<string, LibraryChartRecord>(StringComparer.OrdinalIgnoreCase);
            string path = Path.Combine(indexDirectory, "charts.tsv");
            if (!File.Exists(path)) return result;
            foreach (string line in File.ReadLines(path, Encoding.UTF8))
            {
                string[] fields = line.Split('\t');
                long length, ticks;
                if (fields.Length < 10 || !Int64.TryParse(fields[2], out length) || !Int64.TryParse(fields[3], out ticks)) continue;
                try
                {
                    LibraryChartRecord record = new LibraryChartRecord {
                        Path=Decode(fields[0]), Directory=Decode(fields[1]), Length=length, LastWriteTicks=ticks,
                        MD5=fields[4], SHA256=fields[5], Title=Decode(fields[6]), Subtitle=Decode(fields[7]), Artist=Decode(fields[8]), Genre=Decode(fields[9])
                    };
                    result[record.Path] = record;
                }
                catch { }
            }
            return result;
        }
    }
}
