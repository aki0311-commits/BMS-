using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace BeatorajaMissingChartFetcher
{
    public sealed class SongRecord
    {
        public string Md5 { get; set; }
        public string Sha256 { get; set; }
        public string Path { get; set; }
    }

    // Minimal, read-only SQLite table reader. It intentionally implements only
    // the on-disk features needed to read beatoraja's ordinary `song` table.
    public static class SongDatabaseReader
    {
        private sealed class Database
        {
            public byte[] Bytes;
            public int PageSize;
            public int UsableSize;
            public Encoding TextEncoding;
        }

        public static List<SongRecord> Read(string databasePath)
        {
            if (String.IsNullOrWhiteSpace(databasePath) || !File.Exists(databasePath))
                throw new FileNotFoundException("songdata.db が見つかりません。", databasePath);

            var walPath = databasePath + "-wal";
            if (File.Exists(walPath) && new FileInfo(walPath).Length > 0)
                throw new InvalidOperationException("beatorajaがsongdata.dbを使用中です。beatorajaを終了してから、もう一度調べてください。");

            byte[] bytes;
            using (var stream = new FileStream(databasePath, FileMode.Open, FileAccess.Read,
                                                FileShare.ReadWrite | FileShare.Delete))
            using (var memory = new MemoryStream())
            {
                stream.CopyTo(memory);
                bytes = memory.ToArray();
            }

            if (bytes.Length < 100 || Encoding.ASCII.GetString(bytes, 0, 16) != "SQLite format 3\0")
                throw new InvalidDataException("songdata.dbがSQLiteデータベースではありません。");

            int pageSize = ReadUInt16(bytes, 16);
            if (pageSize == 1) pageSize = 65536;
            int reserved = bytes[20];
            int encodingId = (int)ReadUInt32(bytes, 56);
            Encoding encoding = encodingId == 2 ? Encoding.Unicode :
                                encodingId == 3 ? Encoding.BigEndianUnicode : Encoding.UTF8;
            var db = new Database {
                Bytes = bytes,
                PageSize = pageSize,
                UsableSize = pageSize - reserved,
                TextEncoding = encoding
            };

            var masterRows = ReadTableRows(db, 1);
            int songRootPage = 0;
            string createSql = null;
            foreach (var row in masterRows)
            {
                if (row.Count < 5) continue;
                if (AsText(row[0]) == "table" && AsText(row[1]) == "song")
                {
                    songRootPage = Convert.ToInt32(row[3]);
                    createSql = AsText(row[4]);
                    break;
                }
            }
            if (songRootPage <= 0) throw new InvalidDataException("songdata.dbにsongテーブルがありません。");

            var columns = ParseColumnNames(createSql);
            int md5Index = IndexOf(columns, "md5");
            int shaIndex = IndexOf(columns, "sha256");
            int pathIndex = IndexOf(columns, "path");
            if (md5Index < 0 || shaIndex < 0 || pathIndex < 0)
                throw new InvalidDataException("songテーブルのmd5・sha256・path列を確認できません。");

            var result = new List<SongRecord>();
            foreach (var row in ReadTableRows(db, songRootPage))
            {
                if (row.Count <= Math.Max(pathIndex, Math.Max(md5Index, shaIndex))) continue;
                var md5 = AsText(row[md5Index]).Trim().ToLowerInvariant();
                var sha256 = AsText(row[shaIndex]).Trim().ToLowerInvariant();
                var path = AsText(row[pathIndex]);
                if (md5.Length == 0 && sha256.Length == 0) continue;
                result.Add(new SongRecord { Md5 = md5, Sha256 = sha256, Path = path });
            }
            return result;
        }

        private static List<string> ParseColumnNames(string sql)
        {
            var names = new List<string>();
            if (String.IsNullOrWhiteSpace(sql)) return names;
            int open = sql.IndexOf('('), close = sql.LastIndexOf(')');
            if (open < 0 || close <= open) return names;
            string body = sql.Substring(open + 1, close - open - 1);
            foreach (Match match in Regex.Matches(body,
                @"(?:^|,)\s*(?:\[(?<bracket>[^\]]+)\]|""(?<quote>[^""]+)""|`(?<tick>[^`]+)`|(?<plain>[A-Za-z_][A-Za-z0-9_]*))"))
            {
                string name = match.Groups["bracket"].Success ? match.Groups["bracket"].Value :
                              match.Groups["quote"].Success ? match.Groups["quote"].Value :
                              match.Groups["tick"].Success ? match.Groups["tick"].Value :
                              match.Groups["plain"].Value;
                string upper = name.ToUpperInvariant();
                if (upper == "PRIMARY" || upper == "UNIQUE" || upper == "CONSTRAINT" || upper == "CHECK" || upper == "FOREIGN")
                    continue;
                names.Add(name);
            }
            return names;
        }

        private static int IndexOf(List<string> values, string name)
        {
            for (int i = 0; i < values.Count; i++)
                if (String.Equals(values[i], name, StringComparison.OrdinalIgnoreCase)) return i;
            return -1;
        }

        private static List<List<object>> ReadTableRows(Database db, int rootPage)
        {
            var rows = new List<List<object>>();
            var pending = new Stack<int>();
            var seen = new HashSet<int>();
            pending.Push(rootPage);
            while (pending.Count > 0)
            {
                int pageNumber = pending.Pop();
                if (pageNumber <= 0 || !seen.Add(pageNumber)) continue;
                int pageOffset = checked((pageNumber - 1) * db.PageSize);
                if (pageOffset < 0 || pageOffset >= db.Bytes.Length) throw new InvalidDataException("SQLiteページ番号が範囲外です。");
                int headerOffset = pageNumber == 1 ? 100 : 0;
                int header = pageOffset + headerOffset;
                byte pageType = db.Bytes[header];
                int cellCount = ReadUInt16(db.Bytes, header + 3);

                if (pageType == 0x05) // interior table b-tree page
                {
                    uint rightMost = ReadUInt32(db.Bytes, header + 8);
                    pending.Push((int)rightMost);
                    int pointerArray = header + 12;
                    for (int i = cellCount - 1; i >= 0; i--)
                    {
                        int cellOffset = ReadUInt16(db.Bytes, pointerArray + i * 2);
                        int child = (int)ReadUInt32(db.Bytes, pageOffset + cellOffset);
                        pending.Push(child);
                    }
                }
                else if (pageType == 0x0D) // leaf table b-tree page
                {
                    int pointerArray = header + 8;
                    for (int i = 0; i < cellCount; i++)
                    {
                        int cellOffset = ReadUInt16(db.Bytes, pointerArray + i * 2);
                        int position = pageOffset + cellOffset;
                        ulong payloadLengthValue = ReadVarint(db.Bytes, ref position);
                        ReadVarint(db.Bytes, ref position); // rowid
                        if (payloadLengthValue > Int32.MaxValue) throw new InvalidDataException("SQLiteレコードが大きすぎます。");
                        byte[] payload = ReadPayload(db, position, (int)payloadLengthValue);
                        rows.Add(ReadRecord(db, payload));
                    }
                }
                else
                {
                    throw new InvalidDataException("対応していないSQLiteテーブルページです: " + pageType.ToString("X2"));
                }
            }
            return rows;
        }

        private static byte[] ReadPayload(Database db, int start, int payloadLength)
        {
            int local = LocalPayloadSize(db.UsableSize, payloadLength);
            var output = new byte[payloadLength];
            Buffer.BlockCopy(db.Bytes, start, output, 0, local);
            int written = local;
            if (written >= payloadLength) return output;

            int overflowPage = (int)ReadUInt32(db.Bytes, start + local);
            var visited = new HashSet<int>();
            while (written < payloadLength)
            {
                if (overflowPage <= 0 || !visited.Add(overflowPage)) throw new InvalidDataException("SQLiteオーバーフローページが壊れています。");
                int pageOffset = checked((overflowPage - 1) * db.PageSize);
                int nextPage = (int)ReadUInt32(db.Bytes, pageOffset);
                int count = Math.Min(payloadLength - written, db.UsableSize - 4);
                Buffer.BlockCopy(db.Bytes, pageOffset + 4, output, written, count);
                written += count;
                overflowPage = nextPage;
            }
            return output;
        }

        private static int LocalPayloadSize(int usableSize, int payloadLength)
        {
            int maxLocal = usableSize - 35;
            if (payloadLength <= maxLocal) return payloadLength;
            int minLocal = ((usableSize - 12) * 32 / 255) - 23;
            int candidate = minLocal + ((payloadLength - minLocal) % (usableSize - 4));
            return candidate <= maxLocal ? candidate : minLocal;
        }

        private static List<object> ReadRecord(Database db, byte[] payload)
        {
            int position = 0;
            int headerSize = checked((int)ReadVarint(payload, ref position));
            var serialTypes = new List<ulong>();
            while (position < headerSize) serialTypes.Add(ReadVarint(payload, ref position));
            int dataPosition = headerSize;
            var values = new List<object>();
            foreach (ulong serialType in serialTypes)
                values.Add(ReadSerialValue(db, payload, ref dataPosition, serialType));
            return values;
        }

        private static object ReadSerialValue(Database db, byte[] payload, ref int position, ulong serialType)
        {
            if (serialType == 0) return null;
            if (serialType >= 1 && serialType <= 6)
            {
                int[] lengths = { 0, 1, 2, 3, 4, 6, 8 };
                int length = lengths[(int)serialType];
                long value = ReadSignedInteger(payload, position, length);
                position += length;
                return value;
            }
            if (serialType == 7)
            {
                byte[] number = new byte[8];
                Buffer.BlockCopy(payload, position, number, 0, 8);
                if (BitConverter.IsLittleEndian) Array.Reverse(number);
                position += 8;
                return BitConverter.ToDouble(number, 0);
            }
            if (serialType == 8) return 0L;
            if (serialType == 9) return 1L;
            if (serialType == 10 || serialType == 11) return null;

            int lengthValue = checked((int)((serialType % 2 == 0 ? serialType - 12 : serialType - 13) / 2));
            byte[] valueBytes = new byte[lengthValue];
            Buffer.BlockCopy(payload, position, valueBytes, 0, lengthValue);
            position += lengthValue;
            if (serialType % 2 == 0) return valueBytes;
            return db.TextEncoding.GetString(valueBytes);
        }

        private static long ReadSignedInteger(byte[] bytes, int offset, int length)
        {
            ulong value = 0;
            for (int i = 0; i < length; i++) value = (value << 8) | bytes[offset + i];
            if (length < 8 && length > 0 && (bytes[offset] & 0x80) != 0)
                value |= UInt64.MaxValue << (length * 8);
            return unchecked((long)value);
        }

        private static ulong ReadVarint(byte[] bytes, ref int position)
        {
            ulong value = 0;
            for (int i = 0; i < 8; i++)
            {
                byte current = bytes[position++];
                value = (value << 7) | ((ulong)current & 0x7FUL);
                if ((current & 0x80) == 0) return value;
            }
            value = (value << 8) | bytes[position++];
            return value;
        }

        private static int ReadUInt16(byte[] bytes, int offset)
        {
            return (bytes[offset] << 8) | bytes[offset + 1];
        }

        private static uint ReadUInt32(byte[] bytes, int offset)
        {
            return ((uint)bytes[offset] << 24) | ((uint)bytes[offset + 1] << 16) |
                   ((uint)bytes[offset + 2] << 8) | bytes[offset + 3];
        }

        private static string AsText(object value)
        {
            return value == null ? String.Empty : Convert.ToString(value);
        }
    }
}
