﻿$ErrorActionPreference = 'Stop'

try {
    & (Join-Path $PSScriptRoot 'BeatorajaMissingChartFetcher.ps1')
}
catch {
    $dataDirectory = Join-Path $PSScriptRoot 'data'
    [System.IO.Directory]::CreateDirectory($dataDirectory) | Out-Null
    $logPath = Join-Path $dataDirectory 'startup-error.log'
    $details = $_ | Out-String
    [System.IO.File]::WriteAllText($logPath, $details, [System.Text.UTF8Encoding]::new($true))

    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show(
        "アプリを起動できませんでした。`r`n`r`n$($_.Exception.Message)`r`n`r`n詳細: $logPath",
        'BMS 未所持譜面チェッカー・導入支援ツール',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}
