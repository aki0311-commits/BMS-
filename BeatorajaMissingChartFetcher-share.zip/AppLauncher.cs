using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class AppLauncher
{
    [STAThread]
    private static void Main()
    {
        try
        {
            string appFolder = AppDomain.CurrentDomain.BaseDirectory;
            string launcher = Path.Combine(appFolder, "Launcher.ps1");
            if (!File.Exists(launcher))
                throw new FileNotFoundException("Launcher.ps1 が見つかりません。ZIP内のファイルをすべて同じフォルダへ展開してください。", launcher);

            string windowsPowerShell = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System),
                @"WindowsPowerShell\v1.0\powershell.exe");
            if (!File.Exists(windowsPowerShell)) windowsPowerShell = "powershell.exe";

            var startInfo = new ProcessStartInfo
            {
                FileName = windowsPowerShell,
                Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -File \"" + launcher + "\"",
                WorkingDirectory = appFolder,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            Process.Start(startInfo);
        }
        catch (Exception error)
        {
            MessageBox.Show(
                "アプリを起動できませんでした。\r\n\r\n" + error.Message,
                "BMS 未所持譜面チェッカー・導入支援ツール",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
