﻿param(
    [switch]$SelfTest,
    [string]$DatabaseTestPath = '',
    [string]$TableTestUrl = '',
    [switch]$LibraryOnly,
    [switch]$UiSmokeTest,
    [string]$UiTestBeatorajaPath = '',
    [string]$UiTestMusicPath = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:DataDir = Join-Path $script:AppDir 'data'
$script:SettingsPath = Join-Path $script:DataDir 'settings.json'
$script:CachePath = Join-Path $script:DataDir 'local-hashes.json'
$script:DownloadDir = Join-Path $script:DataDir 'downloads'
$script:InboxDir = Join-Path $script:DataDir 'inbox'
$script:LogDir = Join-Path $script:DataDir 'logs'
$script:LogPath = Join-Path $script:LogDir 'latest.log'
$script:DownloadCachePath = Join-Path $script:DataDir 'download-cache.json'
$script:ChartIndexCachePath = Join-Path $script:DataDir 'chart-index-cache.json'
$script:BundledTableDir = Join-Path $script:AppDir 'table-cache'
$script:DatabaseReaderPath = Join-Path $script:AppDir 'SongDatabaseReader.cs'
$script:LibraryIndexReaderPath = Join-Path $script:AppDir 'LibraryIndex.cs'
$script:LibraryIndexDir = Join-Path $script:DataDir 'library-index'
$script:Md5UrlMapPath = Join-Path $script:DataDir 'bms-md5-url-map.tsv'
$script:SourceUrlCachePath = Join-Path $script:DataDir 'source-url-cache.json'
$script:PartialInstallPath = Join-Path $script:DataDir 'partial-installs.json'
$script:ChartExtensions = @('.bms', '.bme', '.bml', '.pms', '.bmson')
$script:WebUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 BeatorajaMissingChartFetcher/1.0'
$script:LogTextBox = $null
$script:FolderFileCache = @{}
$script:DownloadCache = @{}
$script:LocalInstalledMD5 = @{}
$script:LocalInstalledSHA256 = @{}
$script:FailedDownloadPages = @{}
$script:FailedDownloadCandidates = @{}
$script:PerformanceTrace = $null
$script:CurrentMusicPath = ''
$script:CurrentLibraryIndex = $null
$script:SessionResourceFolders = @{}
$script:SessionIndexDirty = $false
$script:SessionIndexedFolders = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
$script:Md5UrlMap = $null
$script:SourceUrlCache = @{}
$script:PartialInstalls = @{}
$script:CancelRequested = $false
$script:OperationProgressCallback = $null
$script:CurrentOperationTitle = ''
$script:LevelValueByDisplay = @{}
$script:ExtractedPackageCache = @{}
$script:UiProgressBar = $null
$script:TableNameCache = @{}
$script:TableNameDetectedCallback = $null
$script:DefaultTables = @(
    [pscustomobject]@{ Name = '通常難易度表（Normal 1）'; Url = 'https://darksabun.github.io/table/archive/normal1/' },
    [pscustomobject]@{ Name = '発狂BMS難易度表（Insane 1）'; Url = 'https://darksabun.club/table/archive/insane1/' },
    [pscustomobject]@{ Name = 'Satellite（sl）'; Url = 'https://stellabms.xyz/sl/table.html' },
    [pscustomobject]@{ Name = 'Stella（st）'; Url = 'https://stellabms.xyz/st/table.html' },
    [pscustomobject]@{ Name = 'Starlight（sr）'; Url = 'https://djkuroakari.github.io/starlighttable.html' },
    [pscustomobject]@{ Name = 'Overjoy（★★）'; Url = 'https://lr2.sakura.ne.jp/overjoy.php' },
    [pscustomobject]@{ Name = 'Solar（so・癖譜面）'; Url = 'https://stellabms.xyz/so/table.html' },
    [pscustomobject]@{ Name = 'Supernova（sn・高難度癖譜面）'; Url = 'https://stellabms.xyz/sn/table.html' },
    [pscustomobject]@{ Name = 'DP Satellite'; Url = 'https://stellabms.xyz/dp/table.html' },
    [pscustomobject]@{ Name = 'NEW GENERATION 通常（▽）'; Url = 'https://rattoto10.jounin.jp/table.html' },
    [pscustomobject]@{ Name = 'NEW GENERATION 発狂（▼）'; Url = 'https://rattoto10.jounin.jp/table_insane.html' },
    [pscustomobject]@{ Name = 'BMS現代発狂譜面寄せ集め（集）'; Url = 'https://potechang.github.io/like_st/' },
    [pscustomobject]@{ Name = 'FL差分難易度表'; Url = 'https://fsrs.darksabun.club/table.html' }
)

function Ensure-AppFolders {
    foreach ($path in @($script:DataDir, $script:DownloadDir, $script:InboxDir, $script:LogDir)) {
        [System.IO.Directory]::CreateDirectory($path) | Out-Null
    }
}

function Start-PerformanceTrace([string]$Name) {
    $script:PerformanceTrace = [pscustomobject]@{
        Name = $Name
        Started = [DateTime]::UtcNow
        Metrics = @{}
        Counters = @{}
    }
    Write-AppLog 'INFO' 'PERF_START' $Name
    Set-UiProgress $Name 0 0
}

function Set-UiProgress([string]$Stage, [long]$Current = 0, [long]$Total = 0) {
    $bar = $script:UiProgressBar
    if (-not $bar -or $bar.IsDisposed) { return }
    if ($Total -gt 0) {
        $bar.Style = 'Continuous'
        $percent = [int][Math]::Floor(([Math]::Min([double]$Current, [double]$Total) / [double]$Total) * 100.0)
        $bar.Value = [Math]::Max(0, [Math]::Min(100, $percent))
        $bar.AccessibleDescription = "$Stage $Current / $Total"
    } else {
        $bar.Style = 'Marquee'
        $bar.MarqueeAnimationSpeed = 25
        $bar.AccessibleDescription = $Stage
    }
}

function Reset-UiProgress([string]$Description = '待機中') {
    $bar = $script:UiProgressBar
    if (-not $bar -or $bar.IsDisposed) { return }
    $bar.Style = 'Continuous'
    $bar.Value = 0
    $bar.AccessibleName = '処理進捗'
    $bar.AccessibleDescription = $Description
}

function Add-PerformanceMetric([string]$Name, [double]$Milliseconds, [long]$Items = 0) {
    if (-not $script:PerformanceTrace) { return }
    if (-not $script:PerformanceTrace.Metrics.ContainsKey($Name)) {
        $script:PerformanceTrace.Metrics[$Name] = [pscustomobject]@{ Calls=0L; Milliseconds=0.0; Items=0L }
    }
    $metric = $script:PerformanceTrace.Metrics[$Name]
    $metric.Calls++
    $metric.Milliseconds += $Milliseconds
    $metric.Items += $Items
}

function Add-PerformanceCounter([string]$Name, [long]$Count = 1) {
    if (-not $script:PerformanceTrace) { return }
    if ($script:PerformanceTrace.Counters.ContainsKey($Name)) { $script:PerformanceTrace.Counters[$Name] += $Count }
    else { $script:PerformanceTrace.Counters[$Name] = $Count }
}

function Complete-PerformanceTrace {
    if (-not $script:PerformanceTrace) { return }
    $trace = $script:PerformanceTrace
    $elapsedMs = ([DateTime]::UtcNow - $trace.Started).TotalMilliseconds
    Write-AppLog 'INFO' 'PERF_SUMMARY' ("$($trace.Name) 合計=$([Math]::Round($elapsedMs / 1000, 3))秒")
    foreach ($pair in @($trace.Metrics.GetEnumerator() | Sort-Object { $_.Value.Milliseconds } -Descending)) {
        $value = $pair.Value
        Write-AppLog 'INFO' 'PERF_METRIC' ("$($pair.Key): $([Math]::Round($value.Milliseconds / 1000, 3))秒 / 呼出=$($value.Calls) / 対象=$($value.Items)")
    }
    foreach ($pair in @($trace.Counters.GetEnumerator() | Sort-Object Name)) {
        Write-AppLog 'INFO' 'PERF_COUNT' ("$($pair.Key): $($pair.Value)")
    }
    if ($script:UiProgressBar -and -not $script:UiProgressBar.IsDisposed) {
        $script:UiProgressBar.Style = 'Continuous'
        $script:UiProgressBar.Value = 100
    }
    $script:PerformanceTrace = $null
}

function Write-AppLog([string]$Level, [string]$Stage, [string]$Message) {
    if ($script:PerformanceTrace -and $Stage -notlike 'PERF_*') { Add-PerformanceCounter 'ログ書込回数' }
    Ensure-AppFolders
    $line = '{0} [{1}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $Level, $Stage, ($Message -replace "`r?`n", ' / ')
    for ($attempt = 0; $attempt -lt 3; $attempt++) {
        try { Add-Content -LiteralPath $script:LogPath -Encoding UTF8 -Value $line -ErrorAction Stop; break }
        catch { if ($attempt -lt 2) { Start-Sleep -Milliseconds 30 } }
    }
    if ($script:LogTextBox -and -not $script:LogTextBox.IsDisposed) {
        $script:LogTextBox.AppendText($line + [Environment]::NewLine)
        $script:LogTextBox.SelectionStart = $script:LogTextBox.TextLength
        $script:LogTextBox.ScrollToCaret()
    }
}

function Invoke-UiPulse {
    if ($script:PerformanceTrace) { Add-PerformanceCounter 'UI更新回数' }
    $applicationType = 'System.Windows.Forms.Application' -as [type]
    if ($applicationType) { [System.Windows.Forms.Application]::DoEvents() }
}

function Assert-NotCancelled {
    if ($script:CancelRequested) { throw 'ユーザー操作で中止しました。' }
}

function Report-OperationProgress([string]$Stage, [int]$Current, [int]$Total) {
    Set-UiProgress $Stage $Current $Total
    if ($script:OperationProgressCallback) {
        [void](& $script:OperationProgressCallback $Stage $Current $Total)
    }
}

function Load-DownloadCache {
    $script:DownloadCache = @{}
    if (-not (Test-Path -LiteralPath $script:DownloadCachePath -PathType Leaf)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:DownloadCachePath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($property in $saved.PSObject.Properties) {
            $path = [string]$property.Value
            if (Test-Path -LiteralPath $path -PathType Leaf) { $script:DownloadCache[$property.Name] = $path }
        }
    } catch {
        Write-AppLog 'WARN' 'CACHE' ('ダウンロードキャッシュを読み込めません: ' + $_.Exception.Message)
    }
}

function Save-DownloadCache {
    try { $script:DownloadCache | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $script:DownloadCachePath -Encoding UTF8 } catch { }
}

function Clear-PendingAndDownloadStorage([string]$InboxRoot = $script:InboxDir, [string]$DownloadRoot = $script:DownloadDir) {
    [System.IO.Directory]::CreateDirectory($InboxRoot) | Out-Null
    [System.IO.Directory]::CreateDirectory($DownloadRoot) | Out-Null
    $inboxFull = [System.IO.Path]::GetFullPath($InboxRoot).TrimEnd('\') + '\'
    $downloadFull = [System.IO.Path]::GetFullPath($DownloadRoot).TrimEnd('\') + '\'
    $inboxItems = @(Get-ChildItem -LiteralPath $InboxRoot -Force -ErrorAction SilentlyContinue)
    $downloadFiles = @(Get-ChildItem -LiteralPath $DownloadRoot -Recurse -File -Force -ErrorAction SilentlyContinue)
    $downloadBytes = [long](($downloadFiles | Measure-Object Length -Sum).Sum)
    $deletedInboxItems = 0
    foreach ($item in $inboxItems) {
        $itemFull = [System.IO.Path]::GetFullPath($item.FullName)
        if (-not ($itemFull + $(if ($item.PSIsContainer) { '\' } else { '' })).StartsWith($inboxFull, [System.StringComparison]::OrdinalIgnoreCase)) { continue }
        Remove-Item -LiteralPath $itemFull -Recurse -Force
        $deletedInboxItems++
    }
    $deletedDownloads = 0
    foreach ($item in @(Get-ChildItem -LiteralPath $DownloadRoot -Force -ErrorAction SilentlyContinue)) {
        $itemFull = [System.IO.Path]::GetFullPath($item.FullName)
        if (-not ($itemFull + $(if ($item.PSIsContainer) { '\' } else { '' })).StartsWith($downloadFull, [System.StringComparison]::OrdinalIgnoreCase)) { continue }
        Remove-Item -LiteralPath $itemFull -Recurse -Force
    }
    $deletedDownloads = $downloadFiles.Count
    $cacheKeysToRemove = New-Object System.Collections.Generic.List[string]
    foreach ($cacheEntry in $script:DownloadCache.GetEnumerator()) {
        try {
            $cachedFull = [System.IO.Path]::GetFullPath([string]$cacheEntry.Value)
            if ($cachedFull.StartsWith($downloadFull, [System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $cachedFull -PathType Leaf)) { [void]$cacheKeysToRemove.Add([string]$cacheEntry.Key) }
        } catch { [void]$cacheKeysToRemove.Add([string]$cacheEntry.Key) }
    }
    foreach ($cacheKey in $cacheKeysToRemove) { $script:DownloadCache.Remove($cacheKey) }
    Save-DownloadCache
    $partialKeys = @($script:PartialInstalls.Keys)
    $clearedPartial = 0
    foreach ($partialKey in $partialKeys) {
        $state = $script:PartialInstalls[$partialKey]
        $baseFolder = if ($state.PSObject.Properties['BaseFolder']) { [string]$state.BaseFolder } else { '' }
        $pendingFolder = if ($state.PSObject.Properties['PendingFolder']) { [string]$state.PendingFolder } else { '' }
        $basePackage = if ($state.PSObject.Properties['BasePackagePath']) { [string]$state.BasePackagePath } else { '' }
        if (-not $pendingFolder -and -not $basePackage) { continue }
        if ($baseFolder -and (Test-Path -LiteralPath $baseFolder -PathType Container)) {
            $script:PartialInstalls[$partialKey] = [pscustomobject]@{ BaseFolder=$baseFolder; PendingFolder=''; BasePackagePath=''; Title=[string]$state.Title; Updated=[DateTime]::UtcNow.ToString('o') }
        } else {
            $script:PartialInstalls.Remove($partialKey)
        }
        $clearedPartial++
    }
    Save-PartialInstalls
    Clear-ExtractedPackageCache
    Write-AppLog 'INFO' 'DELETE_PENDING' ("受信箱 $deletedInboxItems 件 / ダウンロード $deletedDownloads ファイル ($downloadBytes bytes) / 途中状態 $clearedPartial 件を削除")
    return [pscustomobject]@{ InboxItems=$deletedInboxItems; DownloadFiles=$deletedDownloads; DownloadBytes=$downloadBytes; PartialStates=$clearedPartial }
}

function Load-SourceUrlCache {
    $script:SourceUrlCache = @{}
    if (-not (Test-Path -LiteralPath $script:SourceUrlCachePath -PathType Leaf)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:SourceUrlCachePath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($property in $saved.PSObject.Properties) { $script:SourceUrlCache[$property.Name] = @($property.Value) }
    } catch { Write-AppLog 'WARN' 'SOURCE_CACHE' ('取得先キャッシュを読み込めません: ' + $_.Exception.Message) }
}

function Save-SourceUrlCache {
    try { $script:SourceUrlCache | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $script:SourceUrlCachePath -Encoding UTF8 } catch { }
}

function Load-PartialInstalls {
    $script:PartialInstalls = @{}
    if (-not (Test-Path -LiteralPath $script:PartialInstallPath -PathType Leaf)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:PartialInstallPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($property in $saved.PSObject.Properties) { $script:PartialInstalls[$property.Name] = $property.Value }
    } catch { Write-AppLog 'WARN' 'PARTIAL' ('途中状態を読み込めません: ' + $_.Exception.Message) }
}

function Save-PartialInstalls {
    try { $script:PartialInstalls | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:PartialInstallPath -Encoding UTF8 } catch { }
}

function Get-PartialInstallKey($Entry) {
    $md5 = Get-EntryHash $Entry 'md5'
    if ($md5) { return 'md5:' + $md5 }
    $sha = Get-EntryHash $Entry 'sha256'
    if ($sha) { return 'sha256:' + $sha }
    return ''
}

function Get-PartialInstall($Entry) {
    $key = Get-PartialInstallKey $Entry
    if (-not $key -or -not $script:PartialInstalls.ContainsKey($key)) { return $null }
    $state = $script:PartialInstalls[$key]
    $baseFolder = if ($state.PSObject.Properties['BaseFolder']) { [string]$state.BaseFolder } else { '' }
    $pendingFolder = if ($state.PSObject.Properties['PendingFolder']) { [string]$state.PendingFolder } else { '' }
    $basePackagePath = if ($state.PSObject.Properties['BasePackagePath']) { [string]$state.BasePackagePath } else { '' }
    if ($baseFolder -and -not (Test-Path -LiteralPath $baseFolder -PathType Container)) { $baseFolder = '' }
    if ($pendingFolder -and -not (Test-Path -LiteralPath $pendingFolder -PathType Container)) { $pendingFolder = '' }
    if ($basePackagePath -and -not (Test-Path -LiteralPath $basePackagePath -PathType Leaf)) { $basePackagePath = '' }
    if (-not $baseFolder -and -not $pendingFolder -and -not $basePackagePath) {
        $script:PartialInstalls.Remove($key)
        Save-PartialInstalls
        return $null
    }
    return [pscustomobject]@{ Key=$key; BaseFolder=$baseFolder; PendingFolder=$pendingFolder; BasePackagePath=$basePackagePath; Title=[string]$state.Title; Updated=[string]$state.Updated }
}

function Set-PartialInstall($Entry, [string]$BaseFolder = '', [string]$PendingFolder = '', [string]$BasePackagePath = '', [switch]$ClearBaseFolder) {
    $key = Get-PartialInstallKey $Entry
    if (-not $key) { return }
    $existing = Get-PartialInstall $Entry
    if ($ClearBaseFolder) { $BaseFolder = '' }
    elseif (-not $BaseFolder -and $existing) { $BaseFolder = [string]$existing.BaseFolder }
    if (-not $PendingFolder -and $existing) { $PendingFolder = [string]$existing.PendingFolder }
    if (-not $BasePackagePath -and $existing) { $BasePackagePath = [string]$existing.BasePackagePath }
    $script:PartialInstalls[$key] = [pscustomobject]@{
        BaseFolder=$BaseFolder
        PendingFolder=$PendingFolder
        BasePackagePath=$BasePackagePath
        Title=(Get-EntryText $Entry 'title' '')
        Updated=[DateTime]::UtcNow.ToString('o')
    }
    Save-PartialInstalls
    Write-AppLog 'INFO' 'PARTIAL' ("途中状態を保存: $key / 元曲フォルダ=$BaseFolder / 元曲候補ファイル=$BasePackagePath / 差分=$PendingFolder")
}

function Clear-PartialInstall($Entry, [switch]$RemovePendingFolder) {
    $key = Get-PartialInstallKey $Entry
    if (-not $key -or -not $script:PartialInstalls.ContainsKey($key)) { return }
    $state = $script:PartialInstalls[$key]
    if ($RemovePendingFolder -and $state.PSObject.Properties['PendingFolder']) {
        $pending = [string]$state.PendingFolder
        if (-not [string]::IsNullOrWhiteSpace($pending)) {
            try {
                $inboxRoot = [System.IO.Path]::GetFullPath($script:InboxDir).TrimEnd('\') + '\'
                $pendingFull = [System.IO.Path]::GetFullPath($pending).TrimEnd('\') + '\'
                if ($pendingFull.StartsWith($inboxRoot, [System.StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $pending -PathType Container)) { Remove-Item -LiteralPath $pending -Recurse -Force }
            } catch { Write-AppLog 'WARN' 'PARTIAL' ('完了した配置待ちフォルダを削除できません: ' + $_.Exception.Message) }
        }
    }
    $script:PartialInstalls.Remove($key)
    Save-PartialInstalls
    Write-AppLog 'INFO' 'PARTIAL' ("不足側の補完が完了: $key")
}

function Get-EntrySourceKey($Entry) {
    $md5 = Get-EntryHash $Entry 'md5'
    if ($md5) { return 'md5:' + $md5 }
    $sha = Get-EntryHash $Entry 'sha256'
    if ($sha) { return 'sha256:' + $sha }
    return ''
}

function Register-SuccessfulSourceUrl($Entry, [string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return }
    $key = Get-EntrySourceKey $Entry
    if (-not $key) { return }
    $values = New-Object System.Collections.Generic.List[string]
    foreach ($existing in @($script:SourceUrlCache[$key])) { if ($existing -and $existing -ne $Url) { [void]$values.Add([string]$existing) } }
    $values.Insert(0, $Url)
    while ($values.Count -gt 5) { $values.RemoveAt($values.Count - 1) }
    $script:SourceUrlCache[$key] = [string[]]$values.ToArray()
    Save-SourceUrlCache
    Write-AppLog 'INFO' 'SOURCE_CACHE' ("成功した取得先を記録: $key -> $Url")
}

function Remove-FailedSourceUrl($Entry, [string]$Url) {
    $key = Get-EntrySourceKey $Entry
    if (-not $key -or -not $script:SourceUrlCache.ContainsKey($key)) { return }
    $remaining = @($script:SourceUrlCache[$key] | Where-Object { [string]$_ -ne $Url })
    if ($remaining.Count -eq @($script:SourceUrlCache[$key]).Count) { return }
    if ($remaining.Count -gt 0) { $script:SourceUrlCache[$key] = [string[]]$remaining } else { $script:SourceUrlCache.Remove($key) }
    Save-SourceUrlCache
}

function Load-Md5UrlMap {
    if ($null -ne $script:Md5UrlMap) { return $script:Md5UrlMap }
    $script:Md5UrlMap = @{}
    try {
        $needsDownload = -not (Test-Path -LiteralPath $script:Md5UrlMapPath -PathType Leaf)
        if (-not $needsDownload) { $needsDownload = ((Get-Date) - (Get-Item -LiteralPath $script:Md5UrlMapPath).LastWriteTime).TotalDays -gt 7 }
        if ($needsDownload) {
            Set-UiProgress '公開MD5→URLマップを更新中' 0 0
            $temporary = $script:Md5UrlMapPath + '.download'
            [void](Save-UrlResponsive ([string]$script:Settings.Md5UrlMapUrl) $temporary 60 20)
            Move-Item -LiteralPath $temporary -Destination $script:Md5UrlMapPath -Force
        }
        $lineNumber = 0
        foreach ($line in [System.IO.File]::ReadLines($script:Md5UrlMapPath, [System.Text.Encoding]::UTF8)) {
            $lineNumber++
            if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith('#')) { continue }
            $fields = @($line -split "`t")
            $md5 = [string](@($fields | Where-Object { $_.Trim().ToLowerInvariant() -match '^[0-9a-f]{32}$' } | Select-Object -First 1))
            if (-not $md5) { continue }
            $md5 = $md5.Trim().ToLowerInvariant()
            $urls = @($fields | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^https?://' } | Select-Object -Unique)
            if ($urls.Count -gt 0) { $script:Md5UrlMap[$md5] = [string[]]$urls }
        }
        Write-AppLog 'INFO' 'MD5_URL_MAP' ("読込: $($script:Md5UrlMap.Count)件 / $lineNumber 行")
    } catch {
        Write-AppLog 'WARN' 'MD5_URL_MAP' ("公開MD5→URLマップを利用できません: $($_.Exception.Message)")
    }
    return $script:Md5UrlMap
}

function Get-AlternativeSourceUrls($Entry, [string]$TableDataUrl, [string]$PreferredProperty = '') {
    $seen = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $result = New-Object System.Collections.Generic.List[string]
    $key = Get-EntrySourceKey $Entry
    if ($key -and $script:SourceUrlCache.ContainsKey($key)) {
        foreach ($url in @($script:SourceUrlCache[$key])) { if ($url -match '^https?://' -and $seen.Add($url)) { [void]$result.Add($url) } }
    }
    $md5 = Get-EntryHash $Entry 'md5'
    if ($md5) {
        $map = Load-Md5UrlMap
        if ($map.ContainsKey($md5)) {
            $mappedUrls = @($map[$md5])
            if ($PreferredProperty -eq 'url_diff') { [array]::Reverse($mappedUrls) }
            foreach ($url in $mappedUrls) { if ($url -match '^https?://' -and $seen.Add($url)) { [void]$result.Add($url) } }
        }
    }
    $originalValue = Get-EntryDownloadUrl $Entry $PreferredProperty
    if ($originalValue) {
        $original = Convert-ToDirectDownloadUrl (Resolve-AbsoluteUrl $TableDataUrl $originalValue)
        [void]$seen.Add($original)
        return @($result | Where-Object { $_ -ne $original })
    }
    return [string[]]$result.ToArray()
}

function Test-KnownBrokenDistributionUrl([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $true }
    $normalized = $Url.ToLowerInvariant()
    return $normalized.Contains('gnqg.rosx.net') -or $normalized.Contains('absolute.pv.land.to')
}

function Get-PreflightSourceUrl($Entry, [string]$TableDataUrl, [string]$PreferredProperty = '') {
    $originalValue = Get-EntryDownloadUrl $Entry $PreferredProperty
    $originalUrl = if ($originalValue) { Resolve-AbsoluteUrl $TableDataUrl $originalValue } else { '' }
    if ($originalUrl -and -not (Test-KnownBrokenDistributionUrl $originalUrl)) {
        return [pscustomobject]@{ Url=$originalUrl; Complemented=$false; Reason='難易度表URL' }
    }
    if (-not (Test-AllowAlternativeSource $PreferredProperty)) {
        return [pscustomobject]@{ Url=$originalUrl; Complemented=$false; Reason=$(if ($originalUrl) { '元曲URLはMD5代替対象外' } else { '元曲URLなし' }) }
    }
    $alternatives = @(Get-AlternativeSourceUrls $Entry $TableDataUrl $PreferredProperty)
    if ($alternatives.Count -gt 0) {
        $reason = if ($originalUrl) { '既知のリンク切れURLをMD5で補完' } else { '空のURLをMD5で補完' }
        return [pscustomobject]@{ Url=[string]$alternatives[0]; Complemented=$true; Reason=$reason }
    }
    return [pscustomobject]@{ Url=$originalUrl; Complemented=$false; Reason=$(if ($originalUrl) { '補完候補なし' } else { 'URLなし' }) }
}

function Download-EntryFromAlternatives($Entry, [string]$TableDataUrl, [string]$PreferredProperty = '') {
    $urls = @(Get-AlternativeSourceUrls $Entry $TableDataUrl $PreferredProperty | Select-Object -First 3)
    if ($urls.Count -eq 0) { return $null }
    $title = Get-EntryText $Entry 'title' 'chart'
    $attempt = 0
    foreach ($candidate in $urls) {
        $attempt++
        Assert-NotCancelled
        $direct = Convert-ToDirectDownloadUrl $candidate
        Write-AppLog 'INFO' 'ALTERNATIVE_SOURCE' ("代替取得先 $attempt/$($urls.Count): $direct")
        try {
            if ($script:DownloadCache.ContainsKey($direct) -and (Test-Path -LiteralPath $script:DownloadCache[$direct] -PathType Leaf)) {
                $resolved = Resolve-DownloadedContent $Entry $direct ([string]$script:DownloadCache[$direct])
            } else {
                $destination = New-DownloadDestination $direct $title
                [void](Save-UrlResponsive $direct $destination 60 15)
                $script:DownloadCache[$direct] = $destination
                Save-DownloadCache
                $resolved = Resolve-DownloadedContent $Entry $direct $destination
            }
            return [pscustomobject]@{ Path=$resolved; Url=$direct }
        } catch {
            if ($script:CancelRequested) { throw 'ユーザー操作で中止しました。' }
            Write-AppLog 'WARN' 'ALTERNATIVE_SOURCE' ("候補失敗: $direct / $($_.Exception.Message)")
            Remove-FailedSourceUrl $Entry $direct
        }
    }
    return $null
}

function Load-LocalInstalledHashes {
    $script:LocalInstalledMD5 = @{}
    $script:LocalInstalledSHA256 = @{}
    if (-not (Test-Path -LiteralPath $script:CachePath -PathType Leaf)) { return }
    try {
        $saved = Get-Content -LiteralPath $script:CachePath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($hash in @($saved.MD5)) {
            $value = ([string]$hash).Trim().ToLowerInvariant()
            if ($value -match '^[0-9a-f]{32}$') { $script:LocalInstalledMD5[$value] = $true }
        }
        foreach ($hash in @($saved.SHA256)) {
            $value = ([string]$hash).Trim().ToLowerInvariant()
            if ($value -match '^[0-9a-f]{64}$') { $script:LocalInstalledSHA256[$value] = $true }
        }
        Write-AppLog 'INFO' 'LOCAL_INSTALLED' ("読込: MD5 $($script:LocalInstalledMD5.Count)件 / SHA-256 $($script:LocalInstalledSHA256.Count)件")
    } catch {
        Write-AppLog 'WARN' 'LOCAL_INSTALLED' ('導入済み記録を読み込めません: ' + $_.Exception.Message)
    }
}

function Save-LocalInstalledHashes {
    try {
        [ordered]@{
            MD5 = @($script:LocalInstalledMD5.Keys | Sort-Object)
            SHA256 = @($script:LocalInstalledSHA256.Keys | Sort-Object)
        } | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $script:CachePath -Encoding UTF8
    } catch {
        Write-AppLog 'WARN' 'LOCAL_INSTALLED' ('導入済み記録を保存できません: ' + $_.Exception.Message)
    }
}

function Register-EntryInstalled($Entry) {
    $changed = $false
    $md5 = Get-EntryHash $Entry 'md5'
    $sha = Get-EntryHash $Entry 'sha256'
    if ($md5 -match '^[0-9a-f]{32}$' -and -not $script:LocalInstalledMD5.ContainsKey($md5)) { $script:LocalInstalledMD5[$md5] = $true; $changed = $true }
    if ($sha -match '^[0-9a-f]{64}$' -and -not $script:LocalInstalledSHA256.ContainsKey($sha)) { $script:LocalInstalledSHA256[$sha] = $true; $changed = $true }
    if ($changed) {
        Save-LocalInstalledHashes
        Write-AppLog 'INFO' 'LOCAL_INSTALLED' ("導入済みとして記録: MD5=$md5 / SHA-256=$sha")
    }
}

function Test-EntryRecordedInstalled($Entry) {
    $md5 = Get-EntryHash $Entry 'md5'
    $sha = Get-EntryHash $Entry 'sha256'
    return (($md5 -ne '') -and $script:LocalInstalledMD5.ContainsKey($md5)) -or (($sha -ne '') -and $script:LocalInstalledSHA256.ContainsKey($sha))
}

function Repair-MojibakeText([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or $Value -notmatch '[ÃÂÎÏÐÑâçéåæä]|[\u0080-\u009F]') { return $Value }
    $bytes = New-Object byte[] $Value.Length
    for ($index = 0; $index -lt $Value.Length; $index++) {
        $code = [int][char]$Value[$index]
        if ($code -gt 255) { return $Value }
        $bytes[$index] = [byte]$code
    }
    try {
        $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
        $repaired = $strictUtf8.GetString($bytes)
        if ($repaired -and $repaired -ne $Value -and $repaired -notmatch '[\u0080-\u009F\uFFFD]') { return $repaired }
    } catch { }
    return $Value
}

function New-DefaultSettings {
    [ordered]@{
        BeatorajaPath = ''
        MusicPath     = ''
        MusicPaths    = @()
        PlayerMode    = 'beatoraja'
        Tables        = @()
        CustomTables  = @()
        SelectedLevels = @()
        Md5UrlMapUrl = 'https://raw.githubusercontent.com/Neeted/bemusicseeker-unofficial-fork/refs/heads/main/bms-md5-url-map.tsv'
    }
}

function Load-Settings {
    Ensure-AppFolders
    if (-not (Test-Path -LiteralPath $script:SettingsPath -PathType Leaf)) {
        return New-DefaultSettings
    }
    try {
        $saved = Get-Content -LiteralPath $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $customTables = New-Object System.Collections.ArrayList
        $repairedNames = 0
        foreach ($savedTable in @($(if ($saved.PSObject.Properties['CustomTables']) { $saved.CustomTables } else { @() }))) {
            $savedUrl = [string]$savedTable.Url
            $savedName = [string]$savedTable.Name
            $repairedName = Repair-MojibakeText $savedName
            if ($repairedName -ne $savedName) { $repairedNames++ }
            [void]$customTables.Add([pscustomobject]@{ Name=$repairedName; Url=$savedUrl })
        }
        $settings = [ordered]@{
            BeatorajaPath = [string]$saved.BeatorajaPath
            MusicPath     = [string]$saved.MusicPath
            MusicPaths    = @($(if ($saved.PSObject.Properties['MusicPaths']) { $saved.MusicPaths } elseif ($saved.MusicPath) { @([string]$saved.MusicPath) } else { @() }))
            PlayerMode    = $(if ($saved.PSObject.Properties['PlayerMode'] -and [string]$saved.PlayerMode -eq 'folder') { 'folder' } else { 'beatoraja' })
            Tables        = @($saved.Tables)
            CustomTables  = @($customTables.ToArray())
            SelectedLevels = @($(if ($saved.PSObject.Properties['SelectedLevels']) { $saved.SelectedLevels } else { @() }))
            Md5UrlMapUrl = $(if ($saved.PSObject.Properties['Md5UrlMapUrl'] -and $saved.Md5UrlMapUrl) { [string]$saved.Md5UrlMapUrl } else { 'https://raw.githubusercontent.com/Neeted/bemusicseeker-unofficial-fork/refs/heads/main/bms-md5-url-map.tsv' })
        }
        if ($repairedNames -gt 0) {
            $settings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
            Write-AppLog 'INFO' 'MIGRATION' ("文字化けしていた難易度表名を修復: $repairedNames 件")
        }
        return $settings
    } catch {
        return New-DefaultSettings
    }
}

function Save-Settings([System.Collections.IDictionary]$Settings) {
    Ensure-AppFolders
    $Settings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
}

function Get-RegisteredMusicPaths {
    $paths = New-Object System.Collections.Generic.List[string]
    $settingsValue = Get-Variable -Name Settings -Scope Script -ValueOnly -ErrorAction SilentlyContinue
    if (-not $settingsValue) { return @() }
    foreach ($candidate in @($settingsValue.MusicPaths) + @($settingsValue.MusicPath)) {
        if ([string]::IsNullOrWhiteSpace([string]$candidate)) { continue }
        try { $full = [System.IO.Path]::GetFullPath([string]$candidate).TrimEnd('\') } catch { continue }
        if (-not @($paths | Where-Object { $_ -eq $full }).Count) { [void]$paths.Add($full) }
    }
    return [string[]]$paths.ToArray()
}

function Import-BeatorajaConfiguration([string]$BeatorajaPath) {
    if (-not (Test-BeatorajaFolder $BeatorajaPath)) { throw 'beatorajaの本体フォルダを選んでください。' }
    $configPath = Join-Path $BeatorajaPath 'config_sys.json'
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) { throw 'config_sys.jsonが見つかりません。通常のフォルダ登録を使用してください。' }
    $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($config.bmsroot)) {
        if ([string]::IsNullOrWhiteSpace([string]$value)) { continue }
        $path = [string]$value
        if (-not [System.IO.Path]::IsPathRooted($path)) { $path = Join-Path $BeatorajaPath $path }
        try { $path = [System.IO.Path]::GetFullPath($path).TrimEnd('\') } catch { continue }
        if ((Test-Path -LiteralPath $path -PathType Container) -and -not @($roots | Where-Object { $_ -eq $path }).Count) { [void]$roots.Add($path) }
    }
    $tables = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($config.tableURL)) {
        $url = ([string]$value).Trim()
        if ($url -match '^https?://' -and -not @($tables | Where-Object { $_.TrimEnd('/') -eq $url.TrimEnd('/') }).Count) { [void]$tables.Add($url) }
    }
    return [pscustomobject]@{ MusicPaths=[string[]]$roots.ToArray(); TableUrls=[string[]]$tables.ToArray(); ConfigPath=$configPath }
}

function Ensure-LibraryIndexType {
    if ('BeatorajaMissingChartFetcher.LibraryIndex' -as [type]) { return }
    if (-not (Test-Path -LiteralPath $script:LibraryIndexReaderPath -PathType Leaf)) { throw 'LibraryIndex.csがありません。配布ファイルを展開し直してください。' }
    Add-Type -Path $script:LibraryIndexReaderPath
}

function Test-LibraryIndexAvailable([string[]]$Roots = $(Get-RegisteredMusicPaths)) {
    try {
        Ensure-LibraryIndexType
        return [BeatorajaMissingChartFetcher.LibraryIndex]::IsUsable($script:LibraryIndexDir, [string[]]$Roots)
    } catch { return $false }
}

function Get-PersistentLibraryIndex([string[]]$Roots = $(Get-RegisteredMusicPaths)) {
    if (-not (Test-LibraryIndexAvailable $Roots)) { return $null }
    Ensure-LibraryIndexType
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $records = [BeatorajaMissingChartFetcher.LibraryIndex]::LoadCharts($script:LibraryIndexDir)
    $byMd5 = @{}
    $bySha = @{}
    $directories = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($record in $records) {
        $row = [pscustomobject]@{ Path=[string]$record.Path; Directory=[string]$record.Directory; MD5=[string]$record.MD5; SHA256=[string]$record.SHA256; Title=[string]$record.Title; Artist=[string]$record.Artist }
        if ($row.MD5) { $byMd5[$row.MD5] = $row }
        if ($row.SHA256) { $bySha[$row.SHA256] = $row }
        if ($row.Directory) { [void]$directories.Add($row.Directory) }
    }
    $timer.Stop()
    Add-PerformanceMetric '高速ライブラリ索引読込' $timer.Elapsed.TotalMilliseconds $records.Count
    Write-AppLog 'INFO' 'LIBRARY_INDEX' ("読込: $($records.Count)譜面 / $($directories.Count)フォルダ / $([Math]::Round($timer.Elapsed.TotalSeconds, 2))秒")
    $index = [pscustomobject]@{ ByMD5=$byMd5; BySHA256=$bySha; Rows=@($records); Directories=@($directories); Source=$script:LibraryIndexDir; Mode='persistent'; Roots=[string[]]$Roots }
    $script:CurrentLibraryIndex = $index
    return $index
}

function Update-LibraryIndex([string[]]$Roots, [scriptblock]$ProgressCallback = $null, [switch]$Full) {
    Ensure-LibraryIndexType
    $registeredRoots = @($Roots | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { [System.IO.Path]::GetFullPath([string]$_).TrimEnd('\') } | Select-Object -Unique)
    if ($registeredRoots.Count -eq 0) { throw '登録されたBMSフォルダがありません。' }
    $missingRoots = @($registeredRoots | Where-Object { -not (Test-Path -LiteralPath $_ -PathType Container) })
    if ($missingRoots.Count -gt 0) {
        throw ("次の登録フォルダを現在開けないため、索引更新を中止しました。既存の索引は維持されています。`n" + ($missingRoots -join "`n"))
    }
    $validRoots = $registeredRoots
    $progressDelegate = [Action[string,int,int]]{
        param($stage, $current, $total)
        if ($ProgressCallback) { & $ProgressCallback $stage $current $total }
        Invoke-UiPulse
        Assert-NotCancelled
    }
    Write-AppLog 'INFO' 'LIBRARY_INDEX' ("更新開始: $($validRoots -join ' / ')")
    $result = [BeatorajaMissingChartFetcher.LibraryIndex]::Build([string[]]$validRoots, $script:LibraryIndexDir, $progressDelegate, (-not $Full))
    Write-AppLog 'INFO' 'LIBRARY_INDEX' ("更新完了: 全ファイル $($result.FileCount) / 譜面 $($result.ChartCount) / ハッシュ再利用 $($result.ReusedChartCount) / 再計算 $($result.HashedChartCount) / $([Math]::Round($result.ElapsedSeconds, 2))秒")
    $script:FolderFileCache = @{}
    $script:SessionResourceFolders = @{}
    $script:SessionIndexDirty = $false
    $script:SessionIndexedFolders.Clear()
    $script:Settings.MusicPaths = [string[]]$validRoots
    if ([string]::IsNullOrWhiteSpace([string]$script:Settings.MusicPath) -or $validRoots -notcontains [string]$script:Settings.MusicPath) { $script:Settings.MusicPath = $validRoots[0] }
    Save-Settings $script:Settings
    return Get-PersistentLibraryIndex $validRoots
}

function Register-FolderInSessionIndex([string]$Folder) {
    if (-not (Test-Path -LiteralPath $Folder -PathType Container)) { return }
    $normalizedFolder = [System.IO.Path]::GetFullPath($Folder).TrimEnd('\')
    $script:SessionIndexDirty = $true
    [void]$script:SessionIndexedFolders.Add($normalizedFolder)
    $activeDatabaseIndex = Get-Variable -Name CurrentDatabaseIndex -Scope Script -ValueOnly -ErrorAction SilentlyContinue
    foreach ($file in @(Get-ChildItem -LiteralPath $Folder -Recurse -File -ErrorAction SilentlyContinue)) {
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($file.Name).ToLowerInvariant()
        if (-not $stem) { continue }
        if (-not $script:SessionResourceFolders.ContainsKey($stem)) { $script:SessionResourceFolders[$stem] = New-Object System.Collections.ArrayList }
        if (-not @($script:SessionResourceFolders[$stem] | Where-Object { $_ -eq $Folder }).Count) { [void]$script:SessionResourceFolders[$stem].Add($Folder) }
        if ($script:ChartExtensions -contains $file.Extension.ToLowerInvariant() -and $activeDatabaseIndex) {
            try {
                $md5 = (Get-FileHash -LiteralPath $file.FullName -Algorithm MD5).Hash.ToLowerInvariant()
                $sha = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                $row = [pscustomobject]@{ Path=$file.FullName; Directory=$Folder; MD5=$md5; SHA256=$sha }
                $activeDatabaseIndex.ByMD5[$md5] = $row
                $activeDatabaseIndex.BySHA256[$sha] = $row
                Add-PerformanceCounter '配置直後MD5計算回数'
                Add-PerformanceCounter '配置直後SHA256計算回数'
            } catch { Write-AppLog 'WARN' 'INDEX_UPDATE' ("配置直後の譜面索引更新に失敗: $($file.FullName) / $($_.Exception.Message)") }
        }
    }
}

function Find-ParentFolderFromIndex([string[]]$References) {
    if (-not $References -or $References.Count -eq 0) { return $null }
    $candidateHits = @{}
    if (Test-LibraryIndexAvailable) {
        Ensure-LibraryIndexType
        $lookupTimer = [System.Diagnostics.Stopwatch]::StartNew()
        foreach ($candidate in [BeatorajaMissingChartFetcher.LibraryIndex]::FindCandidates($script:LibraryIndexDir, [string[]]$References, 12)) {
            $candidateHits[[string]$candidate.Path] = [int]$candidate.Hits
        }
        $lookupTimer.Stop()
        Add-PerformanceMetric '親曲索引検索' $lookupTimer.Elapsed.TotalMilliseconds $References.Count
        Add-PerformanceCounter '親曲索引検索回数'
    }
    foreach ($reference in $References) {
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($reference).ToLowerInvariant()
        if (-not $stem -or -not $script:SessionResourceFolders.ContainsKey($stem)) { continue }
        foreach ($folder in $script:SessionResourceFolders[$stem]) {
            if ($candidateHits.ContainsKey($folder)) { $candidateHits[$folder]++ } else { $candidateHits[$folder] = 1 }
        }
    }
    if ($candidateHits.Count -eq 0) { return $null }
    $orderedHits = @($candidateHits.GetEnumerator() | Sort-Object Value -Descending)
    $topHitCount = [int]$orderedHits[0].Value
    $secondHitCount = if ($orderedHits.Count -gt 1) { [int]$orderedHits[1].Value } else { 0 }
    $topRatio = $topHitCount / [double]$References.Count
    if ($topHitCount -ge 3 -and $topRatio -ge 0.50 -and ($topHitCount -gt $secondHitCount -or $topRatio -gt 0.90)) {
        $topPath = [string]$orderedHits[0].Key
        if (Test-Path -LiteralPath $topPath -PathType Container) {
            $verified = Get-FolderReferenceScore $topPath $References
            if ($verified.Hits -ge 3 -and $verified.Ratio -ge 0.50) {
                Write-AppLog 'INFO' 'PARENT_INDEX' ("高速索引で親BMSを特定: $($verified.Hits)/$($References.Count)一致 -> $topPath")
                return $topPath
            }
        }
    }
    $scores = New-Object System.Collections.Generic.List[object]
    foreach ($pair in @($orderedHits | Select-Object -First 12)) {
        if (-not (Test-Path -LiteralPath $pair.Key -PathType Container)) { continue }
        $score = Get-FolderReferenceScore ([string]$pair.Key) $References
        if ($score.Hits -gt 0) { [void]$scores.Add($score) }
    }
    $ordered = @($scores | Sort-Object Hits, Ratio -Descending)
    if ($ordered.Count -eq 0) { return $null }
    $best = $ordered[0]
    $secondHits = if ($ordered.Count -gt 1) { $ordered[1].Hits } else { 0 }
    if ($best.Hits -ge 3 -and $best.Ratio -ge 0.50 -and ($best.Hits -gt $secondHits -or $best.Ratio -gt 0.90)) {
        Write-AppLog 'INFO' 'PARENT_INDEX' ("高速索引で親BMSを特定: $($best.Hits)/$($References.Count)一致 -> $($best.Path)")
        return $best.Path
    }
    return $null
}

function Test-BeatorajaFolder([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    return (Test-Path -LiteralPath (Join-Path $Path 'beatoraja.jar') -PathType Leaf) -or
           (Test-Path -LiteralPath (Join-Path $Path 'songdata.db') -PathType Leaf)
}

function Find-LikelyMusicFolder([string]$BeatorajaPath) {
    $candidates = @(
        (Join-Path $BeatorajaPath 'music'),
        (Join-Path $BeatorajaPath 'songs'),
        (Join-Path (Split-Path -Parent $BeatorajaPath) 'music'),
        (Join-Path (Split-Path -Parent $BeatorajaPath) 'BMS')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Container) { return $candidate }
    }
    return ''
}

function Get-ChartFiles([string]$MusicPath) {
    if (-not (Test-Path -LiteralPath $MusicPath -PathType Container)) { return @() }
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $result = @(Get-ChildItem -LiteralPath $MusicPath -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $script:ChartExtensions -contains $_.Extension.ToLowerInvariant() })
    $timer.Stop()
    Add-PerformanceMetric 'BMSファイル列挙' $timer.Elapsed.TotalMilliseconds $result.Count
    Add-PerformanceCounter '再帰BMS列挙回数'
    try {
        if ($script:CurrentMusicPath -and ([System.IO.Path]::GetFullPath($MusicPath).TrimEnd('\') -eq [System.IO.Path]::GetFullPath($script:CurrentMusicPath).TrimEnd('\'))) {
            Add-PerformanceMetric 'BMSライブラリ全走査' $timer.Elapsed.TotalMilliseconds $result.Count
            Add-PerformanceCounter 'BMSライブラリ全走査回数'
        } else {
            Add-PerformanceMetric '作業フォルダBMS列挙' $timer.Elapsed.TotalMilliseconds $result.Count
        }
    } catch { }
    return $result
}

function Get-LocalChartIndex([string]$MusicPath, [scriptblock]$ProgressCallback) {
    $totalTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $files = Get-ChartFiles $MusicPath
    $byMd5 = @{}
    $bySha256 = @{}
    $directories = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $rows = New-Object System.Collections.Generic.List[object]
    $cacheByPath = @{}
    $fullMusicPath = [System.IO.Path]::GetFullPath($MusicPath)
    if (Test-Path -LiteralPath $script:ChartIndexCachePath -PathType Leaf) {
        try {
            $savedCache = Get-Content -LiteralPath $script:ChartIndexCachePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$savedCache.MusicPath -eq $fullMusicPath) {
                foreach ($savedItem in @($savedCache.Items)) { $cacheByPath[[string]$savedItem.Path] = $savedItem }
            }
        } catch { Write-AppLog 'WARN' 'FOLDER_INDEX' ("所持譜面キャッシュを読み込めません: $($_.Exception.Message)") }
    }
    $newCacheItems = New-Object System.Collections.Generic.List[object]
    $cacheHits = 0
    $i = 0
    foreach ($file in $files) {
        $i++
        if ($ProgressCallback -and ($i % 20 -eq 0 -or $i -eq $files.Count)) {
            & $ProgressCallback $i $files.Count $file.Name
        }
        try {
            $cached = if ($cacheByPath.ContainsKey($file.FullName)) { $cacheByPath[$file.FullName] } else { $null }
            if ($cached -and [long]$cached.Length -eq [long]$file.Length -and [long]$cached.LastWriteTicks -eq [long]$file.LastWriteTimeUtc.Ticks) {
                $md5 = [string]$cached.MD5
                $sha = [string]$cached.SHA256
                $cacheHits++
            } else {
                $md5 = (Get-FileHash -LiteralPath $file.FullName -Algorithm MD5).Hash.ToLowerInvariant()
                $sha = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                Add-PerformanceCounter 'ライブラリMD5計算回数'
                Add-PerformanceCounter 'ライブラリSHA256計算回数'
            }
            $row = [pscustomobject]@{ Path = $file.FullName; Directory = $file.DirectoryName; MD5 = $md5; SHA256 = $sha }
            $byMd5[$md5] = $row
            $bySha256[$sha] = $row
            [void]$directories.Add($file.DirectoryName)
            $rows.Add($row)
            $newCacheItems.Add([pscustomobject]@{ Path=$file.FullName; Length=[long]$file.Length; LastWriteTicks=[long]$file.LastWriteTimeUtc.Ticks; MD5=$md5; SHA256=$sha })
        } catch { }
    }
    try {
        Ensure-AppFolders
        [pscustomobject]@{ MusicPath=$fullMusicPath; Items=$newCacheItems.ToArray() } |
            ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:ChartIndexCachePath -Encoding UTF8
    } catch { Write-AppLog 'WARN' 'FOLDER_INDEX' ("所持譜面キャッシュを保存できません: $($_.Exception.Message)") }
    Write-AppLog 'INFO' 'FOLDER_INDEX' ("曲フォルダ: $($rows.Count)譜面 / $($directories.Count)フォルダ / キャッシュ利用 $cacheHits 件")
    $totalTimer.Stop()
    Add-PerformanceMetric '所持確認（曲フォルダ直接）' $totalTimer.Elapsed.TotalMilliseconds $rows.Count
    Add-PerformanceCounter 'ライブラリハッシュキャッシュ利用件数' $cacheHits
    [pscustomobject]@{ ByMD5 = $byMd5; BySHA256 = $bySha256; Rows = $rows; Directories = @($directories); Source = $fullMusicPath; Mode = 'folder' }
}

function Get-SongDatabaseIndex([string]$BeatorajaPath) {
    $databaseTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $databasePath = Join-Path $BeatorajaPath 'songdata.db'
    if (-not (Test-Path -LiteralPath $databasePath -PathType Leaf)) {
        throw '選択した場所にsongdata.dbがありません。beatorajaの本体フォルダを選び直してください。'
    }
    if (-not (Test-Path -LiteralPath $script:DatabaseReaderPath -PathType Leaf)) {
        throw 'SongDatabaseReader.csがありません。配布ファイルを展開し直してください。'
    }
    if (-not ('BeatorajaMissingChartFetcher.SongDatabaseReader' -as [type])) {
        Add-Type -Path $script:DatabaseReaderPath
    }

    $records = [BeatorajaMissingChartFetcher.SongDatabaseReader]::Read($databasePath)
    $byMd5 = @{}
    $bySha256 = @{}
    $directories = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($record in $records) {
        $rawPath = [string]$record.Path
        $fullPath = $rawPath
        if (-not [string]::IsNullOrWhiteSpace($rawPath)) {
            try {
                if (-not [System.IO.Path]::IsPathRooted($rawPath)) { $fullPath = Join-Path $BeatorajaPath $rawPath }
                $fullPath = [System.IO.Path]::GetFullPath($fullPath)
            } catch { $fullPath = $rawPath }
        }
        $directory = if ([string]::IsNullOrWhiteSpace($fullPath)) { '' } else { [System.IO.Path]::GetDirectoryName($fullPath) }
        $row = [pscustomobject]@{
            Path      = $fullPath
            Directory = $directory
            MD5       = ([string]$record.Md5).ToLowerInvariant()
            SHA256    = ([string]$record.Sha256).ToLowerInvariant()
        }
        if ($row.MD5) { $byMd5[$row.MD5] = $row }
        if ($row.SHA256) { $bySha256[$row.SHA256] = $row }
        if ($directory -and (Test-Path -LiteralPath $directory -PathType Container)) { [void]$directories.Add($directory) }
        $rows.Add($row)
    }
    Write-AppLog 'INFO' 'DATABASE' ("songdata.db: $($rows.Count)譜面 / $($directories.Count)フォルダ")
    $databaseTimer.Stop()
    Add-PerformanceMetric 'songdata.db読込' $databaseTimer.Elapsed.TotalMilliseconds $rows.Count
    [pscustomobject]@{ ByMD5 = $byMd5; BySHA256 = $bySha256; Rows = $rows; Directories = @($directories); Source = $databasePath }
}

function Resolve-AbsoluteUrl([string]$BaseUrl, [string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return '' }
    try { return ([Uri]::new([Uri]$BaseUrl, $Value)).AbsoluteUri } catch { return $Value }
}

function Get-WebEncoding([string]$Name, [switch]$Strict) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $null }
    $clean = $Name.Trim().Trim('"', "'").ToLowerInvariant()
    switch -Regex ($clean) {
        '^utf-?8$' { return New-Object System.Text.UTF8Encoding($false, [bool]$Strict) }
        '^utf-?16(?:le)?$|^unicode$' { return New-Object System.Text.UnicodeEncoding($false, $false, [bool]$Strict) }
        '^utf-?16be$|^bigendianunicode$' { return New-Object System.Text.UnicodeEncoding($true, $false, [bool]$Strict) }
    }
    try {
        $providerType = [Type]::GetType('System.Text.CodePagesEncodingProvider, System.Text.Encoding.CodePages', $false)
        if ($providerType) { [System.Text.Encoding]::RegisterProvider($providerType.GetProperty('Instance').GetValue($null, $null)) }
        if ($Strict) { return [System.Text.Encoding]::GetEncoding($clean, [System.Text.EncoderFallback]::ExceptionFallback, [System.Text.DecoderFallback]::ExceptionFallback) }
        return [System.Text.Encoding]::GetEncoding($clean)
    } catch { return $null }
}

function Convert-WebBytesToText([byte[]]$Bytes, [string]$ContentType = '', [switch]$Json) {
    if (-not $Bytes -or $Bytes.Length -eq 0) { return '' }
    if ($Bytes.Length -ge 3 -and $Bytes[0] -eq 0xEF -and $Bytes[1] -eq 0xBB -and $Bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($Bytes, 3, $Bytes.Length - 3)
    }
    if ($Bytes.Length -ge 2 -and $Bytes[0] -eq 0xFF -and $Bytes[1] -eq 0xFE) {
        return [System.Text.Encoding]::Unicode.GetString($Bytes, 2, $Bytes.Length - 2)
    }
    if ($Bytes.Length -ge 2 -and $Bytes[0] -eq 0xFE -and $Bytes[1] -eq 0xFF) {
        return [System.Text.Encoding]::BigEndianUnicode.GetString($Bytes, 2, $Bytes.Length - 2)
    }
    $declared = ''
    $charsetMatch = [regex]::Match([string]$ContentType, '(?i)charset\s*=\s*["'']?([^;\s"'']+)')
    if ($charsetMatch.Success) { $declared = $charsetMatch.Groups[1].Value }
    $sampleLength = [Math]::Min($Bytes.Length, 8192)
    $asciiSample = [System.Text.Encoding]::ASCII.GetString($Bytes, 0, $sampleLength)
    $metaMatch = [regex]::Match($asciiSample, '(?i)<meta[^>]+charset\s*=\s*["'']?\s*([A-Za-z0-9._-]+)')
    if (-not $metaMatch.Success) { $metaMatch = [regex]::Match($asciiSample, '(?i)<meta[^>]+content\s*=\s*["''][^"'']*charset\s*=\s*([A-Za-z0-9._-]+)') }
    $metaCharset = if ($metaMatch.Success) { $metaMatch.Groups[1].Value } else { '' }
    foreach ($name in @($metaCharset, $(if ($declared -match '(?i)shift|sjis|932|euc|2022') { $declared } else { '' }))) {
        $encoding = Get-WebEncoding $name -Strict
        if ($encoding) { try { return $encoding.GetString($Bytes) } catch { } }
    }
    $utf8 = Get-WebEncoding 'utf-8' -Strict
    try { return $utf8.GetString($Bytes) } catch { }
    foreach ($name in @($declared, 'shift_jis', 'windows-31j', 'euc-jp', 'iso-2022-jp')) {
        $encoding = Get-WebEncoding $name -Strict
        if ($encoding) { try { return $encoding.GetString($Bytes) } catch { } }
    }
    return [System.Text.Encoding]::Default.GetString($Bytes)
}

function Invoke-WebTextResponse([string]$Url, [int]$TimeoutSec = 30, [switch]$Json) {
    $request = [System.Net.HttpWebRequest]::Create($Url)
    $request.Method = 'GET'
    $request.UserAgent = $script:WebUserAgent
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = $TimeoutSec * 1000
    $request.AllowAutoRedirect = $true
    $request.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $response = $null
    try {
        $response = [System.Net.HttpWebResponse]$request.GetResponse()
        $stream = $response.GetResponseStream()
        try {
            $memory = New-Object System.IO.MemoryStream
            try { $stream.CopyTo($memory); $bytes = $memory.ToArray() } finally { $memory.Dispose() }
        } finally { $stream.Dispose() }
        $text = Convert-WebBytesToText $bytes ([string]$response.ContentType) -Json:$Json
        return [pscustomobject]@{ Content=$text; ContentType=[string]$response.ContentType; StatusCode=[int]$response.StatusCode; ResponseUrl=$response.ResponseUri.AbsoluteUri; ByteCount=$bytes.Length }
    } finally {
        if ($response) { $response.Dispose() }
    }
}

function ConvertFrom-WebJsonResponse($Response, [string]$Description) {
    try { return ([string]$Response.Content | ConvertFrom-Json) }
    catch { throw "$Description のJSONを解析できません。文字コードまたはデータ形式を確認してください。 $($_.Exception.Message)" }
}

function Publish-DetectedTableName([string]$Name, [string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return }
    $cleanName = $Name.Trim()
    $script:TableNameCache[$Url.TrimEnd('/').ToLowerInvariant()] = $cleanName
    Write-AppLog 'INFO' 'TABLE_NAME' ("難易度表を検出: $cleanName / $Url")
    if ($script:TableNameDetectedCallback) { & $script:TableNameDetectedCallback $cleanName $Url }
}

function Get-TableHeaderUrl([string]$InputUrl) {
    Write-AppLog 'INFO' 'TABLE_PAGE' ("取得開始: $InputUrl")
    $networkTimer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $response = Invoke-WebTextResponse $InputUrl 30
    } catch {
        Write-AppLog 'ERROR' 'TABLE_PAGE' ("取得失敗: $InputUrl / $($_.Exception.Message)")
        throw '難易度表ページを取得できません。URL変更・リンク切れ・一時的な障害の可能性があります。'
    } finally {
        $networkTimer.Stop()
        Add-PerformanceMetric '難易度表ページ通信' $networkTimer.Elapsed.TotalMilliseconds 1
    }
    $contentType = [string]$response.ContentType
    $body = [string]$response.Content
    Write-AppLog 'INFO' 'TABLE_PAGE' ("取得成功: HTTP $($response.StatusCode) / $($body.Length)文字")
    if ($InputUrl -match '\.json(?:\?|$)' -or $contentType -match 'json' -or $body.TrimStart().StartsWith('{')) {
        return $response.ResponseUrl
    }
    $match = [regex]::Match($body, '<meta\s+[^>]*name\s*=\s*["'']bmstable["''][^>]*content\s*=\s*["'']([^"'']+)["'']', 'IgnoreCase')
    if (-not $match.Success) {
        $match = [regex]::Match($body, '<meta\s+[^>]*content\s*=\s*["'']([^"'']+)["''][^>]*name\s*=\s*["'']bmstable["'']', 'IgnoreCase')
    }
    if (-not $match.Success) {
        Write-AppLog 'ERROR' 'TABLE_HEADER' 'HTML内にbmstableメタ情報がありません。'
        throw 'このページから難易度表のheader.jsonを見つけられませんでした。旧形式または移転済みページの可能性があります。'
    }
    $resolved = Resolve-AbsoluteUrl $response.ResponseUrl $match.Groups[1].Value
    Write-AppLog 'INFO' 'TABLE_HEADER' ("header.json: $resolved")
    return $resolved
}

function Get-TableEntriesOnline([string]$InputUrl) {
    $headerUrl = Get-TableHeaderUrl $InputUrl
    $headerTimer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $headerResponse = Invoke-WebTextResponse $headerUrl 30 -Json
        $header = ConvertFrom-WebJsonResponse $headerResponse '難易度表header.json'
    } catch {
        Write-AppLog 'ERROR' 'TABLE_HEADER' ("header.json取得失敗: $headerUrl / $($_.Exception.Message)")
        throw '難易度表のheader.jsonを取得できません。URL変更またはリンク切れの可能性があります。'
    } finally {
        $headerTimer.Stop()
        Add-PerformanceMetric '難易度表header通信' $headerTimer.Elapsed.TotalMilliseconds 1
    }
    $dataUrlProperty = $header.PSObject.Properties['data_url']
    $dataProperty = $header.PSObject.Properties['data']
    $nameProperty = $header.PSObject.Properties['name']
    $symbolProperty = $header.PSObject.Properties['symbol']
    $dataValue = if ($dataUrlProperty -and $dataUrlProperty.Value) { [string]$dataUrlProperty.Value } elseif ($dataProperty -and $dataProperty.Value) { [string]$dataProperty.Value } else { '' }
    $detectedName = if ($nameProperty -and $nameProperty.Value) { [string]$nameProperty.Value } else { Get-FriendlyTableNameFromUrl $InputUrl }
    Publish-DetectedTableName $detectedName $InputUrl
    if ([string]::IsNullOrWhiteSpace($dataValue)) { throw 'header.jsonにdata_urlがありません。' }
    $dataUrl = Resolve-AbsoluteUrl $headerUrl $dataValue
    Write-AppLog 'INFO' 'TABLE_DATA' ("譜面JSON取得開始: $dataUrl")
    $dataTimer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $dataResponse = Invoke-WebTextResponse $dataUrl 60 -Json
        $rawData = ConvertFrom-WebJsonResponse $dataResponse '難易度表の譜面データ'
    } catch {
        Write-AppLog 'ERROR' 'TABLE_DATA' ("譜面JSON取得失敗: $dataUrl / $($_.Exception.Message)")
        throw '難易度表の譜面データを取得できません。データURL変更または一時的な障害の可能性があります。'
    } finally {
        $dataTimer.Stop()
        Add-PerformanceMetric '難易度表データ通信' $dataTimer.Elapsed.TotalMilliseconds 1
    }
    $entries = ConvertTo-TableEntryArray $rawData
    if ($entries.Count -eq 0) { throw "難易度表に譜面データがありません。`n$dataUrl" }
    Write-AppLog 'INFO' 'TABLE_DATA' ("取得成功: $($entries.Count)譜面")
    [pscustomobject]@{
        Name      = $detectedName
        Symbol    = if ($symbolProperty -and $symbolProperty.Value) { [string]$symbolProperty.Value } else { '' }
        HeaderUrl = $headerUrl
        DataUrl   = $dataUrl
        Entries   = $entries
    }
}

function Get-BundledInsaneTable([string]$InputUrl) {
    $headerPath = Join-Path $script:BundledTableDir 'insane1-header.json'
    $dataPath = Join-Path $script:BundledTableDir 'insane1-data.json'
    if (-not (Test-Path -LiteralPath $headerPath -PathType Leaf) -or -not (Test-Path -LiteralPath $dataPath -PathType Leaf)) { return $null }
    $header = Get-Content -LiteralPath $headerPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $rawData = Get-Content -LiteralPath $dataPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $entries = ConvertTo-TableEntryArray $rawData
    $nameProperty = $header.PSObject.Properties['name']
    $symbolProperty = $header.PSObject.Properties['symbol']
    Write-AppLog 'INFO' 'TABLE_CACHE' ("同梱済み発狂BMS表を読み込み: $($entries.Count)譜面")
    return [pscustomobject]@{
        Name = if ($nameProperty -and $nameProperty.Value) { [string]$nameProperty.Value } else { '発狂BMS難易度表' }
        Symbol = if ($symbolProperty -and $symbolProperty.Value) { [string]$symbolProperty.Value } else { '★' }
        HeaderUrl = 'https://darksabun.club/table/archive/insane1/header.json'
        DataUrl = 'https://darksabun.club/table/archive/insane1/data.json'
        Entries = $entries
        IsBundledCache = $true
    }
}

function Get-TableEntries([string]$InputUrl) {
    if ($InputUrl -match 'darksabun\.(?:club|github\.io)/table/archive/insane1') {
        $bundledData = Join-Path $script:BundledTableDir 'insane1-data.json'
        if (Test-Path -LiteralPath $bundledData -PathType Leaf) {
            $age = (Get-Date) - (Get-Item -LiteralPath $bundledData).LastWriteTime
            if ($age.TotalDays -le 7) {
                Write-AppLog 'INFO' 'TABLE_CACHE' '7日以内に確認した同梱済み発狂BMS表を使用します。'
                return Get-BundledInsaneTable $InputUrl
            }
        }
    }
    try {
        return Get-TableEntriesOnline $InputUrl
    } catch {
        $originalError = $_.Exception.Message
        if ($InputUrl -match 'darksabun\.(?:club|github\.io)/table/archive/insane1') {
            $bundled = Get-BundledInsaneTable $InputUrl
            if ($bundled) { return $bundled }
        }
        throw $originalError
    }
}

function Get-FriendlyTableNameFromUrl([string]$InputUrl) {
    try {
        $uri = [Uri]$InputUrl
        $segments = @($uri.AbsolutePath.Trim('/') -split '/' | Where-Object { $_ })
        $leaf = if ($segments.Count -gt 0) { [Uri]::UnescapeDataString([string]$segments[-1]) } else { '' }
        if ($leaf -match '^(?i)(?:table|header|data)(?:\.json|\.html?)?$' -and $segments.Count -gt 1) { $leaf = [Uri]::UnescapeDataString([string]$segments[-2]) }
        if ([string]::IsNullOrWhiteSpace($leaf)) { return $uri.Host }
        return "$leaf ($($uri.Host))"
    } catch { return '追加した難易度表' }
}

function Get-TableDisplayNameOnline([string]$InputUrl) {
    $cacheKey = $InputUrl.TrimEnd('/').ToLowerInvariant()
    if ($script:TableNameCache.ContainsKey($cacheKey)) { return [string]$script:TableNameCache[$cacheKey] }
    $fallback = Get-FriendlyTableNameFromUrl $InputUrl
    try {
        $headerUrl = Get-TableHeaderUrl $InputUrl
        $headerResponse = Invoke-WebTextResponse $headerUrl 20 -Json
        $header = ConvertFrom-WebJsonResponse $headerResponse '難易度表header.json'
        $nameProperty = $header.PSObject.Properties['name']
        $name = if ($nameProperty -and -not [string]::IsNullOrWhiteSpace([string]$nameProperty.Value)) { ([string]$nameProperty.Value).Trim() } else { $fallback }
        $script:TableNameCache[$cacheKey] = $name
        Publish-DetectedTableName $name $InputUrl
        Write-AppLog 'INFO' 'TABLE_NAME' ("難易度表名を取得: $name / $InputUrl")
        return $name
    } catch {
        Write-AppLog 'WARN' 'TABLE_NAME' ("難易度表名を取得できないためURLから作成: $fallback / $InputUrl / $($_.Exception.Message)")
        $script:TableNameCache[$cacheKey] = $fallback
        return $fallback
    }
}

function ConvertTo-TableEntryArray($RawData) {
    if ($null -eq $RawData) { return @() }

    # Most tables return a JSON array. Some newer table generators wrap that
    # array in a named property, so unwrap the common shapes as well.
    foreach ($propertyName in @('data', 'entries', 'songs', 'scores', 'charts', 'body', 'items')) {
        $property = $RawData.PSObject.Properties[$propertyName]
        if ($property -and $null -ne $property.Value) {
            $candidate = @($property.Value)
            if ($candidate.Count -gt 0) { return $candidate }
        }
    }

    if ($RawData -is [System.Array] -or $RawData -is [System.Collections.IList]) {
        return @($RawData)
    }
    return @($RawData)
}

function Get-EntryHash($Entry, [string]$Name) {
    $prop = $Entry.PSObject.Properties[$Name]
    if ($null -eq $prop -or $null -eq $prop.Value) { return '' }
    return ([string]$prop.Value).Trim().ToLowerInvariant()
}

function Get-EntryText($Entry, [string]$Name, [string]$Fallback = '') {
    $prop = $Entry.PSObject.Properties[$Name]
    if ($null -eq $prop -or $null -eq $prop.Value -or [string]::IsNullOrWhiteSpace([string]$prop.Value)) { return $Fallback }
    return [string]$prop.Value
}

function Test-EntryInIndex($Entry, $Index) {
    $md5 = Get-EntryHash $Entry 'md5'
    $sha = Get-EntryHash $Entry 'sha256'
    return (($md5 -ne '') -and $Index.ByMD5.ContainsKey($md5)) -or (($sha -ne '') -and $Index.BySHA256.ContainsKey($sha))
}

function Test-EntryInstalled($Entry, $Index) {
    return (Test-EntryInIndex $Entry $Index) -or (Test-EntryRecordedInstalled $Entry)
}

function Get-EntryDownloadUrl($Entry, [string]$PreferredProperty = '') {
    $propertyNames = if ([string]::IsNullOrWhiteSpace($PreferredProperty)) { @('url_diff', 'url') } else { @($PreferredProperty) }
    foreach ($name in $propertyNames) {
        $prop = $Entry.PSObject.Properties[$name]
        if ($prop -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value)) {
            $value = [string]$prop.Value
            if ($value -match '\s') { $value = ($value -split '\s+')[0] }
            return $value
        }
    }
    return ''
}

function Get-SafeFileName([string]$Value) {
    $result = $Value
    foreach ($char in [System.IO.Path]::GetInvalidFileNameChars()) { $result = $result.Replace([string]$char, '_') }
    $result = $result.Trim().TrimEnd('.')
    if ($result.Length -gt 100) { $result = $result.Substring(0, 100) }
    if ([string]::IsNullOrWhiteSpace($result)) { return 'download' }
    return $result
}

function Expand-ZipSafely([string]$ZipPath, [string]$Destination) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Directory]::CreateDirectory($Destination) | Out-Null
    $root = [System.IO.Path]::GetFullPath($Destination).TrimEnd('\') + '\'
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try {
        $entryNumber = 0
        $entryTotal = $zip.Entries.Count
        foreach ($entry in $zip.Entries) {
            $entryNumber++
            if (($entryNumber % 25) -eq 0 -or $entryNumber -eq 1 -or $entryNumber -eq $entryTotal) {
                Invoke-UiPulse
                Assert-NotCancelled
                Report-OperationProgress 'ZIP展開中' $entryNumber $entryTotal
            }
            if ([string]::IsNullOrEmpty($entry.FullName)) { continue }
            $target = [System.IO.Path]::GetFullPath((Join-Path $Destination $entry.FullName))
            if (-not $target.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw '安全でないパスを含むZIPのため展開を中止しました。'
            }
            if ($entry.FullName.EndsWith('/')) {
                [System.IO.Directory]::CreateDirectory($target) | Out-Null
            } else {
                [System.IO.Directory]::CreateDirectory((Split-Path -Parent $target)) | Out-Null
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $false)
            }
        }
    } finally { $zip.Dispose() }
}

function Invoke-WindowsArchiveTool([string]$Arguments) {
    $tarCommand = Get-Command 'tar.exe' -ErrorAction SilentlyContinue
    if (-not $tarCommand) {
        throw 'Windowsの書庫展開機能が見つかりません。'
    }
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $tarCommand.Source
    $startInfo.Arguments = $Arguments
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) { throw '書庫展開機能を起動できませんでした。' }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        while (-not $process.WaitForExit(100)) {
            Invoke-UiPulse
            if ($script:CancelRequested) {
                try { $process.Kill() } catch { }
                throw 'ユーザー操作で中止しました。'
            }
        }
        $stdout = $stdoutTask.Result
        $stderr = $stderrTask.Result
        if ($process.ExitCode -ne 0) {
            $detail = if ([string]::IsNullOrWhiteSpace($stderr)) { $stdout } else { $stderr }
            throw ('この書庫を展開できませんでした。' + $(if ($detail) { ' ' + $detail.Trim() } else { '' }))
        }
        return $stdout
    } finally {
        $process.Dispose()
    }
}

function Quote-NativePath([string]$Path) {
    # Windowsのファイル名には二重引用符を使えないため、この形で安全に渡せます。
    return '"' + $Path + '"'
}

function Get-SevenZipPath {
    $candidates = New-Object System.Collections.Generic.List[string]
    $bundled = Join-Path $script:AppDir 'tools\7zip\7z.exe'
    [void]$candidates.Add($bundled)
    $programFiles = [Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFiles)
    if (-not [string]::IsNullOrWhiteSpace($programFiles)) { [void]$candidates.Add((Join-Path $programFiles '7-Zip\7z.exe')) }
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if (-not [string]::IsNullOrWhiteSpace($programFilesX86)) { [void]$candidates.Add((Join-Path $programFilesX86 '7-Zip\7z.exe')) }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $command = Get-Command '7z.exe' -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    return ''
}

function Invoke-SevenZip([string]$SevenZipPath, [string]$Arguments, [int]$TimeoutSeconds = 120) {
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $SevenZipPath
    $startInfo.Arguments = $Arguments
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.RedirectStandardInput = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) { throw '7-Zipを起動できませんでした。' }
        # パスワード付き書庫などが、非表示の入力待ちで停止しないよう標準入力を閉じます。
        $process.StandardInput.Close()
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $waitTimer = [System.Diagnostics.Stopwatch]::StartNew()
        while (-not $process.WaitForExit(100)) {
            Invoke-UiPulse
            if ($script:CancelRequested) {
                try { $process.Kill() } catch { }
                throw 'ユーザー操作で中止しました。'
            }
            if ($TimeoutSeconds -gt 0 -and $waitTimer.Elapsed.TotalSeconds -ge $TimeoutSeconds) {
                try { $process.Kill() } catch { }
                throw "7-Zipの処理が$TimeoutSeconds 秒以内に完了しなかったため打ち切りました。"
            }
        }
        $stdout = $stdoutTask.Result
        $stderr = $stderrTask.Result
        if ($process.ExitCode -ne 0) {
            $detail = if ([string]::IsNullOrWhiteSpace($stderr)) { $stdout } else { $stderr }
            throw ('7-Zipでもこの書庫を展開できませんでした。' + $(if ($detail) { ' ' + $detail.Trim() } else { '' }))
        }
        return $stdout
    } finally { $process.Dispose() }
}

function Get-GcaExtractorPath {
    $helper = Join-Path $script:AppDir 'tools\ungca\vendor\GcaExtractor.exe'
    $library = Join-Path $script:AppDir 'tools\ungca\vendor\UnGCA32.dll'
    if ((Test-Path -LiteralPath $helper -PathType Leaf) -and (Test-Path -LiteralPath $library -PathType Leaf)) { return $helper }
    return ''
}

function Invoke-GcaExtractor([string]$HelperPath, [string]$Arguments, [int]$TimeoutSeconds = 120) {
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $HelperPath
    $startInfo.Arguments = $Arguments
    $startInfo.WorkingDirectory = Split-Path -Parent $HelperPath
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.RedirectStandardInput = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    try {
        if (-not $process.Start()) { throw 'GCA展開補助を起動できませんでした。' }
        $process.StandardInput.Close()
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $timer = [System.Diagnostics.Stopwatch]::StartNew()
        while (-not $process.WaitForExit(100)) {
            Invoke-UiPulse
            if ($script:CancelRequested) {
                try { $process.Kill() } catch { }
                throw 'ユーザー操作で中止しました。'
            }
            if ($TimeoutSeconds -gt 0 -and $timer.Elapsed.TotalSeconds -ge $TimeoutSeconds) {
                try { $process.Kill() } catch { }
                throw "GCA展開が$TimeoutSeconds 秒以内に完了しなかったため打ち切りました。"
            }
        }
        return [pscustomobject]@{
            ExitCode = $process.ExitCode
            Output = $stdoutTask.Result
            Error = $stderrTask.Result
        }
    } finally { $process.Dispose() }
}

function Test-IsLikelyGcaArchive([string]$Path) {
    if ([System.IO.Path]::GetExtension($Path).Equals('.gca', [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    $stream = [System.IO.File]::OpenRead($Path)
    try {
        if ($stream.Length -lt 2 -or $stream.Length -gt 67108864) { return $false }
        $length = [int][Math]::Min(1048576, $stream.Length)
        $bytes = New-Object byte[] $length
        $read = $stream.Read($bytes, 0, $length)
    } finally { $stream.Dispose() }
    if ($read -lt 2 -or $bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) { return $false }
    $text = [System.Text.Encoding]::GetEncoding(28591).GetString($bytes, 0, $read)
    return $text.IndexOf('GCA SelfExtractor', [System.StringComparison]::OrdinalIgnoreCase) -ge 0
}

function Expand-GcaArchiveSafely([string]$ArchivePath, [string]$Destination) {
    if (-not (Test-IsLikelyGcaArchive $ArchivePath)) { return $false }
    $helper = Get-GcaExtractorPath
    if ([string]::IsNullOrWhiteSpace($helper)) {
        throw '古いGCA形式ですが、GCA展開補助が見つかりません。'
    }

    $fullArchive = [System.IO.Path]::GetFullPath($ArchivePath)
    $manifest = Invoke-GcaExtractor $helper ('manifest ' + (Quote-NativePath $fullArchive)) 30
    if ($manifest.ExitCode -ne 0) {
        throw 'GCA書庫の内容を安全に確認できませんでした。'
    }
    $entryLines = @($manifest.Output -split "`r?`n" | Where-Object { $_.StartsWith('ENTRY64=', [System.StringComparison]::Ordinal) })
    if ($entryLines.Count -eq 0 -or $entryLines.Count -gt 20000) { throw 'GCA書庫の内容件数が不正です。' }
    foreach ($line in $entryLines) {
        try {
            $rawName = [Convert]::FromBase64String($line.Substring(8))
            $entry = [System.Text.Encoding]::GetEncoding(932).GetString($rawName)
        } catch { throw 'GCA書庫内のファイル名を確認できませんでした。' }
        $normalized = $entry.Replace('\', '/')
        if ([string]::IsNullOrWhiteSpace($normalized) -or $normalized.StartsWith('/') -or $normalized -match '^[A-Za-z]:' -or $normalized -match '(^|/)\.\.(/|$)' -or $normalized.Contains(':')) {
            throw '安全でない保存先を含むGCA書庫のため展開を中止しました。'
        }
    }

    $candidateDestination = $Destination + '-gca-' + [guid]::NewGuid().ToString('N').Substring(0, 6)
    try {
        [System.IO.Directory]::CreateDirectory($candidateDestination) | Out-Null
        $result = Invoke-GcaExtractor $helper ('extract ' + (Quote-NativePath $fullArchive) + ' ' + (Quote-NativePath ([System.IO.Path]::GetFullPath($candidateDestination)))) 120
        if ($result.ExitCode -ne 0) {
            $detail = if ($result.Error) { $result.Error.Trim() } else { $result.Output.Trim() }
            throw ('GCA書庫を展開できませんでした。' + $(if ($detail) { ' ' + $detail } else { '' }))
        }
        foreach ($item in @(Get-ChildItem -LiteralPath $candidateDestination -Recurse -Force -ErrorAction Stop)) {
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'リンクを含むGCA書庫のため、安全上の理由で展開を中止しました。'
            }
        }
        if (@(Get-ChildItem -LiteralPath $candidateDestination -Recurse -File -ErrorAction Stop).Count -eq 0) { throw 'GCA書庫の展開結果が空です。' }
        if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Recurse -Force -ErrorAction SilentlyContinue }
        Move-Item -LiteralPath $candidateDestination -Destination $Destination
        Write-AppLog 'INFO' 'GCA_ARCHIVE' ("古いGCA自己解凍書庫を実行せず安全に展開: $ArchivePath")
        return $true
    } finally {
        if (Test-Path -LiteralPath $candidateDestination) { Remove-Item -LiteralPath $candidateDestination -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Expand-WithSevenZipSafely([string]$SevenZipPath, [string]$ArchivePath, [string]$Destination) {
    [System.IO.Directory]::CreateDirectory($Destination) | Out-Null
    $quotedArchive = Quote-NativePath ([System.IO.Path]::GetFullPath($ArchivePath))
    $nonInteractivePassword = '-p__BMS_FETCHER_NO_PASSWORD__'
    $listing = Invoke-SevenZip $SevenZipPath ('l -slt -ba ' + $nonInteractivePassword + ' -- ' + $quotedArchive)
    if ($listing -match '(?im)^(?:Symbolic Link|Hard Link)\s*=') { throw 'リンクを含む書庫のため、安全上の理由で展開を中止しました。' }
    $entryMatches = [regex]::Matches($listing, '(?im)^Path\s*=\s*(.+?)\s*$')
    if ($entryMatches.Count -eq 0) { throw '7-Zipで書庫の中身を確認できませんでした。' }
    foreach ($entryMatch in $entryMatches) {
        $entry = $entryMatch.Groups[1].Value.Trim()
        $normalized = $entry.Replace('\', '/')
        if ($normalized.StartsWith('/') -or $normalized -match '^[A-Za-z]:' -or $normalized -match '(^|/)\.\.(/|$)' -or $normalized.Contains(':')) {
            throw '安全でない保存先を含む書庫のため展開を中止しました。'
        }
    }
    $quotedDestination = Quote-NativePath ([System.IO.Path]::GetFullPath($Destination))
    [void](Invoke-SevenZip $SevenZipPath ('x -y -bd -bb0 ' + $nonInteractivePassword + ' -o' + $quotedDestination + ' -- ' + $quotedArchive))
    foreach ($item in @(Get-ChildItem -LiteralPath $Destination -Recurse -Force -ErrorAction Stop)) {
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'リンクを含む書庫のため、安全上の理由で展開を中止しました。'
        }
    }
}

function Expand-OtherArchiveSafely([string]$ArchivePath, [string]$Destination) {
    try {
        [System.IO.Directory]::CreateDirectory($Destination) | Out-Null
        $quotedArchive = Quote-NativePath ([System.IO.Path]::GetFullPath($ArchivePath))
        $listing = Invoke-WindowsArchiveTool ('-tf ' + $quotedArchive)
        $entries = @($listing -split "`r?`n" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if ($entries.Count -eq 0) { throw '書庫の中身が空です。' }
        foreach ($entry in $entries) {
            $normalized = $entry.Replace('\', '/')
            if ($normalized.StartsWith('/') -or $normalized -match '^[A-Za-z]:' -or $normalized -match '(^|/)\.\.(/|$)' -or $normalized.Contains(':')) {
                throw '安全でない保存先を含む書庫のため展開を中止しました。'
            }
        }
        $verbose = Invoke-WindowsArchiveTool ('-tvf ' + $quotedArchive)
        foreach ($line in @($verbose -split "`r?`n")) {
            if ($line -match '^[lh]') { throw 'リンクを含む書庫のため、安全上の理由で展開を中止しました。' }
        }
        $quotedDestination = Quote-NativePath ([System.IO.Path]::GetFullPath($Destination))
        [void](Invoke-WindowsArchiveTool ('-xf ' + $quotedArchive + ' -C ' + $quotedDestination))
        foreach ($item in @(Get-ChildItem -LiteralPath $Destination -Recurse -Force -ErrorAction Stop)) {
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'リンクを含む書庫のため、安全上の理由で展開を中止しました。'
            }
        }
        return
    } catch {
        if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw }
        $windowsError = $_.Exception.Message
        $sevenZipPath = Get-SevenZipPath
        if ([string]::IsNullOrWhiteSpace($sevenZipPath)) {
            throw ($windowsError + ' 7-Zipが見つかりません。RAR等を自動展開するには7-Zipをインストールしてから再試行してください。')
        }
        Write-AppLog 'INFO' 'ARCHIVE' ("Windows標準展開に失敗したため7-Zipで再試行: $sevenZipPath / $ArchivePath")
        Expand-WithSevenZipSafely $sevenZipPath $ArchivePath $Destination
    }
}

function Expand-EmbeddedArchiveFromExecutable([string]$ExecutablePath, [string]$Destination) {
    $info = Get-Item -LiteralPath $ExecutablePath -ErrorAction Stop
    # BMSで使われる古い自己解凍書庫を対象にし、巨大な実行ファイルの全読込は避けます。
    if ($info.Length -lt 8 -or $info.Length -gt 67108864) { return $false }
    $bytes = [System.IO.File]::ReadAllBytes($info.FullName)
    if ($bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) { return $false }
    $binaryText = [System.Text.Encoding]::GetEncoding(28591).GetString($bytes)
    $signatures = @(
        [pscustomobject]@{ Text=([string][char]0x50 + [char]0x4B + [char]0x03 + [char]0x04); Extension='.zip'; Adjustment=0 },
        [pscustomobject]@{ Text=([string][char]0x52 + [char]0x61 + [char]0x72 + [char]0x21 + [char]0x1A + [char]0x07 + [char]0x00); Extension='.rar'; Adjustment=0 },
        [pscustomobject]@{ Text=([string][char]0x52 + [char]0x61 + [char]0x72 + [char]0x21 + [char]0x1A + [char]0x07 + [char]0x01 + [char]0x00); Extension='.rar'; Adjustment=0 },
        [pscustomobject]@{ Text=([string][char]0x37 + [char]0x7A + [char]0xBC + [char]0xAF + [char]0x27 + [char]0x1C); Extension='.7z'; Adjustment=0 }
    )
    $candidates = New-Object System.Collections.Generic.List[object]
    $seenOffsets = New-Object System.Collections.Generic.HashSet[long]
    foreach ($signature in $signatures) {
        $offset = $binaryText.IndexOf([string]$signature.Text, 1, [System.StringComparison]::Ordinal)
        while ($offset -gt 0 -and $candidates.Count -lt 20) {
            if ($seenOffsets.Add([long]$offset)) { $candidates.Add([pscustomobject]@{ Offset=[long]$offset; Extension=[string]$signature.Extension }) }
            $offset = $binaryText.IndexOf([string]$signature.Text, $offset + 1, [System.StringComparison]::Ordinal)
        }
    }
    $lhaOffset = $binaryText.IndexOf('-lh', 2, [System.StringComparison]::OrdinalIgnoreCase)
    while ($lhaOffset -ge 2 -and $candidates.Count -lt 20) {
        if (($lhaOffset + 4) -lt $binaryText.Length) {
            $method = $binaryText.Substring($lhaOffset, 5)
            if ($method -match '^-lh[0-9d]-$') {
                $archiveOffset = [long]($lhaOffset - 2)
                if ($seenOffsets.Add($archiveOffset)) { $candidates.Add([pscustomobject]@{ Offset=$archiveOffset; Extension='.lzh' }) }
            }
        }
        $lhaOffset = $binaryText.IndexOf('-lh', $lhaOffset + 1, [System.StringComparison]::OrdinalIgnoreCase)
    }
    if ($candidates.Count -eq 0) { return $false }
    $sevenZipPath = Get-SevenZipPath
    if (-not $sevenZipPath) { return $false }
    foreach ($candidate in @($candidates | Sort-Object Offset)) {
        $embeddedPath = Join-Path ([System.IO.Path]::GetTempPath()) ('bms-embedded-' + [guid]::NewGuid().ToString('N') + $candidate.Extension)
        $candidateDestination = $Destination + '-embedded-' + [guid]::NewGuid().ToString('N').Substring(0, 6)
        try {
            $sourceStream = [System.IO.File]::OpenRead($info.FullName)
            $targetStream = [System.IO.File]::Create($embeddedPath)
            try {
                $sourceStream.Position = [long]$candidate.Offset
                $sourceStream.CopyTo($targetStream)
            } finally {
                $targetStream.Dispose()
                $sourceStream.Dispose()
            }
            Expand-WithSevenZipSafely $sevenZipPath $embeddedPath $candidateDestination
            if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Recurse -Force -ErrorAction SilentlyContinue }
            Move-Item -LiteralPath $candidateDestination -Destination $Destination
            Write-AppLog 'INFO' 'EMBEDDED_ARCHIVE' ("自己解凍EXE内の書庫を安全に展開: offset=$($candidate.Offset) / $ExecutablePath")
            return $true
        } catch {
            Write-AppLog 'INFO' 'EMBEDDED_ARCHIVE' ("埋め込み書庫候補は展開不可: offset=$($candidate.Offset) / $($_.Exception.Message)")
        } finally {
            if (Test-Path -LiteralPath $embeddedPath) { Remove-Item -LiteralPath $embeddedPath -Force -ErrorAction SilentlyContinue }
            if (Test-Path -LiteralPath $candidateDestination) { Remove-Item -LiteralPath $candidateDestination -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }
    return $false
}

function Expand-SingleDownloadedFile([string]$DownloadedPath, [string]$Destination) {
    $expandTimer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
    $extension = [System.IO.Path]::GetExtension($DownloadedPath).ToLowerInvariant()
    $stream = [System.IO.File]::OpenRead($DownloadedPath)
    try {
        $signature = New-Object byte[] 4
        $read = $stream.Read($signature, 0, $signature.Length)
    } finally {
        $stream.Dispose()
    }
    $isZip = $read -ge 4 -and $signature[0] -eq 0x50 -and $signature[1] -eq 0x4B -and
             (($signature[2] -eq 0x03 -and $signature[3] -eq 0x04) -or
              ($signature[2] -eq 0x05 -and $signature[3] -eq 0x06) -or
              ($signature[2] -eq 0x07 -and $signature[3] -eq 0x08))
    if ($extension -eq '.zip' -or $isZip) {
        Expand-ZipSafely $DownloadedPath $Destination
        return
    }
    try {
        Expand-OtherArchiveSafely $DownloadedPath $Destination
    } catch {
        if (Expand-GcaArchiveSafely $DownloadedPath $Destination) { return }
        if (Expand-EmbeddedArchiveFromExecutable $DownloadedPath $Destination) { return }
        throw
    }
    } finally {
        $expandTimer.Stop()
        Add-PerformanceMetric 'アーカイブ展開' $expandTimer.Elapsed.TotalMilliseconds 1
        Add-PerformanceCounter 'アーカイブ展開回数'
    }
}

function Expand-NestedArchivesSafely([string]$Root, [int]$MaximumDepth = 3, [int]$MaximumArchives = 500, [int]$MaximumFiles = 20000) {
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { return 0 }
    $archiveExtensions = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($extension in @('.zip','.rar','.7z','.lzh','.lha','.gca','.tar','.gz','.bz2','.xz')) { [void]$archiveExtensions.Add($extension) }
    $processed = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $expanded = 0
    $fileCount = @(Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue).Count
    for ($depth = 1; $depth -le $MaximumDepth; $depth++) {
        $candidates = @(Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
            $archiveExtensions.Contains($_.Extension) -and -not $processed.Contains($_.FullName)
        })
        if ($candidates.Count -eq 0) { break }
        foreach ($archive in $candidates) {
            Assert-NotCancelled
            [void]$processed.Add($archive.FullName)
            if ($processed.Count -gt $MaximumArchives) {
                Write-AppLog 'WARN' 'NESTED_ARCHIVE' ("入れ子書庫が$MaximumArchives 個を超えたため、残りの展開を省略して検出済みの譜面を確認します。")
                return $expanded
            }
            $destinationName = '__展開_' + (Get-SafeFileName $archive.BaseName) + '_' + $processed.Count
            $nestedDestination = Join-Path $archive.DirectoryName $destinationName
            try {
                if (Test-DownloadedFileIsHtml $archive.FullName) { throw '書庫ではなくHTMLです。' }
                Expand-SingleDownloadedFile $archive.FullName $nestedDestination
                $expanded++
                $fileCount += @(Get-ChildItem -LiteralPath $nestedDestination -Recurse -File -ErrorAction SilentlyContinue).Count
                Write-AppLog 'INFO' 'NESTED_ARCHIVE' ("入れ子書庫を展開: 深さ $depth / $($archive.FullName)")
            } catch {
                if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw }
                if (Test-Path -LiteralPath $nestedDestination) { Remove-Item -LiteralPath $nestedDestination -Recurse -Force -ErrorAction SilentlyContinue }
                Write-AppLog 'WARN' 'NESTED_ARCHIVE' ("入れ子書庫を展開できないため続行: $($archive.FullName) / $($_.Exception.Message)")
            }
            if ($fileCount -gt $MaximumFiles) { throw "展開後のファイルが$MaximumFiles 個を超えたため、安全のため処理を中止しました。" }
        }
    }
    if ($expanded -gt 0) { Write-AppLog 'INFO' 'NESTED_ARCHIVE' ("入れ子書庫の展開完了: $expanded 件") }
    return $expanded
}

function Expand-DownloadedFile([string]$DownloadedPath, [string]$Destination) {
    Expand-SingleDownloadedFile $DownloadedPath $Destination
    [void](Expand-NestedArchivesSafely $Destination)
}

function Get-DownloadedChartExtension([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return '' }
    $knownExtension = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
    if ($script:ChartExtensions -contains $knownExtension) { return $knownExtension }
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        try {
            $length = [Math]::Min(65536, [int]$stream.Length)
            if ($length -le 0) { return '' }
            $bytes = New-Object byte[] $length
            [void]$stream.Read($bytes, 0, $length)
        } finally {
            $stream.Dispose()
        }
        if ($bytes.Length -ge 4) {
            if (($bytes[0] -eq 0x50 -and $bytes[1] -eq 0x4B) -or
                ($bytes[0] -eq 0x52 -and $bytes[1] -eq 0x61 -and $bytes[2] -eq 0x72 -and $bytes[3] -eq 0x21) -or
                ($bytes[0] -eq 0x37 -and $bytes[1] -eq 0x7A -and $bytes[2] -eq 0xBC -and $bytes[3] -eq 0xAF)) { return '' }
        }
        $sample = $null
        foreach ($encodingName in @('utf-8', 'shift_jis', 'windows-31j')) {
            try {
                $sample = [System.Text.Encoding]::GetEncoding($encodingName).GetString($bytes)
                if ($sample) { break }
            } catch { }
        }
        if ([string]::IsNullOrWhiteSpace($sample)) { return '' }
        if ($sample -match '(?is)^\s*\{' -and $sample -match '(?i)"info"\s*:' -and $sample -match '(?i)"sound_channels"\s*:') { return '.bmson' }
        if ($sample -match '(?im)^\s*#(?:PLAYER|GENRE|TITLE|ARTIST|BPM|PLAYLEVEL|WAV[0-9A-Za-z]{2}|BMP[0-9A-Za-z]{2})\s+') { return '.bms' }
    } catch { }
    return ''
}

function Copy-DownloadedChartToFolder([string]$DownloadedPath, [string]$Destination) {
    $chartExtension = Get-DownloadedChartExtension $DownloadedPath
    if ([string]::IsNullOrWhiteSpace($chartExtension)) { throw 'ダウンロードしたファイルをBMS譜面として確認できませんでした。' }
    $leaf = [System.IO.Path]::GetFileName($DownloadedPath)
    if (-not ($script:ChartExtensions -contains [System.IO.Path]::GetExtension($leaf).ToLowerInvariant())) { $leaf += $chartExtension }
    $target = Join-Path $Destination (Get-SafeFileName $leaf)
    Copy-Item -LiteralPath $DownloadedPath -Destination $target
    return $target
}

function Test-DownloadedFileIsHtml([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    try {
        $length = [Math]::Min(2048, [int]$stream.Length)
        if ($length -le 0) { return $false }
        $bytes = New-Object byte[] $length
        [void]$stream.Read($bytes, 0, $length)
        $sample = [System.Text.Encoding]::ASCII.GetString($bytes)
        return $sample -match '(?is)<\s*(?:!doctype\s+html|html|head|title|body)\b'
    } finally {
        $stream.Dispose()
    }
}

function Read-ChartText([string]$Path) {
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        $providerType = [Type]::GetType('System.Text.CodePagesEncodingProvider, System.Text.Encoding.CodePages', $false)
        if ($providerType) {
            [System.Text.Encoding]::RegisterProvider($providerType.GetProperty('Instance').GetValue($null, $null))
        }
        $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
        try { return $strictUtf8.GetString($bytes) } catch { }
        foreach ($name in @('shift_jis', 'windows-31j')) {
            try {
                $encoding = [System.Text.Encoding]::GetEncoding($name, [System.Text.EncoderFallback]::ExceptionFallback, [System.Text.DecoderFallback]::ExceptionFallback)
                return $encoding.GetString($bytes)
            } catch { }
        }
        return [System.Text.Encoding]::Default.GetString($bytes)
    } finally {
        $timer.Stop()
        Add-PerformanceMetric 'BMS内容読込・文字コード解析' $timer.Elapsed.TotalMilliseconds 1
        Add-PerformanceCounter 'BMS内容読込回数'
    }
}

function Get-ChartReferences([string]$ChartPath) {
    if ([System.IO.Path]::GetExtension($ChartPath).ToLowerInvariant() -eq '.bmson') {
        try {
            $json = Get-Content -LiteralPath $ChartPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $bmsonNames = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($channel in @($json.sound_channels)) {
                if ($channel.name) { [void]$bmsonNames.Add([System.IO.Path]::GetFileName([string]$channel.name)) }
            }
            if ($json.bga -and $json.bga.bga_header) {
                foreach ($item in @($json.bga.bga_header)) {
                    if ($item.name) { [void]$bmsonNames.Add([System.IO.Path]::GetFileName([string]$item.name)) }
                }
            }
            return @($bmsonNames)
        } catch {
            Write-AppLog 'WARN' 'BMSON' ("参照素材を解析できません: $ChartPath / $($_.Exception.Message)")
            return @()
        }
    }
    $text = Read-ChartText $ChartPath
    $names = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($line in ($text -split "`r?`n")) {
        if ($line -match '^\s*#(?:WAV|BMP|BGA)[0-9A-Za-z]{2}\s+(.+?)\s*$') {
            $leaf = [System.IO.Path]::GetFileName($matches[1].Trim('"'))
            if ($leaf) { [void]$names.Add($leaf) }
        }
    }
    return @($names)
}

function Get-ChartMetadata([string]$ChartPath) {
    if ([System.IO.Path]::GetExtension($ChartPath).ToLowerInvariant() -eq '.bmson') {
        try {
            $json = Get-Content -LiteralPath $ChartPath -Raw -Encoding UTF8 | ConvertFrom-Json
            return [pscustomobject]@{ Title = [string]$json.info.title; Artist = [string]$json.info.artist }
        } catch { return [pscustomobject]@{ Title = ''; Artist = '' } }
    }
    $text = Read-ChartText $ChartPath
    $titleMatch = [regex]::Match($text, '(?im)^\s*#TITLE\s+(.+?)\s*$')
    $artistMatch = [regex]::Match($text, '(?im)^\s*#ARTIST\s+(.+?)\s*$')
    return [pscustomobject]@{ Title = $titleMatch.Groups[1].Value.Trim(); Artist = $artistMatch.Groups[1].Value.Trim() }
}

function ConvertTo-MatchText([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return '' }
    return ([regex]::Replace($Value.ToLowerInvariant(), '[^\p{L}\p{Nd}]', ''))
}

function Get-EntryBaseTitle([object]$Entry) {
    $title = Get-EntryText $Entry 'title' ''
    if ([string]::IsNullOrWhiteSpace($title)) { return '' }
    $withoutBracketDifficulty = [regex]::Replace($title, '\s*[\[\(（【][^\]\)）】]{1,60}[\]\)）】]\s*$', '').Trim()
    if ($withoutBracketDifficulty.Length -ge 4) { return $withoutBracketDifficulty }
    return $title.Trim()
}

function Test-EntryTitleMatchesCandidate([object]$Entry, [string]$CandidateTitle) {
    if ([string]::IsNullOrWhiteSpace($CandidateTitle)) { return $false }
    $targetKey = ConvertTo-MatchText (Get-EntryBaseTitle $Entry)
    $candidateBase = [regex]::Replace($CandidateTitle, '\s*[\[\(（【][^\]\)）】]{1,60}[\]\)）】]\s*$', '').Trim()
    $candidateKey = ConvertTo-MatchText $candidateBase
    if (-not $targetKey -or -not $candidateKey) { return $false }
    if ($targetKey -eq $candidateKey) { return $true }
    $shorterLength = [Math]::Min($targetKey.Length, $candidateKey.Length)
    if ($shorterLength -ge 4 -and ($targetKey.Contains($candidateKey) -or $candidateKey.Contains($targetKey))) { return $true }
    return $false
}

function Test-EntryMatchesBaseFolderTitle([object]$Entry, [string]$Folder) {
    if ([string]::IsNullOrWhiteSpace($Folder) -or -not (Test-Path -LiteralPath $Folder -PathType Container)) { return $false }
    if (Test-EntryTitleMatchesCandidate $Entry ([System.IO.Path]::GetFileName($Folder))) { return $true }
    foreach ($chart in @(Get-ChartFiles $Folder | Select-Object -First 50)) {
        $metadata = Get-ChartMetadata $chart.FullName
        if (Test-EntryTitleMatchesCandidate $Entry ([string]$metadata.Title)) { return $true }
    }
    return $false
}

function Get-FolderReferenceScore([string]$Directory, [string[]]$References) {
    $cacheKey = [System.IO.Path]::GetFullPath($Directory).ToLowerInvariant()
    if ($script:FolderFileCache.ContainsKey($cacheKey)) {
        $cached = $script:FolderFileCache[$cacheKey]
        $fileNames = $cached.Names
        $fileStems = $cached.Stems
    } else {
        $folderTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $fileNames = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
        $fileStems = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
        # 音声や画像を sound/image などの子フォルダに置くパッケージもあるため、
        # 譜面がある曲フォルダの配下をまとめて照合します。
        foreach ($file in @(Get-ChildItem -LiteralPath $Directory -Recurse -File -ErrorAction SilentlyContinue)) {
            [void]$fileNames.Add($file.Name)
            [void]$fileStems.Add([System.IO.Path]::GetFileNameWithoutExtension($file.Name))
        }
        $folderTimer.Stop()
        Add-PerformanceMetric '候補フォルダ内容列挙' $folderTimer.Elapsed.TotalMilliseconds $fileNames.Count
        Add-PerformanceCounter '候補フォルダ内容列挙回数'
        $script:FolderFileCache[$cacheKey] = [pscustomobject]@{ Names = $fileNames; Stems = $fileStems }
    }
    $hits = 0
    foreach ($reference in $References) {
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($reference)
        if ($fileNames.Contains($reference) -or ($stem -and $fileStems.Contains($stem))) { $hits++ }
    }
    $ratio = if ($References.Count -gt 0) { $hits / [double]$References.Count } else { 0 }
    return [pscustomobject]@{ Path = $Directory; Hits = $hits; Ratio = $ratio }
}

function Select-BestReferenceFolder([string[]]$Directories, [string[]]$References) {
    $scores = New-Object System.Collections.Generic.List[object]
    $directoryNumber = 0
    foreach ($dir in $Directories) {
        $directoryNumber++
        if (($directoryNumber % 25) -eq 0) { Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress '親曲候補を照合中' $directoryNumber $Directories.Count }
        $score = Get-FolderReferenceScore $dir $References
        if ($score.Hits -gt 0) { $scores.Add($score) }
    }
    $ordered = @($scores | Sort-Object Hits, Ratio -Descending)
    if ($ordered.Count -eq 0) { return $null }
    $best = $ordered[0]
    $secondHits = if ($ordered.Count -gt 1) { $ordered[1].Hits } else { 0 }
    if ($best.Hits -ge 3 -and $best.Ratio -ge 0.50 -and ($best.Hits -gt $secondHits -or $best.Ratio -gt 0.90)) { return $best.Path }
    return $null
}

function Find-ParentFolder([string]$ChartPath, [string]$MusicPath, $DatabaseIndex, [switch]$IndexOnly) {
    $parentTimer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
    $refs = @(Get-ChartReferences $ChartPath)
    $indexedMatch = Find-ParentFolderFromIndex $refs
    if ($indexedMatch) { return $indexedMatch }
    Write-AppLog 'INFO' 'PARENT_INDEX' '高速索引に親曲候補がありません。全ライブラリ検索は行いません。外部から曲を追加した場合は「索引を更新」で反映してください。'
    return $null
    } finally {
        $parentTimer.Stop()
        Add-PerformanceMetric '親曲フォルダ特定' $parentTimer.Elapsed.TotalMilliseconds 1
        Add-PerformanceCounter '親曲検索回数'
    }
}

function Copy-NewFiles([string]$SourceRoot, [string]$DestinationRoot) {
    $copied = 0
    $fileNumber = 0
    $sourceFiles = @(Get-ChildItem -LiteralPath $SourceRoot -Recurse -File)
    foreach ($file in $sourceFiles) {
        $fileNumber++
        if (($fileNumber % 100) -eq 0 -or $fileNumber -eq 1 -or $fileNumber -eq $sourceFiles.Count) { Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress 'ファイル配置中' $fileNumber $sourceFiles.Count }
        $rootFull = [System.IO.Path]::GetFullPath($SourceRoot).TrimEnd('\') + '\'
        $fileFull = [System.IO.Path]::GetFullPath($file.FullName)
        if (-not $fileFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) { continue }
        $relative = $fileFull.Substring($rootFull.Length)
        $target = Join-Path $DestinationRoot $relative
        if (-not (Test-Path -LiteralPath $target)) {
            [System.IO.Directory]::CreateDirectory((Split-Path -Parent $target)) | Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $target
            $copied++
        }
    }
    if ($copied -gt 0) { Register-FolderInSessionIndex $DestinationRoot }
    return $copied
}

function Get-PackageCacheKey([string]$DownloadedPath) {
    $item = Get-Item -LiteralPath $DownloadedPath -ErrorAction Stop
    return ([System.IO.Path]::GetFullPath($item.FullName).ToLowerInvariant() + '|' + $item.Length + '|' + $item.LastWriteTimeUtc.Ticks)
}

function Get-CachedPackageChart($Package, [string]$ExpectedMd5, [string]$ExpectedSha) {
    if ($ExpectedMd5) {
        if (-not $Package.Md5Complete) {
            $hashTimer = [System.Diagnostics.Stopwatch]::StartNew()
            $number = 0
            foreach ($chart in $Package.Charts) {
                $number++
                if (($number % 50) -eq 0 -or $number -eq 1 -or $number -eq $Package.Charts.Count) {
                    Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress '譜面索引を作成中' $number $Package.Charts.Count
                }
                $hash = (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant()
                Add-PerformanceCounter 'パッケージMD5計算回数'
                if (-not $Package.ByMd5.ContainsKey($hash)) { $Package.ByMd5[$hash] = $chart }
            }
            $Package.Md5Complete = $true
            $hashTimer.Stop()
            Add-PerformanceMetric 'パッケージMD5索引作成' $hashTimer.Elapsed.TotalMilliseconds $number
        }
        if ($Package.ByMd5.ContainsKey($ExpectedMd5)) { return $Package.ByMd5[$ExpectedMd5] }
    }
    if ($ExpectedSha) {
        if (-not $Package.ShaComplete) {
            $hashTimer = [System.Diagnostics.Stopwatch]::StartNew()
            $number = 0
            foreach ($chart in $Package.Charts) {
                $number++
                if (($number % 50) -eq 0 -or $number -eq 1 -or $number -eq $Package.Charts.Count) {
                    Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress 'SHA-256索引を作成中' $number $Package.Charts.Count
                }
                $hash = (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                Add-PerformanceCounter 'パッケージSHA256計算回数'
                if (-not $Package.BySha.ContainsKey($hash)) { $Package.BySha[$hash] = $chart }
            }
            $Package.ShaComplete = $true
            $hashTimer.Stop()
            Add-PerformanceMetric 'パッケージSHA256索引作成' $hashTimer.Elapsed.TotalMilliseconds $number
        }
        if ($Package.BySha.ContainsKey($ExpectedSha)) { return $Package.BySha[$ExpectedSha] }
    }
    return $null
}

function Clear-ExtractedPackageCache {
    $dataRoot = [System.IO.Path]::GetFullPath($script:DataDir).TrimEnd('\') + '\'
    $roots = @($script:ExtractedPackageCache.Values | ForEach-Object { $_.Root } | Sort-Object -Unique)
    $script:ExtractedPackageCache = @{}
    foreach ($root in $roots) {
        try {
            $full = [System.IO.Path]::GetFullPath([string]$root)
            if ($full.StartsWith($dataRoot, [System.StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $full) -like 'extract-*' -and (Test-Path -LiteralPath $full)) {
                Remove-Item -LiteralPath $full -Recurse -Force -ErrorAction SilentlyContinue
            }
        } catch { }
    }
}

function Install-DownloadedEntry($Entry, [string]$DownloadedPath, [string]$MusicPath, $DatabaseIndex) {
    $installTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $work = Join-Path $script:DataDir ('extract-' + [guid]::NewGuid().ToString('N'))
    $keepWork = $false
    $package = $null
    $cacheKey = ''
    $titleForLog = Get-EntryText $Entry 'title' '(タイトル不明)'
    Write-AppLog 'INFO' 'INSTALL' ("開始: $titleForLog / $DownloadedPath")
    try {
        Assert-NotCancelled
        $detectedChartExtension = Get-DownloadedChartExtension $DownloadedPath
        $isDirectChart = -not [string]::IsNullOrWhiteSpace($detectedChartExtension)
        if ($isDirectChart) {
            [System.IO.Directory]::CreateDirectory($work) | Out-Null
            [void](Copy-DownloadedChartToFolder $DownloadedPath $work)
        } else {
            $cacheKey = Get-PackageCacheKey $DownloadedPath
            if ($script:ExtractedPackageCache.ContainsKey($cacheKey) -and (Test-Path -LiteralPath $script:ExtractedPackageCache[$cacheKey].Root -PathType Container)) {
                $package = $script:ExtractedPackageCache[$cacheKey]
                $work = $package.Root
                $keepWork = $true
                Report-OperationProgress '展開済みパックを再利用' $package.Charts.Count $package.Charts.Count
                Write-AppLog 'INFO' 'EXTRACT_CACHE' ("再利用: $DownloadedPath / $($package.Charts.Count)譜面")
            } else {
                [System.IO.Directory]::CreateDirectory($work) | Out-Null
            try {
                if (Test-DownloadedFileIsHtml $DownloadedPath) { throw '配布URLから書庫ではなくWebページが返されました。' }
                Expand-DownloadedFile $DownloadedPath $work
            } catch {
                if ($script:CancelRequested) { throw 'ユーザー操作で中止しました。' }
                $target = Join-Path $script:InboxDir ([System.IO.Path]::GetFileName($DownloadedPath))
                if (Test-Path -LiteralPath $target) {
                    $target = Join-Path $script:InboxDir (([System.IO.Path]::GetFileNameWithoutExtension($DownloadedPath)) + '-' + [guid]::NewGuid().ToString('N').Substring(0, 6) + [System.IO.Path]::GetExtension($DownloadedPath))
                }
                Copy-Item -LiteralPath $DownloadedPath -Destination $target
                $isHtml = Test-DownloadedFileIsHtml $DownloadedPath
                $status = if ($isHtml) { '配布ページ' } else { '展開不可' }
                $message = if ($isHtml) { '配布URLから実ファイルではなくWebページが返されたため、受信箱に保存しました。' } else { 'この書庫は自動展開できなかったため、受信箱に保存しました。' }
                Write-AppLog 'ERROR' 'ARCHIVE' ("$status`: $titleForLog / $($_.Exception.Message)")
                return [pscustomobject]@{ Status = $status; Message = ($message + [Environment]::NewLine + $_.Exception.Message) }
            }
            }
        }
        Report-OperationProgress '譜面一覧を確認中' 0 0
        # Assign each branch separately.  Using `if` as an expression here makes
        # Windows PowerShell 5.1 build a conditional expression whose array
        # branches can have incompatible runtime types.
        if ($package) {
            $charts = [object[]]$package.Charts
        } else {
            $charts = @(Get-ChartFiles $work)
        }
        Assert-NotCancelled
        Write-AppLog 'INFO' 'ARCHIVE' ("展開成功: $($charts.Count)譜面を検出")
        if ($charts.Count -eq 0) {
            Write-AppLog 'ERROR' 'CHART' '書庫内にBMS/BME/BML/PMS/BMSON譜面がありません。'
            return [pscustomobject]@{ Status = '譜面なし'; Message = '書庫内にBMS譜面がありません。配布ファイルが変更された可能性があります。' }
        }
        if (-not $isDirectChart -and -not $package) {
            $package = [pscustomobject]@{ Root=$work; Charts=$charts; ByMd5=@{}; BySha=@{}; Md5Complete=$false; ShaComplete=$false }
            $script:ExtractedPackageCache[$cacheKey] = $package
            $keepWork = $true
            Write-AppLog 'INFO' 'EXTRACT_CACHE' ("登録: $DownloadedPath / $($charts.Count)譜面")
        }
        $expectedMd5 = Get-EntryHash $Entry 'md5'
        $expectedSha = Get-EntryHash $Entry 'sha256'
        $matched = $null
        if ($package) {
            $matched = Get-CachedPackageChart $package $expectedMd5 $expectedSha
        } else {
            $chartNumber = 0
            foreach ($chart in $charts) {
                $chartNumber++
                if (($chartNumber % 50) -eq 0 -or $chartNumber -eq 1 -or $chartNumber -eq $charts.Count) { Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress '対象譜面を確認中' $chartNumber $charts.Count }
                if ($expectedMd5) {
                    Add-PerformanceCounter 'パッケージMD5計算回数'
                    if ((Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant() -eq $expectedMd5) { $matched = $chart; break }
                }
                if ($expectedSha) {
                    Add-PerformanceCounter 'パッケージSHA256計算回数'
                    if ((Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expectedSha) { $matched = $chart; break }
                }
            }
        }
        if (-not $matched) {
            Write-AppLog 'ERROR' 'CHART_HASH' ("難易度表のMD5/SHA-256と一致しません: $titleForLog")
            return [pscustomobject]@{ Status = '譜面不一致'; Message = '難易度表のハッシュと一致する譜面が書庫にありません。同名の別パッケージまたは配布内容変更の可能性があります。' }
        }
        Write-AppLog 'INFO' 'CHART_HASH' ("一致: $($matched.Name)")
        $refs = @(Get-ChartReferences $matched.FullName)
        $partial = Get-PartialInstall $Entry
        $rejectedPartialBase = $false
        $parent = $null
        if ($partial -and $partial.BaseFolder) {
            $partialScore = Get-FolderReferenceScore $partial.BaseFolder $refs
            if ($partialScore.Hits -ge 3 -and $partialScore.Ratio -ge 0.50) {
                $parent = $partial.BaseFolder
                Write-AppLog 'INFO' 'PARTIAL' ("保存済みの元曲へ差分を補完: $parent / $($partialScore.Hits)/$($refs.Count)一致")
            } else {
                $rejectedPartialBase = $true
                Write-AppLog 'WARN' 'PARTIAL' ("保存済み元曲は差分素材と一致しないため関連付けを解除: $($partial.BaseFolder) / $($partialScore.Hits)/$($refs.Count)一致")
            }
        }
        if (-not $parent) { $parent = Find-ParentFolder $matched.FullName $MusicPath $DatabaseIndex }
        if ($parent) {
            $sourceRoot = $matched.DirectoryName
            $count = Copy-NewFiles $sourceRoot $parent
            Clear-PartialInstall $Entry -RemovePendingFolder
            Write-AppLog 'INFO' 'PARENT' ("親BMS特定: $parent / $count ファイル配置")
            return [pscustomobject]@{ Status = '導入済み'; Message = "$count 個の新しいファイルを配置しました。" }
        }
        $selfContainedScore = Get-FolderReferenceScore $matched.DirectoryName $refs
        $selfContainedHits = $selfContainedScore.Hits
        $title = Get-EntryText $Entry 'title' $matched.BaseName
        if ($refs.Count -ge 3 -and $selfContainedHits -ge 3 -and ($selfContainedHits / [double]$refs.Count) -ge 0.50) {
            $artist = Get-EntryText $Entry 'artist' 'Unknown'
            $newFolderName = Get-SafeFileName ("[$artist] $title")
            $newFolder = Join-Path $MusicPath $newFolderName
            if (Test-Path -LiteralPath $newFolder) { $newFolder += '-' + [guid]::NewGuid().ToString('N').Substring(0, 6) }
            [System.IO.Directory]::CreateDirectory($newFolder) | Out-Null
            $count = Copy-NewFiles $matched.DirectoryName $newFolder
            Clear-PartialInstall $Entry -RemovePendingFolder
            Write-AppLog 'INFO' 'SELF_CONTAINED' ("元曲一式として配置: $newFolder / $count ファイル")
            return [pscustomobject]@{ Status = '導入済み'; Message = "自己完結した曲として$count 個のファイルを配置しました。" }
        }
        $folder = Join-Path $script:InboxDir ((Get-SafeFileName $title) + '-' + [guid]::NewGuid().ToString('N').Substring(0, 6))
        [System.IO.Directory]::CreateDirectory($folder) | Out-Null
        [void](Copy-NewFiles $matched.DirectoryName $folder)
        Set-PartialInstall $Entry -PendingFolder $folder -ClearBaseFolder:$rejectedPartialBase
        $savedPartial = Get-PartialInstall $Entry
        if ($savedPartial -and $savedPartial.BasePackagePath) {
            try {
                Write-AppLog 'INFO' 'PARTIAL' ("保存済みの元曲候補ファイルとD&D差分を再結合: $($savedPartial.BasePackagePath)")
                return Install-PendingWithBasePackage $Entry ([string]$savedPartial.BasePackagePath) $folder $MusicPath
            } catch {
                if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw }
                Write-AppLog 'WARN' 'PARTIAL' ("保存済み元曲候補との再結合に失敗。両方を保持します: $($_.Exception.Message)")
                return [pscustomobject]@{ Status = '元曲候補・差分保存済み／統合失敗'; Message = '元曲候補ファイルと差分は保存されていますが、同じ楽曲として安全に照合できませんでした。どちらも削除していません。' + [Environment]::NewLine + $_.Exception.Message; PendingFolder = $folder }
            }
        }
        Write-AppLog 'WARN' 'PARENT' ("親BMSが見つかりません: $titleForLog / 受信箱: $folder")
        return [pscustomobject]@{ Status = '親曲なし'; Message = 'ファイル取得成功／配置失敗：対応する親BMSを特定できないため受信箱に保存しました。'; PendingFolder = $folder }
    } finally {
        if (-not $keepWork -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force }
        $installTimer.Stop()
        Add-PerformanceMetric 'ダウンロード済みファイル導入' $installTimer.Elapsed.TotalMilliseconds 1
    }
}

function Get-MatchingChartForEntry($Entry, [string]$Folder) {
    $expectedMd5 = Get-EntryHash $Entry 'md5'
    $expectedSha = Get-EntryHash $Entry 'sha256'
    foreach ($chart in @(Get-ChartFiles $Folder)) {
        if ($expectedMd5 -and (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant() -eq $expectedMd5) { return $chart }
        if ($expectedSha -and (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expectedSha) { return $chart }
    }
    return $null
}

function Install-PendingFolder($Entry, [string]$PendingFolder, [string]$MusicPath, $DatabaseIndex, [switch]$IndexOnly) {
    Assert-NotCancelled
    $matched = Get-MatchingChartForEntry $Entry $PendingFolder
    if (-not $matched) { throw '難易度表と一致する譜面が配置待ちフォルダにありません。' }
    $parent = Find-ParentFolder $matched.FullName $MusicPath $DatabaseIndex -IndexOnly:$IndexOnly
    if ($parent) {
        $count = Copy-NewFiles $PendingFolder $parent
        Clear-PartialInstall $Entry -RemovePendingFolder
        return [pscustomobject]@{ Status = '導入済み'; Message = "$count 個の配置待ちファイルを元曲フォルダへ配置しました。" }
    }
    $refs = @(Get-ChartReferences $matched.FullName)
    $score = Get-FolderReferenceScore $matched.DirectoryName $refs
    if ($refs.Count -ge 3 -and $score.Hits -ge 3 -and $score.Ratio -ge 0.50) {
        $title = Get-EntryText $Entry 'title' $matched.BaseName
        $artist = Get-EntryText $Entry 'artist' 'Unknown'
        $newFolder = Join-Path $MusicPath (Get-SafeFileName ("[$artist] $title"))
        if (Test-Path -LiteralPath $newFolder) { $newFolder += '-' + [guid]::NewGuid().ToString('N').Substring(0, 6) }
        [System.IO.Directory]::CreateDirectory($newFolder) | Out-Null
        $count = Copy-NewFiles $PendingFolder $newFolder
        Clear-PartialInstall $Entry -RemovePendingFolder
        return [pscustomobject]@{ Status = '導入済み'; Message = "完成済みの曲として$count 個のファイルを配置しました。" }
    }
    return [pscustomobject]@{ Status = '親曲なし'; Message = '所持済みの元曲を特定できませんでした。'; PendingFolder = $PendingFolder }
}

function Get-PendingFolders {
    if (-not (Test-Path -LiteralPath $script:InboxDir -PathType Container)) { return @() }
    return @(Get-ChildItem -LiteralPath $script:InboxDir -Directory -ErrorAction SilentlyContinue | Where-Object {
        @(Get-ChartFiles $_.FullName).Count -gt 0
    })
}

function Install-PendingWithBasePackage($Entry, [string]$BaseDownloadedPath, [string]$PendingFolder, [string]$MusicPath) {
    Assert-NotCancelled
    if (-not (Test-Path -LiteralPath $PendingFolder -PathType Container)) { throw '配置待ちの譜面が見つかりません。' }
    if (Test-DownloadedFileIsHtml $BaseDownloadedPath) { throw '元曲URLから書庫ではなく配布ページが返されました。' }
    $work = Join-Path $script:DataDir ('base-' + [guid]::NewGuid().ToString('N'))
    try {
        [System.IO.Directory]::CreateDirectory($work) | Out-Null
        if (-not [string]::IsNullOrWhiteSpace((Get-DownloadedChartExtension $BaseDownloadedPath))) {
            [void](Copy-DownloadedChartToFolder $BaseDownloadedPath $work)
        } else {
            Expand-DownloadedFile $BaseDownloadedPath $work
        }
        Assert-NotCancelled
        $pendingCharts = @(Get-ChartFiles $PendingFolder)
        if ($pendingCharts.Count -eq 0) { throw '配置待ちフォルダに譜面がありません。' }
        $expectedMd5 = Get-EntryHash $Entry 'md5'
        $expectedSha = Get-EntryHash $Entry 'sha256'
        $pendingChart = $null
        foreach ($chart in $pendingCharts) {
            if ($expectedMd5 -and (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant() -eq $expectedMd5) { $pendingChart = $chart; break }
            if ($expectedSha -and (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -eq $expectedSha) { $pendingChart = $chart; break }
        }
        if (-not $pendingChart) { throw '配置待ち譜面の確認に失敗しました。' }
        $refs = @(Get-ChartReferences $pendingChart.FullName)
        $baseDirectories = @(Get-ChartFiles $work | Select-Object -ExpandProperty DirectoryName -Unique)
        $baseFolder = Select-BestReferenceFolder $baseDirectories $refs
        if (-not $baseFolder) { throw '取得した元曲パッケージと差分譜面を照合できませんでした。' }
        $title = Get-EntryText $Entry 'title' $pendingChart.BaseName
        $artist = Get-EntryText $Entry 'artist' 'Unknown'
        $newFolder = Join-Path $MusicPath (Get-SafeFileName ("[$artist] $title"))
        if (Test-Path -LiteralPath $newFolder) { $newFolder += '-' + [guid]::NewGuid().ToString('N').Substring(0, 6) }
        [System.IO.Directory]::CreateDirectory($newFolder) | Out-Null
        $baseCount = Copy-NewFiles $baseFolder $newFolder
        $differenceCount = Copy-NewFiles $PendingFolder $newFolder
        Clear-PartialInstall $Entry -RemovePendingFolder
        return [pscustomobject]@{ Status = '導入済み'; Message = "元曲も取得し、$baseCount 個の元曲ファイルと $differenceCount 個の差分ファイルを配置しました。" }
    } finally {
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
    }
}

function Install-BasePackageOnly($Entry, [string]$BaseDownloadedPath, [string]$MusicPath) {
    Assert-NotCancelled
    if (Test-DownloadedFileIsHtml $BaseDownloadedPath) { throw '元曲URLから実ファイルではなく配布ページが返されました。' }
    $work = Join-Path $script:DataDir ('base-only-' + [guid]::NewGuid().ToString('N'))
    try {
        [System.IO.Directory]::CreateDirectory($work) | Out-Null
        if (-not [string]::IsNullOrWhiteSpace((Get-DownloadedChartExtension $BaseDownloadedPath))) {
            [void](Copy-DownloadedChartToFolder $BaseDownloadedPath $work)
        } else {
            Expand-DownloadedFile $BaseDownloadedPath $work
        }
        Assert-NotCancelled
        $charts = @(Get-ChartFiles $work)
        if ($charts.Count -eq 0) { throw '元曲パッケージ内にBMS譜面がありません。' }
        $candidates = New-Object System.Collections.Generic.List[object]
        $number = 0
        foreach ($chart in $charts) {
            $number++
            if (($number % 25) -eq 0 -or $number -eq 1 -or $number -eq $charts.Count) {
                Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress '元曲パッケージを確認中' $number $charts.Count
            }
            $refs = @(Get-ChartReferences $chart.FullName)
            $score = Get-FolderReferenceScore $chart.DirectoryName $refs
            $metadata = Get-ChartMetadata $chart.FullName
            if ((Test-EntryTitleMatchesCandidate $Entry ([string]$metadata.Title)) -and $refs.Count -ge 3 -and $score.Hits -ge 3 -and $score.Ratio -ge 0.50) {
                [void]$candidates.Add([pscustomobject]@{ Chart=$chart; Folder=$chart.DirectoryName; Hits=$score.Hits; Ratio=$score.Ratio })
            }
        }
        $best = @($candidates | Sort-Object Ratio, Hits -Descending | Select-Object -First 1)
        if ($best.Count -eq 0) { throw '取得したパッケージ内に対象曲と同名で再生可能なBMSがないため、元曲として配置しませんでした。' }
        $selected = $best[0]
        $metadata = Get-ChartMetadata $selected.Chart.FullName
        $title = if ([string]::IsNullOrWhiteSpace([string]$metadata.Title)) { Get-EntryText $Entry 'title' $selected.Chart.BaseName } else { [string]$metadata.Title }
        $artist = if ([string]::IsNullOrWhiteSpace([string]$metadata.Artist)) { Get-EntryText $Entry 'artist' 'Unknown' } else { [string]$metadata.Artist }
        $newFolder = Join-Path $MusicPath (Get-SafeFileName ("[$artist] $title"))
        if (Test-Path -LiteralPath $newFolder) { $newFolder += '-' + [guid]::NewGuid().ToString('N').Substring(0, 6) }
        [System.IO.Directory]::CreateDirectory($newFolder) | Out-Null
        $count = Copy-NewFiles $selected.Folder $newFolder
        if ($count -eq 0) { throw '元曲フォルダへ配置できるファイルがありませんでした。' }
        Write-AppLog 'INFO' 'BASE_ONLY' ("元曲のみ配置: $newFolder / $count ファイル")
        Set-PartialInstall $Entry -BaseFolder $newFolder
        return [pscustomobject]@{ Status='楽曲のみ導入済み／差分未導入'; Message="元曲のみ$count 個のファイルを曲フォルダへ配置しました。差分は未導入です。"; BaseFolder=$newFolder }
    } finally {
        if (Test-Path -LiteralPath $work) { Remove-Item -LiteralPath $work -Recurse -Force }
    }
}

function New-DownloadDestination([string]$Url, [string]$Title) {
    $leaf = [System.IO.Path]::GetFileName(([Uri]$url).AbsolutePath)
    if ([string]::IsNullOrWhiteSpace($leaf)) { $leaf = (Get-SafeFileName $title) + '.zip' }
    return Join-Path $script:DownloadDir (([guid]::NewGuid().ToString('N').Substring(0, 8)) + '-' + (Get-SafeFileName $leaf))
}

function Save-UrlResponsive([string]$Url, [string]$Destination, [int]$TotalSeconds = 120, [int]$NoProgressSeconds = 20) {
    $networkTimer = [System.Diagnostics.Stopwatch]::StartNew()
    Write-AppLog 'INFO' 'DOWNLOAD' ("開始: $Url")
    $client = New-Object System.Net.WebClient
    $client.Headers[[System.Net.HttpRequestHeader]::UserAgent] = $script:WebUserAgent
    try {
        $task = $client.DownloadFileTaskAsync([Uri]$Url, $Destination)
        $downloadTimer = [System.Diagnostics.Stopwatch]::StartNew()
        $lastProgress = [DateTime]::UtcNow
        $lastSize = -1L
        while (-not $task.IsCompleted) {
            Invoke-UiPulse
            if ($script:CancelRequested) {
                $client.CancelAsync()
                throw 'ユーザー操作で中止しました。'
            }
            $currentSize = if (Test-Path -LiteralPath $Destination) { (Get-Item -LiteralPath $Destination).Length } else { 0L }
            if ($currentSize -ne $lastSize) { $lastSize = $currentSize; $lastProgress = [DateTime]::UtcNow }
            if (([DateTime]::UtcNow - $lastProgress).TotalSeconds -ge $NoProgressSeconds) {
                $client.CancelAsync()
                throw "$NoProgressSeconds 秒以上データを受信できなかったため、このURLを打ち切りました。"
            }
            if ($downloadTimer.Elapsed.TotalSeconds -ge $TotalSeconds) {
                $client.CancelAsync()
                throw "$TotalSeconds 秒以内に完了しなかったため、このURLを打ち切りました。"
            }
            Start-Sleep -Milliseconds 50
        }
        $task.GetAwaiter().GetResult()
        $size = (Get-Item -LiteralPath $Destination).Length
        Write-AppLog 'INFO' 'DOWNLOAD' ("成功: $size bytes / $Destination")
    } catch {
        if (Test-Path -LiteralPath $Destination) { Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue }
        $message = $_.Exception.Message
        $responseProperty = $_.Exception.PSObject.Properties['Response']
        $response = if ($responseProperty) { $responseProperty.Value } else { $null }
        if ($response -and $response.StatusCode) { $message = "HTTP $([int]$response.StatusCode) $($response.StatusDescription)" }
        Write-AppLog 'ERROR' 'DOWNLOAD' ("失敗: $Url / $message")
        if ($message -match 'HTTP (404|410)') { throw 'ダウンロード失敗: リンク切れの可能性があります。' }
        throw ('ダウンロード失敗: ' + $message)
    } finally {
        $client.Dispose()
        $networkTimer.Stop()
        Add-PerformanceMetric 'ネットワーク取得（単体）' $networkTimer.Elapsed.TotalMilliseconds 1
    }
}

function Convert-ToDirectDownloadUrl([string]$Url) {
    # Wayback Machine's normal snapshot URL wraps the original response in its
    # toolbar page.  The id_ modifier returns the archived file bytes unchanged.
    if ($Url -match '^https?://web\.archive\.org/web/(\d+)(?!id_)(?:\*|[a-z_]+)?/(https?://.+)$') {
        return 'https://web.archive.org/web/' + $matches[1] + 'id_/' + $matches[2]
    }
    if ($Url -match '^https?://drive\.google\.com/file/d/([^/?]+)') {
        return 'https://drive.usercontent.google.com/download?id=' + $matches[1] + '&export=download&confirm=t'
    }
    if ($Url -match '^https?://drive\.google\.com/open\?.*\bid=([^&]+)') {
        return 'https://drive.usercontent.google.com/download?id=' + $matches[1] + '&export=download&confirm=t'
    }
    if ($Url -match '^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$') {
        return 'https://raw.githubusercontent.com/' + $matches[1] + '/' + $matches[2] + '/' + $matches[3] + '/' + $matches[4]
    }
    if ($Url -match 'dropbox\.com/') {
        if ($Url -match '[?&]dl=\d') { return $Url -replace '([?&])dl=\d', '${1}dl=1' }
        return $Url + $(if ($Url.Contains('?')) { '&dl=1' } else { '?dl=1' })
    }
    return $Url
}

function Get-DownloadLinksFromPage([string]$HtmlPath, [string]$PageUrl, [string]$TargetTitle = '') {
    $bytes = [System.IO.File]::ReadAllBytes($HtmlPath)
    $html = $null
    $asciiHeader = [System.Text.Encoding]::ASCII.GetString($bytes, 0, [Math]::Min(4096, $bytes.Length))
    $encodingOrder = if ($asciiHeader -match '(?i)charset\s*=\s*["'']?utf-?8') { @('utf-8', 'shift_jis') } else { @('shift_jis', 'utf-8') }
    foreach ($encodingName in $encodingOrder) {
        try {
            $candidateText = [System.Text.Encoding]::GetEncoding($encodingName).GetString($bytes)
            if ($candidateText -match '(?is)<html|<!doctype') { $html = $candidateText; break }
        } catch { }
    }
    if ($null -eq $html) { return @() }
    $links = New-Object System.Collections.Generic.List[object]
    $seen = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $originalOrder = 0

    # Large public Google Drive files first return a warning page.  Its actual
    # download target is a GET form rather than an <a href>, so rebuild the URL
    # from the form action and hidden fields.
    foreach ($formMatch in [regex]::Matches($html, '(?is)<form\b([^>]*)>(.*?)</form>')) {
        $formAttributes = $formMatch.Groups[1].Value
        $actionMatch = [regex]::Match($formAttributes, '(?is)\baction\s*=\s*["'']([^"'']+)["'']')
        if (-not $actionMatch.Success) { continue }
        $action = Resolve-AbsoluteUrl $PageUrl ([System.Net.WebUtility]::HtmlDecode($actionMatch.Groups[1].Value.Trim()))
        if ($action -notmatch '^https?://drive\.usercontent\.google\.com/download') { continue }
        $parameters = New-Object System.Collections.Generic.List[string]
        foreach ($inputMatch in [regex]::Matches($formMatch.Groups[2].Value, '(?is)<input\b([^>]*)>')) {
            $attributes = $inputMatch.Groups[1].Value
            $nameMatch = [regex]::Match($attributes, '(?is)\bname\s*=\s*["'']([^"'']+)["'']')
            $valueMatch = [regex]::Match($attributes, '(?is)\bvalue\s*=\s*["'']([^"'']*)["'']')
            if (-not $nameMatch.Success) { continue }
            $name = [System.Net.WebUtility]::HtmlDecode($nameMatch.Groups[1].Value)
            $value = if ($valueMatch.Success) { [System.Net.WebUtility]::HtmlDecode($valueMatch.Groups[1].Value) } else { '' }
            [void]$parameters.Add(([Uri]::EscapeDataString($name) + '=' + [Uri]::EscapeDataString($value)))
        }
        if ($parameters.Count -gt 0) {
            $formUrl = $action + $(if ($action.Contains('?')) { '&' } else { '?' }) + ($parameters -join '&')
            if ($seen.Add($formUrl)) {
                [void]$links.Add([pscustomobject]@{ Url=$formUrl; Label='Google Drive download confirmation'; Score=120; OriginalOrder=$originalOrder; Kind='download' })
                $originalOrder++
            }
        }
    }

    $targetKeys = New-Object System.Collections.Generic.List[string]
    $targetKey = ConvertTo-MatchText $TargetTitle
    if (-not [string]::IsNullOrWhiteSpace($targetKey)) { [void]$targetKeys.Add($targetKey) }
    $baseTitle = [regex]::Replace($TargetTitle, '\s*[\[\(（【].*$', '').Trim()
    $baseTitleKey = ConvertTo-MatchText $baseTitle
    if ($baseTitleKey.Length -ge 4 -and -not $targetKeys.Contains($baseTitleKey)) { [void]$targetKeys.Add($baseTitleKey) }
    foreach ($match in [regex]::Matches($html, '(?is)<a\b[^>]*href\s*=\s*["'']([^"'']+)["''][^>]*>(.*?)</a>')) {
        $href = [System.Net.WebUtility]::HtmlDecode($match.Groups[1].Value.Trim())
        $label = [regex]::Replace($match.Groups[2].Value, '<[^>]+>', ' ')
        $label = [System.Net.WebUtility]::HtmlDecode($label).Trim()
        # Prefer the exact table row so a nearby song's name cannot raise the
        # score of the wrong DL link.  Fall back to a small surrounding area.
        $rowStart = $html.LastIndexOf('<tr', $match.Index, [StringComparison]::OrdinalIgnoreCase)
        $rowEnd = $html.IndexOf('</tr>', $match.Index + $match.Length, [StringComparison]::OrdinalIgnoreCase)
        if ($rowStart -ge 0 -and $rowEnd -ge 0 -and ($rowEnd + 5 - $rowStart) -le 4000) {
            $contextStart = $rowStart
            $contextEnd = $rowEnd + 5
        } else {
            $contextStart = [Math]::Max(0, $match.Index - 180)
            $contextEnd = [Math]::Min($html.Length, $match.Index + $match.Length + 80)
        }
        $context = [regex]::Replace($html.Substring($contextStart, $contextEnd - $contextStart), '<[^>]+>', ' ')
        $context = [System.Net.WebUtility]::HtmlDecode($context)
        $absolute = Resolve-AbsoluteUrl $PageUrl $href
        if ($absolute -notmatch '^https?://') { continue }
        # テンプレート例、広告、ソフト配布ページは実ファイル候補から除外します。
        if ($absolute -match '(?i)(?:asdfasdf|\[\|=|/software/desktop/?|/upgrade(?:/|$)|javascript:)') { continue }
        $linkText = $label + ' ' + $context
        $linkAreaKey = ConvertTo-MatchText $linkText
        $titleMatched = $false
        foreach ($wantedKey in $targetKeys) {
            if (-not [string]::IsNullOrWhiteSpace($wantedKey) -and $linkAreaKey.Contains($wantedKey)) { $titleMatched = $true; break }
        }
        $looksDownloadable = $absolute -match '(?i)\.(zip|rar|7z|lzh|lha|gca|tar|gz|bz2|xz|bms|bme|bml|pms|bmson)(?:[?#]|$)|drive\.google\.com/(?:file/d/|open\?)|drive\.usercontent\.google\.com/download|docs\.google\.com/uc\?|dropbox\.com/|mega\.(?:nz|io)/|mediafire\.com/file/|archive\.org/download/|ux\.getuploader\.com/.+/download/'
        $looksLikeButton = ($absolute -match '(?i)(?:^|[/_.?=&-])(download|down|file|attach)(?:[/_.?=&-]|$)') -or ($linkText -match '(?i)download|ダウンロード|DLはこちら|保存')
        $labelKey = ConvertTo-MatchText $label
        $isTitlePage = $absolute -match '(?i)\.html?(?:[?#]|$)' -and $titleMatched
        if (-not $looksDownloadable -and -not $looksLikeButton -and -not $isTitlePage) { continue }
        if (-not $seen.Add($absolute)) { continue }
        $score = 0
        if ($absolute -match '(?i)\.(zip|rar|7z|lzh|lha|tar|gz|bz2|xz|bms|bme|bml|pms|bmson)(?:[?#]|$)') { $score += 50 }
        if ($absolute -match 'drive\.google\.com|dropbox\.com') { $score += 30 }
        if ($titleMatched) { $score += 80 }
        if ($linkText -match '(?i)download|ダウンロード|本体|BMS') { $score += 20 }
        if ($looksLikeButton) { $score += 10 }
        if ($linkText -match '低画質|軽量|ogg') { $score += 15 }
        if ($linkText -match '高画質|wav') { $score -= 5 }
        if ($isTitlePage) { $score += 25 }
        $kind = if ($isTitlePage -and -not $looksDownloadable) { 'page' } else { 'download' }
        [void]$links.Add([pscustomobject]@{ Url = $absolute; Label = $label; Score = $score; OriginalOrder = $originalOrder; Kind=$kind })
        $originalOrder++
    }

    # 一部の配布ページはリンク先を data-url/data-href 属性や meta refresh に入れます。
    # JavaScriptを実行せずに読める静的なURLだけを候補に加えます。
    $attributePatterns = @(
        '(?is)\bdata-(?:url|href|download-url)\s*=\s*["'']([^"'']+)["'']',
        '(?is)<meta\b[^>]*http-equiv\s*=\s*["'']?refresh["'']?[^>]*content\s*=\s*["''][^"'']*?url\s*=\s*([^"'';>]+)'
    )
    foreach ($attributePattern in $attributePatterns) {
        foreach ($attributeMatch in [regex]::Matches($html, $attributePattern)) {
            $attributeUrl = Resolve-AbsoluteUrl $PageUrl ([System.Net.WebUtility]::HtmlDecode($attributeMatch.Groups[1].Value.Trim()))
            if ($attributeUrl -notmatch '^https?://' -or $attributeUrl -match '(?i)(?:asdfasdf|\[\|=|/software/desktop/?|/upgrade(?:/|$))') { continue }
            $attributeLooksUseful = $attributeUrl -match '(?i)\.(zip|rar|7z|lzh|lha|tar|gz|bz2|xz|bms|bme|bml|pms|bmson)(?:[?#]|$)|download|drive\.google\.com|dropbox\.com|mediafire\.com/file/|archive\.org/download/'
            if (-not $attributeLooksUseful -or -not $seen.Add($attributeUrl)) { continue }
            [void]$links.Add([pscustomobject]@{ Url=$attributeUrl; Label='ページ内のダウンロード先'; Score=55; OriginalOrder=$originalOrder; Kind='download' })
            $originalOrder++
        }
    }
    return @($links | Sort-Object @{ Expression='Score'; Descending=$true }, @{ Expression='OriginalOrder'; Descending=$false })
}

function Resolve-DownloadedContent($Entry, [string]$Url, [string]$Destination, [int]$Depth = 0) {
    if (-not (Test-DownloadedFileIsHtml $Destination)) { return $Destination }
    $title = Get-EntryText $Entry 'title' 'chart'
    Write-AppLog 'WARN' 'DOWNLOAD_PAGE' ("HTMLを検出: $Url")
    # 同じ一覧ページでも譜面名ごとに候補が異なるため、URLだけで失敗を共有しません。
    $pageKey = $Url.ToLowerInvariant() + '|' + (ConvertTo-MatchText $title)
    if ($script:FailedDownloadPages.ContainsKey($pageKey)) {
        Write-AppLog 'INFO' 'DOWNLOAD_PAGE' 'この実行中に探索済みの配布ページなので、再探索せず手動入手へ回します。'
        return $Destination
    }
    $links = @(Get-DownloadLinksFromPage $Destination $Url $title)
    Write-AppLog 'INFO' 'DOWNLOAD_PAGE' ("候補リンク: $($links.Count)件")
    $candidateTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $attempted = 0
    foreach ($link in $links) {
        Assert-NotCancelled
        if ($attempted -ge 2 -or $candidateTimer.Elapsed.TotalSeconds -ge 30) {
            Write-AppLog 'WARN' 'DOWNLOAD_PAGE' ("候補探索を打ち切り: 最大2件または30秒の上限 / 残りは手動入手")
            break
        }
        $attempted++
        $directUrl = Convert-ToDirectDownloadUrl ([string]$link.Url)
        Write-AppLog 'INFO' 'DOWNLOAD_PAGE' ("候補$attempted を確認: score=$($link.Score) / $($link.Label) / $directUrl")
        $candidateKey = $directUrl.ToLowerInvariant()
        if ([string]$link.Kind -eq 'page') { $candidateKey += '|' + (ConvertTo-MatchText $title) }
        if ($script:FailedDownloadCandidates.ContainsKey($candidateKey)) {
            Write-AppLog 'INFO' 'DOWNLOAD_PAGE' ("探索済み候補を省略: $directUrl")
            continue
        }
        if ($script:DownloadCache.ContainsKey($directUrl)) {
            $cachedCandidate = [string]$script:DownloadCache[$directUrl]
            if ((Test-Path -LiteralPath $cachedCandidate -PathType Leaf) -and -not (Test-DownloadedFileIsHtml $cachedCandidate)) { return $cachedCandidate }
        }
        $candidateDestination = New-DownloadDestination $directUrl $title
        try {
            # Google Driveの確認画面の先は大容量ファイルの場合があるため、
            # 受信が続いている間は通常の候補より長く待ちます。
            if ($directUrl -match '^https?://drive\.usercontent\.google\.com/download') {
                [void](Save-UrlResponsive $directUrl $candidateDestination 120 20)
            } else {
                [void](Save-UrlResponsive $directUrl $candidateDestination 15 8)
            }
            $script:DownloadCache[$directUrl] = $candidateDestination
            [void](Save-DownloadCache)
            if (-not (Test-DownloadedFileIsHtml $candidateDestination)) { return $candidateDestination }
            if ($Depth -lt 2) {
                $nestedPath = Resolve-DownloadedContent $Entry $directUrl $candidateDestination ($Depth + 1)
                if ($nestedPath -and -not (Test-DownloadedFileIsHtml $nestedPath)) { return $nestedPath }
            }
            Write-AppLog 'WARN' 'DOWNLOAD_PAGE' ("候補もHTMLでした: $directUrl")
            $script:FailedDownloadCandidates[$candidateKey] = $true
        } catch {
            if ($script:CancelRequested) { throw 'ユーザー操作で中止しました。' }
            Write-AppLog 'WARN' 'DOWNLOAD_PAGE' ("候補取得失敗: $directUrl / $($_.Exception.Message)")
            $script:FailedDownloadCandidates[$candidateKey] = $true
        }
    }
    $script:FailedDownloadPages[$pageKey] = $true
    $pageProbe = [System.Text.Encoding]::ASCII.GetString([System.IO.File]::ReadAllBytes($Destination))
    if ($Url -match 'mega\.(?:nz|io)/') {
        throw 'ダウンロード失敗: MEGAはブラウザ内で復号する方式のため、自動取得できません。「差分ページ」または「楽曲ページ」から手動で入手してください。'
    }
    if ($pageProbe -match '(?i)accounts\.google\.com|ServiceLogin|Sign in.*Google') {
        throw 'ダウンロード失敗: Google Driveのログインまたは共有権限が必要です。配布ページをブラウザで開いて入手してください。'
    }
    if ($pageProbe -match '(?i)/___verify|captcha|cloudflare.*challenge') {
        throw 'ダウンロード失敗: 配布サイトで人による確認操作が必要です。配布ページをブラウザで開いてください。'
    }
    if ($Url -match 'web\.archive\.org/' -or $pageProbe -match '(?i)Wayback Machine') {
        throw 'ダウンロード失敗: Wayback Machineにページ記録はありますが、元ファイルを取得できませんでした。リンク切れの可能性があります。'
    }
    throw '配布URL取得失敗: 配布ページ内から自動取得できるファイルURLを特定できませんでした。配布ページを開いて手動で入手してください。'
}

function Download-EntryPrimary($Entry, [string]$TableDataUrl, [string]$PreferredProperty = '') {
    $url = Get-EntryDownloadUrl $Entry $PreferredProperty
    if ([string]::IsNullOrWhiteSpace($url)) { throw '配布URLがありません。' }
    $url = Resolve-AbsoluteUrl $TableDataUrl $url
    $url = Convert-ToDirectDownloadUrl $url
    $title = Get-EntryText $Entry 'title' 'chart'
    if ($script:DownloadCache.ContainsKey($url)) {
        $cachedPath = [string]$script:DownloadCache[$url]
        if (Test-Path -LiteralPath $cachedPath -PathType Leaf) {
            if ($url -match '^https?://drive\.usercontent\.google\.com/download' -and (Test-DownloadedFileIsHtml $cachedPath)) {
                Write-AppLog 'INFO' 'CACHE' 'Google Driveの確認ページは期限切れになるため、最新のページを再取得します。'
            } else {
                Write-AppLog 'INFO' 'CACHE' ("再利用: $url -> $cachedPath")
                return Resolve-DownloadedContent $Entry $url $cachedPath
            }
        }
    }
    $destination = New-DownloadDestination $url $title
    [void](Save-UrlResponsive $url $destination)
    $script:DownloadCache[$url] = $destination
    [void](Save-DownloadCache)
    return Resolve-DownloadedContent $Entry $url $destination
}

function Download-Entry($Entry, [string]$TableDataUrl, [string]$PreferredProperty = '') {
    try {
        return Download-EntryPrimary $Entry $TableDataUrl $PreferredProperty
    } catch {
        if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw }
        $primaryError = $_.Exception.Message
        # MD5/SHA-256の代替URLは対象差分を指します。元曲(url)の取得に流用すると
        # 差分パックを「元曲取得済み」と誤判定するため、元曲は表のURLだけを使用します。
        if (-not (Test-AllowAlternativeSource $PreferredProperty)) { throw $primaryError }
        $alternative = Download-EntryFromAlternatives $Entry $TableDataUrl $PreferredProperty
        if ($alternative) {
            Register-SuccessfulSourceUrl $Entry ([string]$alternative.Url)
            return [string]$alternative.Path
        }
        throw $primaryError
    }
}

function Test-AllowAlternativeSource([string]$PreferredProperty) {
    return $PreferredProperty -ne 'url'
}

function Install-BaseAfterDifferenceDownloadFailure($Entry, [string]$TableDataUrl, [string]$MusicPath, [string]$DifferenceError) {
    $baseValue = Get-EntryDownloadUrl $Entry 'url'
    $differenceValue = Get-EntryDownloadUrl $Entry 'url_diff'
    if ([string]::IsNullOrWhiteSpace($baseValue) -or [string]::IsNullOrWhiteSpace($differenceValue)) { return $null }
    $baseUrl = Resolve-AbsoluteUrl $TableDataUrl $baseValue
    $differenceUrl = Resolve-AbsoluteUrl $TableDataUrl $differenceValue
    if ($baseUrl -eq $differenceUrl) { return $null }
    $title = Get-EntryText $Entry 'title' 'chart'
    Write-AppLog 'WARN' 'DIFFERENCE_DOWNLOAD' ("$($title): 差分取得失敗。別の元曲URLを試します。 / $DifferenceError")
    $baseDownloaded = ''
    try {
        $baseDownloaded = Download-Entry $Entry $TableDataUrl 'url'
    } catch {
        if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw 'ユーザー操作で中止しました。' }
        Write-AppLog 'ERROR' 'BASE_DOWNLOAD' ("$($title): 差分・元曲とも取得失敗 / $($_.Exception.Message)")
        return [pscustomobject]@{
            Status = '差分・元曲DL失敗'
            Message = '差分の取得に失敗したため元曲も試しましたが、元曲も取得できませんでした。' + [Environment]::NewLine + '差分: ' + $DifferenceError + [Environment]::NewLine + '元曲: ' + $_.Exception.Message
        }
    }
    try {
        $baseResult = Install-BasePackageOnly $Entry $baseDownloaded $MusicPath
        return [pscustomobject]@{
            Status = '楽曲のみ導入済み／差分DL失敗'
            Message = $baseResult.Message + [Environment]::NewLine + '差分のダウンロードには失敗しました: ' + $DifferenceError
        }
    } catch {
        if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw 'ユーザー操作で中止しました。' }
        Write-AppLog 'WARN' 'BASE_ONLY' ("$($title): 元曲取得済み／安全な自動配置不可 / $($_.Exception.Message)")
        Set-PartialInstall $Entry -BasePackagePath $baseDownloaded
        return [pscustomobject]@{
            Status = '元曲候補ファイル保存済み／差分DL失敗'
            Message = '元曲URLからファイルは取得しましたが、親曲としては未確認・未配置です。ファイルは保存してあり、後から正しい差分をD&Dしたときに再照合します。' + [Environment]::NewLine + '差分: ' + $DifferenceError + [Environment]::NewLine + '元曲候補の確認結果: ' + $_.Exception.Message
        }
    }
}

function Download-EntriesParallel([object[]]$Requests, [int]$MaxParallel = 10, [scriptblock]$ProgressCallback = $null) {
    $batchTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $results = @{}
    if (-not $Requests -or $Requests.Count -eq 0) { return $results }
    $MaxParallel = [Math]::Max(1, [Math]::Min(10, $MaxParallel))
    $urlGroups = @{}
    foreach ($request in $Requests) {
        try {
            $preferred = if ($request.PSObject.Properties['PreferredProperty']) { [string]$request.PreferredProperty } else { '' }
            $url = if ($request.PSObject.Properties['OverrideUrl']) { [string]$request.OverrideUrl } else { '' }
            if ([string]::IsNullOrWhiteSpace($url)) { $url = Get-EntryDownloadUrl $request.Entry $preferred }
            if ([string]::IsNullOrWhiteSpace($url)) { throw '配布URLがありません。' }
            $url = Resolve-AbsoluteUrl ([string]$request.DataUrl) $url
            $url = Convert-ToDirectDownloadUrl $url
            $groupKey = $url.ToLowerInvariant()
            if (-not $urlGroups.ContainsKey($groupKey)) {
                $urlGroups[$groupKey] = [pscustomobject]@{ Url=$url; Members=(New-Object System.Collections.ArrayList) }
            }
            [void]$urlGroups[$groupKey].Members.Add($request)
        } catch {
            $results[[string]$request.Key] = [pscustomobject]@{ Path=''; Error=$_.Exception.Message; Url='' }
        }
    }
    # Enumerating through the pipeline produces a plain object[] and avoids the
    # PowerShell 5.1 generic/dictionary collection conversion binder bug.
    $groups = @($urlGroups.GetEnumerator() | ForEach-Object { $_.Value })
    Write-AppLog 'INFO' 'DOWNLOAD_BATCH' ("並行取得開始: $($Requests.Count)譜面 / $($groups.Count)固有URL / 最大$MaxParallel 件")
    for ($offset = 0; $offset -lt $groups.Count; $offset += $MaxParallel) {
        if ($script:CancelRequested) { break }
        $last = [Math]::Min($offset + $MaxParallel - 1, $groups.Count - 1)
        $batch = @($groups[$offset..$last])
        $jobs = New-Object System.Collections.Generic.List[object]
        foreach ($group in $batch) {
            $url = [string]$group.Url
            $firstEntry = $group.Members[0].Entry
            if ($script:DownloadCache.ContainsKey($url)) {
                $cachedPath = [string]$script:DownloadCache[$url]
                if (Test-Path -LiteralPath $cachedPath -PathType Leaf) {
                    if ($url -match '^https?://drive\.usercontent\.google\.com/download' -and (Test-DownloadedFileIsHtml $cachedPath)) {
                        Write-AppLog 'INFO' 'CACHE' 'Google Driveの確認ページは期限切れになるため、最新のページを再取得します。'
                    } else {
                        Add-PerformanceCounter 'ダウンロードキャッシュ利用件数'
                        [void]$jobs.Add([pscustomobject]@{ Group=$group; Url=$url; Destination=$cachedPath; Client=$null; Task=$null; Error=''; Cached=$true; LastSize=0L; LastProgress=[DateTime]::UtcNow; StartedAt=[DateTime]::UtcNow })
                        continue
                    }
                }
            }
            $title = Get-EntryText $firstEntry 'title' 'chart'
            $destination = New-DownloadDestination $url $title
            $client = New-Object System.Net.WebClient
            $client.Headers[[System.Net.HttpRequestHeader]::UserAgent] = $script:WebUserAgent
            try {
                $servicePoint = [System.Net.ServicePointManager]::FindServicePoint([Uri]$url)
                if ($servicePoint.ConnectionLimit -ne 3) { $servicePoint.ConnectionLimit = 3 }
                Write-AppLog 'INFO' 'DOWNLOAD' ("並行取得開始: $url")
                $task = $client.DownloadFileTaskAsync([Uri]$url, $destination)
                [void]$jobs.Add([pscustomobject]@{ Group=$group; Url=$url; Destination=$destination; Client=$client; Task=$task; Error=''; Cached=$false; LastSize=-1L; LastProgress=[DateTime]::UtcNow; StartedAt=[DateTime]::UtcNow })
            } catch {
                $client.Dispose()
                [void]$jobs.Add([pscustomobject]@{ Group=$group; Url=$url; Destination=$destination; Client=$null; Task=$null; Error=$_.Exception.Message; Cached=$false; LastSize=0L; LastProgress=[DateTime]::UtcNow; StartedAt=[DateTime]::UtcNow })
            }
        }
        $pending = @($jobs | Where-Object { $_.Task -and -not $_.Task.IsCompleted })
        $lastProgressUi = [DateTime]::MinValue
        while ($pending.Count -gt 0) {
            Invoke-UiPulse
            if ($script:CancelRequested) {
                foreach ($job in $pending) {
                    if ($job.Client) { $job.Client.CancelAsync() }
                    $job.Error = 'ユーザー操作で中止しました。'
                }
            }
            foreach ($job in $pending) {
                $currentSize = if (Test-Path -LiteralPath $job.Destination) { (Get-Item -LiteralPath $job.Destination).Length } else { 0L }
                if ($currentSize -ne $job.LastSize) { $job.LastSize = $currentSize; $job.LastProgress = [DateTime]::UtcNow }
                if (([DateTime]::UtcNow - $job.LastProgress).TotalSeconds -ge 20) {
                    $job.Client.CancelAsync()
                    $job.Error = '20秒以上データを受信できなかったため、このURLを打ち切りました。'
                } elseif (([DateTime]::UtcNow - $job.StartedAt).TotalSeconds -ge 120) {
                    $job.Client.CancelAsync()
                    $job.Error = '2分以内に完了しなかったため、このURLを打ち切りました。'
                }
            }
            Start-Sleep -Milliseconds 50
            $pending = @($jobs | Where-Object { $_.Task -and -not $_.Task.IsCompleted })
            if ($ProgressCallback -and (([DateTime]::UtcNow - $lastProgressUi).TotalMilliseconds -ge 250)) {
                $finishedInBatch = @($jobs | Where-Object { -not $_.Task -or $_.Task.IsCompleted }).Count
                $receivedBytes = ($jobs | Measure-Object LastSize -Sum).Sum
                [void](& $ProgressCallback ($offset + $finishedInBatch) $groups.Count $pending.Count $receivedBytes)
                $lastProgressUi = [DateTime]::UtcNow
            }
        }
        foreach ($job in $jobs) {
            try {
                if (-not $job.Error -and $job.Task) { [void]$job.Task.GetAwaiter().GetResult() }
                if ($job.Error) { throw $job.Error }
                if (-not (Test-Path -LiteralPath $job.Destination -PathType Leaf)) { throw 'ダウンロードしたファイルが見つかりません。' }
                if (-not $job.Cached) {
                    $size = (Get-Item -LiteralPath $job.Destination).Length
                    Write-AppLog 'INFO' 'DOWNLOAD' ("並行取得成功: $size bytes / $($job.Destination)")
                    $script:DownloadCache[$job.Url] = $job.Destination
                }
                $resolvedPath = Resolve-DownloadedContent $job.Group.Members[0].Entry $job.Url $job.Destination
                foreach ($member in $job.Group.Members) {
                    $results[[string]$member.Key] = [pscustomobject]@{ Path=$resolvedPath; Error=''; Url=$job.Url }
                }
            } catch {
                if (-not $job.Cached -and (Test-Path -LiteralPath $job.Destination)) { Remove-Item -LiteralPath $job.Destination -Force -ErrorAction SilentlyContinue }
                $message = $_.Exception.Message
                Write-AppLog 'ERROR' 'DOWNLOAD' ("並行取得失敗: $($job.Url) / $message")
                foreach ($member in $job.Group.Members) {
                    $results[[string]$member.Key] = [pscustomobject]@{ Path=''; Error=('ダウンロード失敗: ' + $message); Url=$job.Url }
                }
            } finally {
                if ($job.Client) { $job.Client.Dispose() }
            }
        }
        [void](Save-DownloadCache)
        if ($ProgressCallback) { [void](& $ProgressCallback ($last + 1) $groups.Count 0 0L) }
    }
    if ($script:CancelRequested) {
        foreach ($request in $Requests) {
            $key = [string]$request.Key
            if (-not $results.ContainsKey($key)) {
                $results[$key] = [pscustomobject]@{ Path=''; Error='ユーザー操作で中止しました。'; Url='' }
            }
        }
        Write-AppLog 'WARN' 'DOWNLOAD_BATCH' 'ユーザー操作で並行取得を中止しました。'
    }
    Write-AppLog 'INFO' 'DOWNLOAD_BATCH' '並行取得完了'
    $batchTimer.Stop()
    Add-PerformanceMetric 'ネットワーク取得（並行バッチ）' $batchTimer.Elapsed.TotalMilliseconds $groups.Count
    Add-PerformanceCounter '固有ダウンロードURL数' $groups.Count
    return $results
}

function Invoke-SelfTest {
    Ensure-AppFolders
    $testRoot = Join-Path $script:DataDir ('selftest-' + [guid]::NewGuid().ToString('N'))
    $originalDownloadCachePath = $script:DownloadCachePath
    $originalDownloadCache = $script:DownloadCache
    $originalCachePath = $script:CachePath
    $originalChartIndexCachePath = $script:ChartIndexCachePath
    $originalPartialInstallPath = $script:PartialInstallPath
    $originalPartialInstalls = $script:PartialInstalls
    $originalLocalInstalledMD5 = $script:LocalInstalledMD5
    $originalLocalInstalledSHA256 = $script:LocalInstalledSHA256
    $originalMd5UrlMapPath = $script:Md5UrlMapPath
    $originalMd5UrlMap = $script:Md5UrlMap
    $originalSourceUrlCache = $script:SourceUrlCache
    try {
        [System.IO.Directory]::CreateDirectory($testRoot) | Out-Null
        $script:ChartIndexCachePath = Join-Path $testRoot 'chart-index-cache.json'
        $script:PartialInstallPath = Join-Path $testRoot 'partial-installs.json'
        $script:PartialInstalls = @{}
        $chart = Join-Path $testRoot 'test.bms'
        Set-Content -LiteralPath $chart -Encoding UTF8 -Value "#TITLE Test`n#WAV01 kick.wav`n#WAV02 snare.wav`n#BMP01 bg.png"
        $index = Get-LocalChartIndex $testRoot $null
        if ($index.Rows.Count -ne 1 -or $index.Directories.Count -ne 1 -or -not (Test-Path -LiteralPath $script:ChartIndexCachePath)) { throw 'LR2・その他向け曲フォルダ索引テストに失敗しました。' }
        $cachedIndex = Get-LocalChartIndex $testRoot $null
        if ($cachedIndex.Rows.Count -ne 1) { throw '曲フォルダ索引キャッシュの再読込テストに失敗しました。' }
        $libraryRoot = Join-Path $testRoot 'indexed-library'
        $songRoot = Join-Path $libraryRoot 'song'
        [System.IO.Directory]::CreateDirectory((Join-Path $songRoot 'sound')) | Out-Null
        $indexedChart = Join-Path $songRoot 'indexed.bms'
        Set-Content -LiteralPath $indexedChart -Encoding UTF8 -Value "#TITLE Indexed Test`n#ARTIST Tester`n#WAV01 sound\kick.wav`n#WAV02 snare.wav`n#BMP01 bg.png"
        Set-Content -LiteralPath (Join-Path $songRoot 'sound\kick.wav') -Value 'a'
        Set-Content -LiteralPath (Join-Path $songRoot 'snare.wav') -Value 'b'
        Set-Content -LiteralPath (Join-Path $songRoot 'bg.png') -Value 'c'
        $libraryIndexRoot = Join-Path $testRoot 'library-index'
        Ensure-LibraryIndexType
        $firstBuild = [BeatorajaMissingChartFetcher.LibraryIndex]::Build(@($libraryRoot), $libraryIndexRoot, $null, $true)
        $secondBuild = [BeatorajaMissingChartFetcher.LibraryIndex]::Build(@($libraryRoot), $libraryIndexRoot, $null, $true)
        $candidates = [BeatorajaMissingChartFetcher.LibraryIndex]::FindCandidates($libraryIndexRoot, @('kick.wav','snare.wav','bg.png'), 3)
        if ($firstBuild.ChartCount -ne 1 -or $secondBuild.HashedChartCount -ne 0 -or $secondBuild.ReusedChartCount -ne 1 -or $candidates.Count -ne 1 -or $candidates[0].Path -ne $songRoot) { throw '高速ライブラリ索引の作成・差分更新・親曲検索テストに失敗しました。' }
        $fakeBeatoraja = Join-Path $testRoot 'beatoraja'
        [System.IO.Directory]::CreateDirectory($fakeBeatoraja) | Out-Null
        Set-Content -LiteralPath (Join-Path $fakeBeatoraja 'songdata.db') -Value ''
        [ordered]@{ bmsroot=@($libraryRoot); tableURL=@('https://example.com/table.html') } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $fakeBeatoraja 'config_sys.json') -Encoding UTF8
        $importedConfig = Import-BeatorajaConfiguration $fakeBeatoraja
        if ($importedConfig.MusicPaths.Count -ne 1 -or $importedConfig.TableUrls.Count -ne 1) { throw 'beatoraja設定の読込テストに失敗しました。' }
        $md5 = (Get-FileHash -LiteralPath $chart -Algorithm MD5).Hash.ToLowerInvariant()
        $entry = [pscustomobject]@{ md5 = $md5; sha256 = ''; title = 'Test' }
        if (-not (Test-EntryInstalled $entry $index)) { throw '所持判定テストに失敗しました。' }
        $script:CachePath = Join-Path $testRoot 'local-hashes.json'
        $script:LocalInstalledMD5 = @{}
        $script:LocalInstalledSHA256 = @{}
        $recordedEntry = [pscustomobject]@{ md5=('c' * 32); sha256=('d' * 64); title='Recorded' }
        Register-EntryInstalled $recordedEntry
        $script:LocalInstalledMD5 = @{}
        $script:LocalInstalledSHA256 = @{}
        Load-LocalInstalledHashes
        if (-not (Test-EntryRecordedInstalled $recordedEntry)) { throw 'ツール導入済み記録の保存・再読込テストに失敗しました。' }
        $wrapped = [pscustomobject]@{ data = @($entry, $entry) }
        if (@(ConvertTo-TableEntryArray $wrapped).Count -ne 2) { throw '難易度表の配列展開テストに失敗しました。' }
        if (-not (New-DefaultSettings).Contains('CustomTables')) { throw '手動登録難易度表の設定テストに失敗しました。' }
        $fallbackTableName = Get-FriendlyTableNameFromUrl 'https://example.com/tables/my-table/header.json'
        if ($fallbackTableName -ne 'my-table (example.com)') { throw "難易度表のURL由来名生成テストに失敗しました: $fallbackTableName" }
        $japaneseTableName = '日本語難易度表・発狂'
        $mojibakeName = [System.Text.Encoding]::GetEncoding(28591).GetString([System.Text.Encoding]::UTF8.GetBytes($japaneseTableName))
        if ((Repair-MojibakeText $mojibakeName) -ne $japaneseTableName) { throw '保存済み難易度表名の文字化け修復テストに失敗しました。' }
        $utf8JsonBytes = [System.Text.Encoding]::UTF8.GetBytes(('{"name":"' + $japaneseTableName + '"}'))
        $utf8Decoded = Convert-WebBytesToText $utf8JsonBytes 'text/plain'
        if (($utf8Decoded | ConvertFrom-Json).name -ne $japaneseTableName) { throw 'charset指定なしUTF-8難易度表の文字コード判定テストに失敗しました。' }
        $shiftJis = Get-WebEncoding 'shift_jis'
        $shiftJisBytes = $shiftJis.GetBytes(('{"name":"' + $japaneseTableName + '"}'))
        $shiftJisDecoded = Convert-WebBytesToText $shiftJisBytes 'application/json; charset=Shift_JIS' -Json
        if (($shiftJisDecoded | ConvertFrom-Json).name -ne $japaneseTableName) { throw 'Shift_JIS難易度表の文字コード判定テストに失敗しました。' }
        $refs = @(Get-ChartReferences $chart)
        if ($refs.Count -ne 3) { throw '参照ファイル解析テストに失敗しました。' }
        $convertedAssets = Join-Path $testRoot 'converted-assets'
        [System.IO.Directory]::CreateDirectory($convertedAssets) | Out-Null
        foreach ($name in @('kick.ogg', 'snare.ogg', 'bg.jpg')) { Set-Content -LiteralPath (Join-Path $convertedAssets $name) -Value 'test' }
        $convertedScore = Get-FolderReferenceScore $convertedAssets $refs
        if ($convertedScore.Hits -ne 3) { throw '変換済み音声の照合テストに失敗しました。' }
        $indexOnlyChart = Join-Path $testRoot 'index-only.bms'
        $uniqueReference = [guid]::NewGuid().ToString('N')
        Set-Content -LiteralPath $indexOnlyChart -Encoding UTF8 -Value "#TITLE Index Only`n#WAV01 $uniqueReference-a.wav`n#WAV02 $uniqueReference-b.wav`n#BMP01 $uniqueReference-c.png"
        $indexOnlyResult = Find-ParentFolder $indexOnlyChart $testRoot $index
        if ($indexOnlyResult) { throw '索引不一致時の親曲判定テストに失敗しました。' }
        $partialBase = Join-Path $testRoot 'partial-base'
        [System.IO.Directory]::CreateDirectory($partialBase) | Out-Null
        foreach ($name in @('kick.wav','snare.wav','bg.png')) { Set-Content -LiteralPath (Join-Path $partialBase $name) -Value 'base' }
        Set-Content -LiteralPath (Join-Path $partialBase 'base.bms') -Encoding UTF8 -Value "#TITLE Test`n#WAV01 kick.wav`n#WAV02 snare.wav`n#BMP01 bg.png"
        $manualDifference = Join-Path $testRoot 'manual-difference.bms'
        Set-Content -LiteralPath $manualDifference -Encoding UTF8 -Value "#TITLE Test [DIFFERENCE]`n#WAV01 kick.wav`n#WAV02 snare.wav`n#BMP01 bg.png`n#00111:0100"
        $partialEntry = [pscustomobject]@{ md5=(Get-FileHash -LiteralPath $manualDifference -Algorithm MD5).Hash.ToLowerInvariant(); sha256=''; title='Test' }
        Set-PartialInstall $partialEntry -BaseFolder $partialBase
        $script:PartialInstalls = @{}
        Load-PartialInstalls
        if (-not (Get-PartialInstall $partialEntry)) { throw '本体のみ取得状態の保存・再読込テストに失敗しました。' }
        $partialComplete = Install-DownloadedEntry $partialEntry $manualDifference $testRoot $null
        if ($partialComplete.Status -ne '導入済み' -or -not (Test-Path -LiteralPath (Join-Path $partialBase 'manual-difference.bms')) -or (Get-PartialInstall $partialEntry)) { throw '本体取得済み→差分D&D補完テストに失敗しました。' }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $pendingDifference = Join-Path $testRoot 'pending-difference'
        $basePackage = Join-Path $testRoot 'base-package'
        $pairedMusic = Join-Path $testRoot 'paired-music'
        [System.IO.Directory]::CreateDirectory($pendingDifference) | Out-Null
        [System.IO.Directory]::CreateDirectory($basePackage) | Out-Null
        [System.IO.Directory]::CreateDirectory($pairedMusic) | Out-Null
        Copy-Item -LiteralPath $manualDifference -Destination (Join-Path $pendingDifference 'manual-difference.bms')
        foreach ($name in @('kick.wav','snare.wav','bg.png')) { Set-Content -LiteralPath (Join-Path $basePackage $name) -Value 'base' }
        Set-Content -LiteralPath (Join-Path $basePackage 'base.bms') -Encoding UTF8 -Value "#TITLE Test`n#WAV01 kick.wav`n#WAV02 snare.wav`n#BMP01 bg.png"
        $baseZip = Join-Path $testRoot 'base-package.zip'
        [System.IO.Compression.ZipFile]::CreateFromDirectory($basePackage, $baseZip)
        if (-not (Test-EntryTitleMatchesCandidate $partialEntry 'Test [NORMAL]') -or (Test-EntryTitleMatchesCandidate $partialEntry 'Unrelated Song')) { throw '元曲タイトル照合テストに失敗しました。' }
        $wrongBaseMusic = Join-Path $testRoot 'wrong-base-music'
        [System.IO.Directory]::CreateDirectory($wrongBaseMusic) | Out-Null
        $wrongBaseEntry = [pscustomobject]@{ md5=('e' * 32); sha256=''; title='Unrelated Song [HARD]' }
        $wrongBaseRejected = $false
        try { [void](Install-BasePackageOnly $wrongBaseEntry $baseZip $wrongBaseMusic) } catch { $wrongBaseRejected = $_.Exception.Message -match '対象曲と同名' }
        if (-not $wrongBaseRejected -or @(Get-ChildItem -LiteralPath $wrongBaseMusic -Directory).Count -ne 0) { throw '別曲パッケージの元曲誤配置防止テストに失敗しました。' }
        Set-PartialInstall $partialEntry -PendingFolder $pendingDifference
        $pairedResult = Install-PendingWithBasePackage $partialEntry $baseZip $pendingDifference $pairedMusic
        if ($pairedResult.Status -ne '導入済み' -or @(Get-ChartFiles $pairedMusic).Count -lt 2 -or (Get-PartialInstall $partialEntry)) { throw '差分取得済み→本体DL・D&D補完テストに失敗しました。' }
        if ((Test-AllowAlternativeSource 'url') -or -not (Test-AllowAlternativeSource 'url_diff')) { throw '元曲取得時の差分用代替URL禁止テストに失敗しました。' }
        $candidateMusic = Join-Path $testRoot 'candidate-music'
        [System.IO.Directory]::CreateDirectory($candidateMusic) | Out-Null
        $script:SessionResourceFolders = @{}
        Set-PartialInstall $partialEntry -BasePackagePath $baseZip
        $candidateResult = Install-DownloadedEntry $partialEntry $manualDifference $candidateMusic $null
        if ($candidateResult.Status -ne '導入済み' -or @(Get-ChartFiles $candidateMusic).Count -lt 2 -or -not (Test-Path -LiteralPath $baseZip -PathType Leaf) -or (Get-PartialInstall $partialEntry)) { throw '保存済み元曲候補→差分D&D再照合テストに失敗しました。' }
        if (-not $script:SessionIndexDirty -or $script:SessionIndexedFolders.Count -lt 1) { throw '配置後の終了時索引保存判定テストに失敗しました。' }
        $cleanupInbox = Join-Path $testRoot 'cleanup-inbox'
        $cleanupDownloads = Join-Path $testRoot 'cleanup-downloads'
        $cleanupPending = Join-Path $cleanupInbox 'pending'
        [System.IO.Directory]::CreateDirectory($cleanupPending) | Out-Null
        [System.IO.Directory]::CreateDirectory($cleanupDownloads) | Out-Null
        Set-Content -LiteralPath (Join-Path $cleanupPending 'pending.bms') -Value '#TITLE pending'
        $cleanupDownload = Join-Path $cleanupDownloads 'cached.zip'
        Set-Content -LiteralPath $cleanupDownload -Value 'cache'
        $outsideCache = Join-Path $testRoot 'keep-cache.zip'
        Set-Content -LiteralPath $outsideCache -Value 'keep'
        $cleanupEntry = [pscustomobject]@{ md5=('e' * 32); sha256=''; title='Cleanup' }
        Set-PartialInstall $cleanupEntry -PendingFolder $cleanupPending -BasePackagePath $cleanupDownload
        $script:DownloadCachePath = Join-Path $testRoot 'cleanup-download-cache.json'
        $script:DownloadCache = @{ 'https://example.invalid/delete.zip'=$cleanupDownload; 'https://example.invalid/keep.zip'=$outsideCache }
        $cleanupResult = Clear-PendingAndDownloadStorage $cleanupInbox $cleanupDownloads
        if ($cleanupResult.InboxItems -ne 1 -or $cleanupResult.DownloadFiles -ne 1 -or (Test-Path -LiteralPath $cleanupPending) -or (Test-Path -LiteralPath $cleanupDownload) -or -not (Test-Path -LiteralPath $outsideCache) -or (Get-PartialInstall $cleanupEntry) -or $script:DownloadCache.ContainsKey('https://example.invalid/delete.zip') -or -not $script:DownloadCache.ContainsKey('https://example.invalid/keep.zip')) { throw '配置待ち・ダウンロードキャッシュ一括削除テストに失敗しました。' }
        $script:SessionResourceFolders = @{}
        $pendingTest = Join-Path $testRoot 'pending-test'
        $musicTest = Join-Path $testRoot 'music-test'
        [System.IO.Directory]::CreateDirectory($pendingTest) | Out-Null
        [System.IO.Directory]::CreateDirectory($musicTest) | Out-Null
        Copy-Item -LiteralPath $chart -Destination (Join-Path $pendingTest 'test.bms')
        foreach ($name in @('kick.ogg', 'snare.ogg', 'bg.jpg')) { Set-Content -LiteralPath (Join-Path $pendingTest $name) -Value 'test' }
        $pendingResult = Install-PendingFolder $entry $pendingTest $musicTest $null
        $pendingChartCount = @(Get-ChartFiles $musicTest).Count
        if ($pendingResult.Status -ne '導入済み' -or $pendingChartCount -ne 1) { throw "配置待ち再試行テストに失敗しました。状態=$($pendingResult.Status) / 譜面=$pendingChartCount" }
        if ((Get-SafeFileName 'a:b') -match ':') { throw 'ファイル名安全化テストに失敗しました。' }
        if (Get-Command 'tar.exe' -ErrorAction SilentlyContinue) {
            $archiveSource = Join-Path $testRoot 'archive-source'
            $archiveOutput = Join-Path $testRoot 'archive-output'
            $archivePath = Join-Path $testRoot 'test.tar'
            [System.IO.Directory]::CreateDirectory($archiveSource) | Out-Null
            Set-Content -LiteralPath (Join-Path $archiveSource 'inside.bms') -Encoding UTF8 -Value '#TITLE ArchiveTest'
            $quotedArchive = Quote-NativePath $archivePath
            $quotedSource = Quote-NativePath $archiveSource
            [void](Invoke-WindowsArchiveTool ('-cf ' + $quotedArchive + ' -C ' + $quotedSource + ' .'))
            Expand-OtherArchiveSafely $archivePath $archiveOutput
            if (-not (Test-Path -LiteralPath (Join-Path $archiveOutput 'inside.bms') -PathType Leaf)) { throw 'ZIP以外の書庫展開テストに失敗しました。' }
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $extensionlessZip = Join-Path $testRoot 'download-without-extension'
            $zipOutput = Join-Path $testRoot 'zip-output'
            [System.IO.Compression.ZipFile]::CreateFromDirectory($archiveSource, $extensionlessZip)
            Expand-DownloadedFile $extensionlessZip $zipOutput
            if (-not (Test-Path -LiteralPath (Join-Path $zipOutput 'inside.bms') -PathType Leaf)) { throw '拡張子のないZIP展開テストに失敗しました。' }
            $nestedLeafSource = Join-Path $testRoot 'nested-leaf-source'
            $nestedMidSource = Join-Path $testRoot 'nested-mid-source'
            $nestedOuterSource = Join-Path $testRoot 'nested-outer-source'
            $nestedOutput = Join-Path $testRoot 'nested-output'
            [System.IO.Directory]::CreateDirectory((Join-Path $nestedLeafSource '二段下\譜面')) | Out-Null
            Set-Content -LiteralPath (Join-Path $nestedLeafSource '二段下\譜面\deep-difference.bms') -Encoding UTF8 -Value '#TITLE DeepDifference'
            [System.IO.Directory]::CreateDirectory((Join-Path $nestedMidSource '差分パック')) | Out-Null
            [System.IO.Compression.ZipFile]::CreateFromDirectory($nestedLeafSource, (Join-Path $nestedMidSource '差分パック\leaf.zip'))
            [System.IO.Directory]::CreateDirectory((Join-Path $nestedOuterSource '作者フォルダ')) | Out-Null
            [System.IO.Compression.ZipFile]::CreateFromDirectory($nestedMidSource, (Join-Path $nestedOuterSource '作者フォルダ\mid.zip'))
            $nestedOuterZip = Join-Path $testRoot 'nested-outer.zip'
            [System.IO.Compression.ZipFile]::CreateFromDirectory($nestedOuterSource, $nestedOuterZip)
            Expand-DownloadedFile $nestedOuterZip $nestedOutput
            $nestedCharts = @(Get-ChartFiles $nestedOutput)
            if ($nestedCharts.Count -ne 1 -or $nestedCharts[0].Name -ne 'deep-difference.bms') { throw '複数階層・入れ子書庫内の差分検出テストに失敗しました。' }
        }
        $selfTestSevenZip = Get-SevenZipPath
        if ($selfTestSevenZip) {
            $passwordSource = Join-Path $testRoot 'password-source.bms'
            $passwordArchive = Join-Path $testRoot 'password-protected.7z'
            $passwordOutput = Join-Path $testRoot 'password-output'
            Set-Content -LiteralPath $passwordSource -Encoding UTF8 -Value '#TITLE PasswordProtected'
            [void](Invoke-SevenZip $selfTestSevenZip ('a -t7z -y -bd -bb0 -psecret -mhe=on -- ' + (Quote-NativePath $passwordArchive) + ' ' + (Quote-NativePath $passwordSource)) 10)
            $passwordTimer = [System.Diagnostics.Stopwatch]::StartNew()
            $passwordRejected = $false
            try { Expand-WithSevenZipSafely $selfTestSevenZip $passwordArchive $passwordOutput }
            catch { $passwordRejected = $true }
            $passwordTimer.Stop()
            if (-not $passwordRejected -or $passwordTimer.Elapsed.TotalSeconds -gt 10) { throw 'パスワード付き書庫の非対話打ち切りテストに失敗しました。' }
        }
        $sfxSource = Join-Path $testRoot 'sfx-source'
        $sfxZip = Join-Path $testRoot 'sfx-payload.zip'
        $sfxExe = Join-Path $testRoot 'legacy-sfx.exe'
        $sfxOutput = Join-Path $testRoot 'sfx-output'
        [System.IO.Directory]::CreateDirectory($sfxSource) | Out-Null
        Set-Content -LiteralPath (Join-Path $sfxSource 'sfx-chart.bms') -Encoding UTF8 -Value '#TITLE EmbeddedArchive'
        [System.IO.Compression.ZipFile]::CreateFromDirectory($sfxSource, $sfxZip)
        $sfxStream = [System.IO.File]::Create($sfxExe)
        $payloadStream = [System.IO.File]::OpenRead($sfxZip)
        try {
            $stub = New-Object byte[] 512
            $stub[0] = 0x4D; $stub[1] = 0x5A
            $sfxStream.Write($stub, 0, $stub.Length)
            $payloadStream.CopyTo($sfxStream)
        } finally { $payloadStream.Dispose(); $sfxStream.Dispose() }
        Expand-DownloadedFile $sfxExe $sfxOutput
        if (-not (Test-Path -LiteralPath (Join-Path $sfxOutput 'sfx-chart.bms') -PathType Leaf)) { throw '自己解凍EXE内の埋め込み書庫展開テストに失敗しました。' }
        $htmlTest = Join-Path $testRoot 'download-page'
        Set-Content -LiteralPath $htmlTest -Encoding UTF8 -Value '<!doctype html><meta charset="utf-8"><title>Download</title><p>低画質版 <a href="https://drive.google.com/file/d/test-file-id/view">Download</a></p>'
        if (-not (Test-DownloadedFileIsHtml $htmlTest)) { throw '配布ページ判定テストに失敗しました。' }
        $pageLinks = @(Get-DownloadLinksFromPage $htmlTest 'https://example.com/page')
        if ($pageLinks.Count -ne 1) { throw '配布ページ内のリンク検出テストに失敗しました。' }
        if ((Convert-ToDirectDownloadUrl $pageLinks[0].Url) -notmatch 'drive\.usercontent\.google\.com/download\?id=test-file-id') { throw 'Google Driveリンク変換テストに失敗しました。' }
        $driveWarningTest = Join-Path $testRoot 'drive-warning.html'
        Set-Content -LiteralPath $driveWarningTest -Encoding UTF8 -Value '<!doctype html><form action="https://drive.usercontent.google.com/download" method="get"><input type="hidden" name="id" value="large-file-id"><input type="hidden" name="confirm" value="t"><input type="hidden" name="uuid" value="warning-token"></form>'
        $driveWarningLinks = @(Get-DownloadLinksFromPage $driveWarningTest 'https://drive.usercontent.google.com/download?id=large-file-id')
        if ($driveWarningLinks.Count -ne 1 -or $driveWarningLinks[0].Url -notmatch 'id=large-file-id.*confirm=t.*uuid=warning-token') { throw 'Google Drive大容量ファイル確認ページの解析テストに失敗しました。' }
        $waybackDirect = Convert-ToDirectDownloadUrl 'https://web.archive.org/web/20190322230325*/https://example.com/song.rar'
        if ($waybackDirect -ne 'https://web.archive.org/web/20190322230325id_/https://example.com/song.rar') { throw 'Wayback Machine実体URL変換テストに失敗しました。' }
        $titlePageTest = Join-Path $testRoot 'title-page.html'
        Set-Content -LiteralPath $titlePageTest -Encoding UTF8 -Value '<!doctype html><meta charset="utf-8"><table><tr><td>別の曲 [ANOTHER]</td><td><a href="other.zip">DL</a></td></tr><tr><td>目的の曲 [INSANE]</td><td><a href="target.zip">ダウンロード</a></td></tr></table>'
        $titleLinks = @(Get-DownloadLinksFromPage $titlePageTest 'https://example.com/list.html' '目的の曲 [INSANE]')
        if ($titleLinks.Count -lt 2 -or $titleLinks[0].Url -ne 'https://example.com/target.zip') { throw '差分名による配布ページ内リンク優先テストに失敗しました。' }
        $script:Md5UrlMapPath = Join-Path $testRoot 'bms-md5-url-map.tsv'
        $script:Md5UrlMap = $null
        $script:SourceUrlCache = @{}
        $mappedMd5 = '1234567890abcdef1234567890abcdef'
        Set-Content -LiteralPath $script:Md5UrlMapPath -Encoding UTF8 -Value "$mappedMd5`thttps://example.invalid/base.zip`thttps://example.invalid/difference.bms"
        $emptyUrlEntry = [pscustomobject]@{ md5=$mappedMd5; title='Mapped'; url=''; url_diff='' }
        $emptyUrlPlan = Get-PreflightSourceUrl $emptyUrlEntry 'https://example.invalid/table.json' 'url_diff'
        if (-not $emptyUrlPlan.Complemented -or $emptyUrlPlan.Url -notmatch '^https://example\.invalid/') { throw '空の配布URLのMD5補完テストに失敗しました。' }
        $baseOnlyPlan = Get-PreflightSourceUrl $emptyUrlEntry 'https://example.invalid/table.json' 'url'
        if ($baseOnlyPlan.Complemented -or $baseOnlyPlan.Url) { throw '元曲URLに差分MD5代替URLを流用しています。' }
        $brokenUrlEntry = [pscustomobject]@{ md5=$mappedMd5; title='Broken'; url_diff='http://gnqg.rosx.net/dead.zip' }
        $brokenUrlPlan = Get-PreflightSourceUrl $brokenUrlEntry 'https://example.invalid/table.json' 'url_diff'
        if (-not $brokenUrlPlan.Complemented -or $brokenUrlPlan.Url -match 'gnqg\.rosx\.net') { throw '既知のリンク切れURLのMD5補完テストに失敗しました。' }
        $goodUrlEntry = [pscustomobject]@{ md5=$mappedMd5; title='Good'; url_diff='https://example.invalid/original.zip' }
        $goodUrlPlan = Get-PreflightSourceUrl $goodUrlEntry 'https://example.invalid/table.json' 'url_diff'
        if ($goodUrlPlan.Complemented -or $goodUrlPlan.Url -ne 'https://example.invalid/original.zip') { throw '正常な難易度表URLを優先するテストに失敗しました。' }
        $script:DownloadCachePath = Join-Path $testRoot 'download-cache.json'
        $sharedUrl = 'https://example.invalid/shared-difference.bms'
        $script:DownloadCache = @{ $sharedUrl = $chart }
        $parallelEntry1 = [pscustomobject]@{ title='Parallel 1'; url_diff=$sharedUrl }
        $parallelEntry2 = [pscustomobject]@{ title='Parallel 2'; url_diff=$sharedUrl }
        $parallelRequests = @(
            [pscustomobject]@{ Key='one'; Entry=$parallelEntry1; DataUrl='https://example.invalid/'; PreferredProperty='' },
            [pscustomobject]@{ Key='two'; Entry=$parallelEntry2; DataUrl='https://example.invalid/'; PreferredProperty='' },
            [pscustomobject]@{ Key='override'; Entry=([pscustomobject]@{ title='Override'; url_diff='' }); DataUrl='https://example.invalid/'; PreferredProperty=''; OverrideUrl=$sharedUrl }
        )
        $parallelResults = Download-EntriesParallel $parallelRequests 10
        if ($parallelResults.Count -ne 3 -or $parallelResults['one'].Path -ne $chart -or $parallelResults['two'].Path -ne $chart -or $parallelResults['override'].Path -ne $chart) { throw '並行ダウンロードのURL共有・補完URLテストに失敗しました。' }
        if (-not [string]::IsNullOrWhiteSpace($DatabaseTestPath)) {
            $databaseFolder = Split-Path -Parent $DatabaseTestPath
            if ((Split-Path -Leaf $DatabaseTestPath) -ne 'songdata.db') { throw 'DBテスト用ファイル名はsongdata.dbにしてください。' }
            $databaseIndex = Get-SongDatabaseIndex $databaseFolder
            if ($databaseIndex.Rows.Count -ne 3) { throw 'songdata.db件数テストに失敗しました。' }
            if (-not $databaseIndex.ByMD5.ContainsKey('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')) { throw 'songdata.dbのMD5テストに失敗しました。' }
            if (-not $databaseIndex.BySHA256.ContainsKey(('b' * 64))) { throw 'songdata.dbのSHA-256テストに失敗しました。' }
        }
        Write-Output 'SELFTEST OK'
    } finally {
        $script:DownloadCachePath = $originalDownloadCachePath
        $script:DownloadCache = $originalDownloadCache
        $script:CachePath = $originalCachePath
        $script:ChartIndexCachePath = $originalChartIndexCachePath
        $script:PartialInstallPath = $originalPartialInstallPath
        $script:PartialInstalls = $originalPartialInstalls
        $script:LocalInstalledMD5 = $originalLocalInstalledMD5
        $script:LocalInstalledSHA256 = $originalLocalInstalledSHA256
        $script:Md5UrlMapPath = $originalMd5UrlMapPath
        $script:Md5UrlMap = $originalMd5UrlMap
        $script:SourceUrlCache = $originalSourceUrlCache
        if (Test-Path -LiteralPath $testRoot) { Remove-Item -LiteralPath $testRoot -Recurse -Force }
    }
}

if ($SelfTest) { Invoke-SelfTest; exit 0 }
if (-not [string]::IsNullOrWhiteSpace($TableTestUrl)) {
    Ensure-AppFolders
    $script:TableTestDetectedName = ''
    $script:TableNameDetectedCallback = { param($detectedName, $detectedUrl); $script:TableTestDetectedName = [string]$detectedName }
    $tableTest = Get-TableEntries $TableTestUrl
    $tableLevels = @($tableTest.Entries | ForEach-Object { Get-EntryText $_ 'level' '(未設定)' } | Sort-Object -Unique)
    [pscustomobject]@{
        Name = $tableTest.Name
        DetectedName = $script:TableTestDetectedName
        Symbol = $tableTest.Symbol
        HeaderUrl = $tableTest.HeaderUrl
        DataUrl = $tableTest.DataUrl
        Entries = $tableTest.Entries.Count
        Levels = $tableLevels -join ', '
        WithUrl = @($tableTest.Entries | Where-Object { Get-EntryDownloadUrl $_ }).Count
        SampleTitles = @($tableTest.Entries | Select-Object -First 5 | ForEach-Object { Get-EntryText $_ 'title' '(タイトルなし)' }) -join ' / '
    } | Format-List
    exit 0
}
function Get-DefaultChartDisplayOrder([object[]]$Items) {
    if (-not $Items) { return @() }
    # 未所持を先頭にし、同じグループ内では難易度表の元の順番を保ちます。
    return @($Items | Sort-Object OwnedRank, OriginalOrder)
}

function Find-OwnedSongFolderByTitle([object]$Entry, $DatabaseIndex) {
    if (-not $DatabaseIndex -or -not $DatabaseIndex.Directories) { return '' }
    $baseTitle = Get-EntryBaseTitle $Entry
    $titleKey = ConvertTo-MatchText $baseTitle
    if ($titleKey.Length -lt 4) { return '' }
    $directoryKeyProperty = $DatabaseIndex.PSObject.Properties['TitleDirectoryKeys']
    if (-not $directoryKeyProperty) {
        $directoryKeys = @($DatabaseIndex.Directories | ForEach-Object {
            [pscustomobject]@{ Path=[string]$_; Key=(ConvertTo-MatchText ([System.IO.Path]::GetFileName([string]$_))) }
        })
        $DatabaseIndex | Add-Member -NotePropertyName TitleDirectoryKeys -NotePropertyValue $directoryKeys
    } else {
        $directoryKeys = @($directoryKeyProperty.Value)
    }
    $matches = New-Object System.Collections.Generic.List[string]
    foreach ($directoryItem in $directoryKeys) {
        if ([string]$directoryItem.Key -and ([string]$directoryItem.Key).Contains($titleKey)) { [void]$matches.Add([string]$directoryItem.Path) }
    }
    if ($matches.Count -eq 0) { return '' }
    # 複数パッケージがある場合も、少なくとも元曲を所持していることは判断できます。
    return [string]$matches[0]
}

function New-ManualEntryHashIndex($EntryMap) {
    $md5Map = @{}
    $shaMap = @{}
    foreach ($pair in $EntryMap.GetEnumerator()) {
        $candidate = [pscustomobject]@{ RowKey=[string]$pair.Key; Mapped=$pair.Value }
        $md5 = Get-EntryHash $pair.Value.Entry 'md5'
        $sha = Get-EntryHash $pair.Value.Entry 'sha256'
        if ($md5) {
            if (-not $md5Map.ContainsKey($md5)) { $md5Map[$md5] = New-Object System.Collections.ArrayList }
            [void]$md5Map[$md5].Add($candidate)
        }
        if ($sha) {
            if (-not $shaMap.ContainsKey($sha)) { $shaMap[$sha] = New-Object System.Collections.ArrayList }
            [void]$shaMap[$sha].Add($candidate)
        }
    }
    return [pscustomobject]@{ Md5=$md5Map; Sha256=$shaMap }
}

function Get-ManualPackageMatches([string]$Path, $EntryMap, $PreparedIndex = $null) {
    $manualMatchTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $charts = @()
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw '選択したファイルが見つかりません。' }
    $hashIndex = if ($PreparedIndex) { $PreparedIndex } else { New-ManualEntryHashIndex $EntryMap }
    $md5Map = $hashIndex.Md5
    $shaMap = $hashIndex.Sha256
    $work = $null
    $keepWork = $false
    $package = $null
    $cacheKey = ''
    try {
        $extension = Get-DownloadedChartExtension $Path
        if (-not [string]::IsNullOrWhiteSpace($extension)) {
            $charts = @((Get-Item -LiteralPath $Path))
        } else {
            if (Test-DownloadedFileIsHtml $Path) { throw '選択したファイルはBMSや書庫ではなくWebページです。' }
            $cacheKey = Get-PackageCacheKey $Path
            if ($script:ExtractedPackageCache.ContainsKey($cacheKey) -and (Test-Path -LiteralPath $script:ExtractedPackageCache[$cacheKey].Root -PathType Container)) {
                $package = $script:ExtractedPackageCache[$cacheKey]
                $work = $package.Root
                $charts = [object[]]$package.Charts
                $keepWork = $true
            } else {
                $work = Join-Path $script:DataDir ('manual-scan-' + [guid]::NewGuid().ToString('N'))
                [System.IO.Directory]::CreateDirectory($work) | Out-Null
                [void](Expand-DownloadedFile $Path $work)
                $charts = @(Get-ChartFiles $work)
                $package = [pscustomobject]@{ Root=$work; Charts=$charts; ByMd5=@{}; BySha=@{}; Md5Complete=$false; ShaComplete=$false }
            }
        }
        if ($charts.Count -eq 0) { throw '選択したファイル内にBMS/BME/BML/PMS/BMSON譜面がありません。' }
        $found = @{}
        $number = 0
        foreach ($chart in $charts) {
            $number++
            if (($number % 25) -eq 0 -or $number -eq 1 -or $number -eq $charts.Count) {
                Invoke-UiPulse; Assert-NotCancelled; Report-OperationProgress '手動差分を照合中' $number $charts.Count
            }
            $md5 = (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant()
            Add-PerformanceCounter '手動ファイルMD5計算回数'
            if ($package -and -not $package.ByMd5.ContainsKey($md5)) { $package.ByMd5[$md5] = $chart }
            if ($md5Map.ContainsKey($md5)) {
                foreach ($candidate in $md5Map[$md5]) { $found[$candidate.RowKey] = $candidate }
                continue
            }
            $sha = (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            Add-PerformanceCounter '手動ファイルSHA256計算回数'
            if ($package -and -not $package.BySha.ContainsKey($sha)) { $package.BySha[$sha] = $chart }
            if ($shaMap.ContainsKey($sha)) {
                foreach ($candidate in $shaMap[$sha]) { $found[$candidate.RowKey] = $candidate }
            }
        }
        if ($package -and $cacheKey -and -not $script:ExtractedPackageCache.ContainsKey($cacheKey)) {
            $package.Md5Complete = $true
            $script:ExtractedPackageCache[$cacheKey] = $package
            $keepWork = $true
            Write-AppLog 'INFO' 'MANUAL_CACHE' ("一度だけ展開して再利用: $Path / $($charts.Count)譜面")
        }
        return @($found.GetEnumerator() | ForEach-Object { $_.Value })
    } finally {
        if (-not $keepWork -and $work -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force }
        $manualMatchTimer.Stop()
        Add-PerformanceMetric '手動ファイル展開・難易度表照合' $manualMatchTimer.Elapsed.TotalMilliseconds $(if ($charts) { $charts.Count } else { 0 })
    }
}

function Clear-ManualPackageCache([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    try { $cacheKey = Get-PackageCacheKey $Path } catch { return }
    if (-not $script:ExtractedPackageCache.ContainsKey($cacheKey)) { return }
    $root = [string]$script:ExtractedPackageCache[$cacheKey].Root
    $script:ExtractedPackageCache.Remove($cacheKey)
    if ($root -and (Test-Path -LiteralPath $root -PathType Container)) {
        $dataRoot = [System.IO.Path]::GetFullPath($script:DataDir).TrimEnd('\') + '\'
        $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
        if ($rootFull.StartsWith($dataRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function Save-ManualChartGroupToInbox([string]$SourceFolder, [System.IO.FileInfo[]]$Charts, [string]$SourcePath, [string]$Reason) {
    if (-not $Charts -or $Charts.Count -eq 0) { return $null }
    $metadata = Get-ChartMetadata $Charts[0].FullName
    $title = if ([string]::IsNullOrWhiteSpace([string]$metadata.Title)) { $Charts[0].BaseName } else { [string]$metadata.Title }
    $folderName = '手動要確認-' + (Get-SafeFileName $title) + '-' + [guid]::NewGuid().ToString('N').Substring(0,6)
    $pending = Join-Path $script:InboxDir $folderName
    [System.IO.Directory]::CreateDirectory($pending) | Out-Null
    $count = Copy-NewFiles $SourceFolder $pending
    if ($count -le 0) {
        Remove-Item -LiteralPath $pending -Recurse -Force -ErrorAction SilentlyContinue
        return $null
    }
    Write-AppLog 'WARN' 'MANUAL_PENDING' ("判定保留として受信箱へ保存: $pending / $count ファイル / 理由: $Reason / 元ファイル: $SourcePath")
    return [pscustomobject]@{ Folder=$pending; Count=$count; Reason=$Reason }
}

function Install-ManualStandalonePackage([string]$Path, [string]$MusicPath, $DatabaseIndex) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw '選択したファイルが見つかりません。' }
    if (Test-DownloadedFileIsHtml $Path) { throw '選択したファイルはBMSや書庫ではなくWebページです。' }
    $work = Join-Path $script:DataDir ('manual-package-' + [guid]::NewGuid().ToString('N'))
    $keepWork = $false
    try {
        if (-not [string]::IsNullOrWhiteSpace((Get-DownloadedChartExtension $Path))) {
            [System.IO.Directory]::CreateDirectory($work) | Out-Null
            [void](Copy-DownloadedChartToFolder $Path $work)
        } else {
            $cacheKey = Get-PackageCacheKey $Path
            if ($script:ExtractedPackageCache.ContainsKey($cacheKey) -and (Test-Path -LiteralPath $script:ExtractedPackageCache[$cacheKey].Root -PathType Container)) {
                $work = [string]$script:ExtractedPackageCache[$cacheKey].Root
                $keepWork = $true
                Write-AppLog 'INFO' 'MANUAL_CACHE' ("楽曲判定にも展開済みデータを再利用: $Path")
            } else {
                [System.IO.Directory]::CreateDirectory($work) | Out-Null
                Expand-DownloadedFile $Path $work
            }
        }
        $charts = @(Get-ChartFiles $work)
        if ($charts.Count -eq 0) { throw 'ファイル内にBMS/BME/BML/PMS/BMSON譜面がありません。' }
        $installed = 0
        $alreadyOwned = 0
        $ambiguous = 0
        $pending = 0
        $pendingFolders = New-Object System.Collections.Generic.List[string]
        $details = New-Object System.Collections.Generic.List[string]
        $groups = @($charts | Group-Object DirectoryName)
        foreach ($group in $groups) {
            Assert-NotCancelled
            $groupCharts = @($group.Group)
            $baseTitles = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
            $bestChart = $null
            $bestHits = -1
            $bestRatio = 0.0
            foreach ($chart in $groupCharts) {
                $metadata = Get-ChartMetadata $chart.FullName
                $baseTitle = [regex]::Replace([string]$metadata.Title, '\s*[\[\(（【][^\]\)）】]{1,60}[\]\)）】]\s*$', '').Trim()
                $baseKey = ConvertTo-MatchText $baseTitle
                if ($baseKey.Length -ge 4) { [void]$baseTitles.Add($baseKey) }
                $refs = @(Get-ChartReferences $chart.FullName)
                $score = Get-FolderReferenceScore $chart.DirectoryName $refs
                if ($refs.Count -ge 3 -and $score.Hits -ge 3 -and $score.Ratio -ge 0.50 -and ($score.Hits -gt $bestHits -or ($score.Hits -eq $bestHits -and $score.Ratio -gt $bestRatio))) {
                    $bestChart = $chart
                    $bestHits = $score.Hits
                    $bestRatio = $score.Ratio
                }
            }
            if (-not $bestChart -or $baseTitles.Count -gt 1) {
                $reason = if (-not $bestChart) { '楽曲本体として再生可能か確認できません' } else { '複数楽曲が同じフォルダに混在しています' }
                $saved = Save-ManualChartGroupToInbox ([string]$group.Name) $groupCharts $Path $reason
                if ($saved) { $pending++; [void]$pendingFolders.Add([string]$saved.Folder); [void]$details.Add("受信箱へ保留: $($saved.Folder) ($($saved.Count) ファイル)") }
                else { $ambiguous++; [void]$details.Add("要確認: $($group.Name)") }
                continue
            }
            $existingFolder = Find-ParentFolder $bestChart.FullName $MusicPath $DatabaseIndex
            if ($existingFolder) {
                $alreadyOwned++
                [void]$details.Add("元から所持: $existingFolder")
                continue
            }
            $metadata = Get-ChartMetadata $bestChart.FullName
            $title = if ([string]::IsNullOrWhiteSpace([string]$metadata.Title)) { $bestChart.BaseName } else { [string]$metadata.Title }
            $artist = if ([string]::IsNullOrWhiteSpace([string]$metadata.Artist)) { 'Unknown' } else { [string]$metadata.Artist }
            $newFolder = Join-Path $MusicPath (Get-SafeFileName ("[$artist] $title"))
            if (Test-Path -LiteralPath $newFolder) {
                $saved = Save-ManualChartGroupToInbox ([string]$group.Name) $groupCharts $Path "同名の曲フォルダがあり、安全に統合できません: $newFolder"
                if ($saved) { $pending++; [void]$pendingFolders.Add([string]$saved.Folder); [void]$details.Add("同名フォルダのため受信箱へ保留: $($saved.Folder)") }
                else { $ambiguous++; [void]$details.Add("同名フォルダがあるため要確認: $newFolder") }
                continue
            }
            [System.IO.Directory]::CreateDirectory($newFolder) | Out-Null
            $count = Copy-NewFiles ([string]$group.Name) $newFolder
            if ($count -le 0) {
                Remove-Item -LiteralPath $newFolder -Recurse -Force -ErrorAction SilentlyContinue
                $ambiguous++
                [void]$details.Add("配置できるファイルなし: $($group.Name)")
                continue
            }
            $installed++
            [void]$details.Add("楽曲本体を配置: $newFolder ($count ファイル)")
            Write-AppLog 'INFO' 'MANUAL_PACKAGE' ("楽曲本体を配置: $newFolder / $count ファイル / 元ファイル: $Path")
        }
        return [pscustomobject]@{ Installed=$installed; AlreadyOwned=$alreadyOwned; Pending=$pending; PendingFolders=[string[]]$pendingFolders.ToArray(); Ambiguous=$ambiguous; Details=[string[]]$details.ToArray() }
    } finally {
        if (-not $keepWork -and (Test-Path -LiteralPath $work)) { Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Retry-PendingAfterManualPlacement($EntryMap, [string]$MusicPath, $DatabaseIndex) {
    $retryTimer = [System.Diagnostics.Stopwatch]::StartNew()
    $md5Map = @{}
    $shaMap = @{}
    foreach ($mapped in @($EntryMap.Values)) {
        $md5 = Get-EntryHash $mapped.Entry 'md5'
        $sha = Get-EntryHash $mapped.Entry 'sha256'
        if ($md5 -and -not $md5Map.ContainsKey($md5)) { $md5Map[$md5] = $mapped }
        if ($sha -and -not $shaMap.ContainsKey($sha)) { $shaMap[$sha] = $mapped }
    }
    $installed = 0
    $rowResults = New-Object System.Collections.Generic.List[object]
    $pendingFolders = @(Get-PendingFolders)
    Add-PerformanceCounter '配置待ちフォルダ確認件数' $pendingFolders.Count
    if ($pendingFolders.Count -eq 0) {
        $retryTimer.Stop()
        Add-PerformanceMetric '配置待ち再試行' $retryTimer.Elapsed.TotalMilliseconds 0
        return [pscustomobject]@{ Installed=0; RowResults=@() }
    }
    if (Test-LibraryIndexAvailable) {
        $placementIndex = if ($script:CurrentLibraryIndex) { $script:CurrentLibraryIndex } else { Get-PersistentLibraryIndex }
        Add-PerformanceCounter '配置待ちで高速索引を利用'
    } else {
        $refreshedDirectories = @(Get-ChartFiles $MusicPath | Select-Object -ExpandProperty DirectoryName -Unique)
        $placementIndex = [pscustomobject]@{ Directories=$refreshedDirectories }
    }
    foreach ($folder in $pendingFolders) {
        Assert-NotCancelled
        $mapped = $null
        foreach ($chart in @(Get-ChartFiles $folder.FullName)) {
            $md5 = (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant()
            Add-PerformanceCounter '配置待ちMD5計算回数'
            if ($md5Map.ContainsKey($md5)) { $mapped = $md5Map[$md5]; break }
            $sha = (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            Add-PerformanceCounter '配置待ちSHA256計算回数'
            if ($shaMap.ContainsKey($sha)) { $mapped = $shaMap[$sha]; break }
        }
        if (-not $mapped) { continue }
        $result = Install-PendingFolder $mapped.Entry $folder.FullName $MusicPath $placementIndex -IndexOnly
        if ($result.Status -ne '導入済み') { continue }
        Register-EntryInstalled $mapped.Entry
        $installed++
        [void]$rowResults.Add([pscustomobject]@{ Mapped=$mapped; Result=$result; Folder=$folder.FullName })
        $inboxRoot = [System.IO.Path]::GetFullPath($script:InboxDir).TrimEnd('\') + '\'
        $folderFull = [System.IO.Path]::GetFullPath($folder.FullName).TrimEnd('\') + '\'
        if ($folderFull.StartsWith($inboxRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $folder.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    $retryTimer.Stop()
    Add-PerformanceMetric '配置待ち再試行' $retryTimer.Elapsed.TotalMilliseconds $pendingFolders.Count
    return [pscustomobject]@{ Installed=$installed; RowResults=[object[]]$rowResults.ToArray() }
}

function Get-DroppedManualFiles([string[]]$Paths, [int]$MaximumFiles = 500) {
    $supported = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($extension in @('.bms','.bme','.bml','.pms','.bmson','.zip','.rar','.7z','.lzh','.lha','.gca','.exe','.tar','.gz','.bz2','.xz')) { [void]$supported.Add($extension) }
    $seen = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
    $files = New-Object System.Collections.Generic.List[string]
    $skipped = 0
    foreach ($path in $Paths) {
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $extension = [System.IO.Path]::GetExtension($path)
            if (-not [string]::IsNullOrWhiteSpace($extension) -and -not $supported.Contains($extension)) { $skipped++; continue }
            $full = [System.IO.Path]::GetFullPath($path)
            if ($seen.Add($full)) { [void]$files.Add($full) }
        } elseif (Test-Path -LiteralPath $path -PathType Container) {
            foreach ($item in @(Get-ChildItem -LiteralPath $path -Recurse -File -ErrorAction SilentlyContinue)) {
                if (-not $supported.Contains($item.Extension)) { $skipped++; continue }
                if ($seen.Add($item.FullName)) { [void]$files.Add($item.FullName) }
                if ($files.Count -gt $MaximumFiles) { throw "一度に処理できるファイルは$MaximumFiles 個までです。フォルダを分けてドロップしてください。" }
            }
        } else { $skipped++ }
        if ($files.Count -gt $MaximumFiles) { throw "一度に処理できるファイルは$MaximumFiles 個までです。ファイルを分けてドロップしてください。" }
    }
    return [pscustomobject]@{ Files=[string[]]$files.ToArray(); Skipped=$skipped }
}

if ($LibraryOnly) { return }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
Ensure-AppFolders
$null = Set-Content -LiteralPath $script:LogPath -Encoding UTF8 -Value ''
Load-DownloadCache
Load-LocalInstalledHashes
Load-SourceUrlCache
Load-PartialInstalls
$script:Settings = Load-Settings
if (@($script:Settings.MusicPaths).Count -eq 0 -and -not [string]::IsNullOrWhiteSpace([string]$script:Settings.MusicPath)) {
    $script:Settings.MusicPaths = @([string]$script:Settings.MusicPath)
}
$script:EntryMap = @{}
$script:ManualEntryMap = @{}
$script:CurrentDatabaseIndex = $null
$script:CurrentTable = $null
$script:CurrentTableUrl = ''
Write-AppLog 'INFO' 'STARTUP' 'アプリを起動しました。'

$form = New-Object System.Windows.Forms.Form
$form.Text = 'BMS 未所持譜面チェッカー・導入支援ツール'
$appIconPath = Join-Path $script:AppDir 'app-icon.ico'
if (Test-Path -LiteralPath $appIconPath -PathType Leaf) {
    try { $form.Icon = New-Object System.Drawing.Icon($appIconPath) }
    catch { Write-AppLog 'WARN' 'ICON' ('アプリアイコンを読み込めません: ' + $_.Exception.Message) }
}
$form.Size = New-Object System.Drawing.Size(1040, 850)
$form.MinimumSize = New-Object System.Drawing.Size(960, 720)
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Yu Gothic UI', 9)

$rootLabel = New-Object System.Windows.Forms.Label
$rootLabel.Text = '所持譜面の確認方法'
$rootLabel.SetBounds(18, 18, 160, 24)
$playerModeBox = New-Object System.Windows.Forms.ComboBox
$playerModeBox.SetBounds(178, 16, 210, 26)
$playerModeBox.DropDownStyle = 'DropDownList'
[void]$playerModeBox.Items.Add('beatoraja（DBで高速確認）')
[void]$playerModeBox.Items.Add('LR2・その他（曲フォルダを確認）')
$playerModeBox.SelectedIndex = $(if ([string]$script:Settings.PlayerMode -eq 'folder') { 1 } else { 0 })
$rootBox = New-Object System.Windows.Forms.TextBox
$rootBox.SetBounds(398, 16, 470, 26)
$rootBox.Text = $script:Settings.BeatorajaPath
$rootButton = New-Object System.Windows.Forms.Button
$rootButton.Text = '選ぶ…'
$rootButton.SetBounds(878, 14, 120, 30)

$musicLabel = New-Object System.Windows.Forms.Label
$musicLabel.Text = 'BMS曲フォルダ'
$musicLabel.SetBounds(18, 54, 160, 24)
$musicBox = New-Object System.Windows.Forms.TextBox
$musicBox.SetBounds(178, 52, 282, 26)
$musicBox.Text = $script:Settings.MusicPath
$musicButton = New-Object System.Windows.Forms.Button
$musicButton.Text = '登録フォルダ…'
$musicButton.SetBounds(470, 50, 105, 30)
$importBeatorajaButton = New-Object System.Windows.Forms.Button
$importBeatorajaButton.Text = 'beatorajaから読込'
$importBeatorajaButton.SetBounds(581, 50, 135, 30)
$indexScanButton = New-Object System.Windows.Forms.Button
$indexScanButton.Text = '索引を更新'
$indexScanButton.SetBounds(722, 50, 146, 30)
$fullIndexScanButton = New-Object System.Windows.Forms.Button
$fullIndexScanButton.Text = '索引を再作成'
$fullIndexScanButton.SetBounds(874, 50, 124, 30)
$indexHelpTip = New-Object System.Windows.Forms.ToolTip
$indexHelpTip.SetToolTip($indexScanButton, '追加・変更・削除されたBMSを確認し、次回起動でも使える情報として保存します。')
$indexHelpTip.SetToolTip($fullIndexScanButton, '保存情報を破棄し、すべての譜面情報を作り直します。通常は必要ありません。')

$tableLabel = New-Object System.Windows.Forms.Label
$tableLabel.Text = '難易度表'
$tableLabel.SetBounds(18, 90, 160, 24)
$tableBox = New-Object System.Windows.Forms.ComboBox
$tableBox.SetBounds(178, 88, 405, 26)
$tableBox.DropDownStyle = 'DropDown'
$tableBox.DropDownWidth = 620
$tableBox.DisplayMember = 'Name'
$tableBox.ValueMember = 'Url'
$knownTableUrls = New-Object System.Collections.Generic.HashSet[string]([System.StringComparer]::OrdinalIgnoreCase)
foreach ($preset in $script:DefaultTables) {
    [void]$tableBox.Items.Add($preset)
    [void]$knownTableUrls.Add([string]$preset.Url)
}
foreach ($savedCustom in @($script:Settings.CustomTables)) {
    $customUrlProperty = $savedCustom.PSObject.Properties['Url']
    $customNameProperty = $savedCustom.PSObject.Properties['Name']
    $customUrl = if ($customUrlProperty) { [string]$customUrlProperty.Value } else { '' }
    $customName = if ($customNameProperty) { [string]$customNameProperty.Value } else { $customUrl }
    if ($customUrl -match '^https?://' -and $knownTableUrls.Add($customUrl)) {
        [void]$tableBox.Items.Add([pscustomobject]@{ Name=$customName; Url=$customUrl; IsCustom=$true })
    }
}
if ($script:Settings.Tables.Count -gt 0) {
    $savedTableUrl = [string]$script:Settings.Tables[0]
    if ($savedTableUrl -eq 'https://nekokan.dyndns.info/~lobsak/genocide/insane.html') {
        $savedTableUrl = 'https://darksabun.club/table/archive/insane1/'
        $script:Settings.Tables = @($savedTableUrl)
        Write-AppLog 'INFO' 'MIGRATION' '旧発狂BMS難易度表URLを現行DARKSABUN URLへ更新しました。'
    }
    $savedIndex = -1
    for ($presetIndex = 0; $presetIndex -lt $tableBox.Items.Count; $presetIndex++) {
        $itemUrlProperty = $tableBox.Items[$presetIndex].PSObject.Properties['Url']
        if ($itemUrlProperty -and [string]$itemUrlProperty.Value -eq $savedTableUrl) { $savedIndex = $presetIndex; break }
    }
    if ($savedIndex -ge 0) { $tableBox.SelectedIndex = $savedIndex } else { $tableBox.Text = $savedTableUrl }
} else {
    $tableBox.SelectedIndex = 2
}
$registerTableButton = New-Object System.Windows.Forms.Button
$registerTableButton.Text = '表を登録'
$registerTableButton.SetBounds(590, 86, 70, 30)
$removeTableButton = New-Object System.Windows.Forms.Button
$removeTableButton.Text = '登録削除'
$removeTableButton.SetBounds(666, 86, 67, 30)
$loadTableButton = New-Object System.Windows.Forms.Button
$loadTableButton.Text = '表を読み込む'
$loadTableButton.SetBounds(743, 86, 125, 30)
$scanButton = New-Object System.Windows.Forms.Button
$scanButton.Text = '選択レベルを検索'
$scanButton.SetBounds(878, 86, 120, 30)
$scanButton.Enabled = $false

$levelLabel = New-Object System.Windows.Forms.Label
$levelLabel.Text = '対象レベル'
$levelLabel.SetBounds(18, 126, 150, 24)
$levelList = New-Object System.Windows.Forms.CheckedListBox
$levelList.SetBounds(178, 122, 555, 88)
$levelList.CheckOnClick = $true
$levelList.MultiColumn = $true
$levelList.ColumnWidth = 74
$levelList.HorizontalScrollbar = $true
$levelList.IntegralHeight = $false
$levelAllButton = New-Object System.Windows.Forms.Button
$levelAllButton.Text = '全レベル選択'
$levelAllButton.SetBounds(743, 122, 125, 28)
$levelClearButton = New-Object System.Windows.Forms.Button
$levelClearButton.Text = '全レベル解除'
$levelClearButton.SetBounds(878, 122, 120, 28)
$levelFromBox = New-Object System.Windows.Forms.ComboBox
$levelFromBox.SetBounds(743, 157, 68, 26)
$levelFromBox.DropDownStyle = 'DropDownList'
$levelToLabel = New-Object System.Windows.Forms.Label
$levelToLabel.Text = '～'
$levelToLabel.TextAlign = 'MiddleCenter'
$levelToLabel.SetBounds(813, 157, 22, 26)
$levelToBox = New-Object System.Windows.Forms.ComboBox
$levelToBox.SetBounds(837, 157, 68, 26)
$levelToBox.DropDownStyle = 'DropDownList'
$levelRangeButton = New-Object System.Windows.Forms.Button
$levelRangeButton.Text = '範囲を選択'
$levelRangeButton.SetBounds(911, 155, 87, 30)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = '保存場所と難易度表を指定してください。'
$statusLabel.SetBounds(18, 216, 845, 24)
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.SetBounds(18, 241, 845, 11)
$progressBar.Minimum = 0
$progressBar.Maximum = 100
$progressBar.Value = 0
$progressBar.Style = 'Continuous'
$progressBar.Anchor = 'Top,Left,Right'
$script:UiProgressBar = $progressBar
$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Text = '中止する'
$cancelButton.SetBounds(878, 214, 120, 34)
$cancelButton.Enabled = $false

$dropPanel = New-Object System.Windows.Forms.Panel
$dropPanel.SetBounds(18, 256, 980, 36)
$dropPanel.Anchor = 'Top,Left,Right'
$dropPanel.BorderStyle = 'FixedSingle'
$dropPanel.BackColor = [System.Drawing.Color]::FromArgb(235, 245, 252)
$dropLabel = New-Object System.Windows.Forms.Label
$dropLabel.Text = 'ZIP・RAR・7z・GCA・自己解凍EXE・BMS、またはフォルダをここへドラッグ＆ドロップ'
$dropLabel.TextAlign = 'MiddleCenter'
$dropLabel.Dock = 'Fill'
$dropLabel.Font = New-Object System.Drawing.Font('Yu Gothic UI', 9, [System.Drawing.FontStyle]::Bold)
$dropPanel.Controls.Add($dropLabel)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.SetBounds(18, 298, 980, 458)
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AutoSizeColumnsMode = 'Fill'
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $true
$grid.ReadOnly = $false
$grid.RowHeadersVisible = $false
[void]$grid.Columns.Add((New-Object System.Windows.Forms.DataGridViewCheckBoxColumn -Property @{ Name='Get'; HeaderText='取得'; FillWeight=35 }))
[void]$grid.Columns.Add('Level', 'レベル')
[void]$grid.Columns.Add('Title', 'タイトル')
[void]$grid.Columns.Add('Artist', 'アーティスト')
[void]$grid.Columns.Add('State', '状態')
$differencePageColumn = New-Object System.Windows.Forms.DataGridViewButtonColumn
$differencePageColumn.Name = 'DifferencePage'
$differencePageColumn.HeaderText = '差分'
$differencePageColumn.Text = '差分ページ'
$differencePageColumn.UseColumnTextForButtonValue = $false
$differencePageColumn.FlatStyle = 'Flat'
[void]$grid.Columns.Add($differencePageColumn)
$songPageColumn = New-Object System.Windows.Forms.DataGridViewButtonColumn
$songPageColumn.Name = 'SongPage'
$songPageColumn.HeaderText = '楽曲'
$songPageColumn.UseColumnTextForButtonValue = $false
$songPageColumn.FlatStyle = 'Flat'
[void]$grid.Columns.Add($songPageColumn)
$grid.Columns['Level'].ReadOnly = $true
$grid.Columns['Title'].ReadOnly = $true
$grid.Columns['Artist'].ReadOnly = $true
$grid.Columns['State'].ReadOnly = $true
$grid.Columns['DifferencePage'].ReadOnly = $true
$grid.Columns['SongPage'].ReadOnly = $true
$grid.Columns['Level'].FillWeight = 45
$grid.Columns['Title'].FillWeight = 155
$grid.Columns['Artist'].FillWeight = 95
$grid.Columns['State'].FillWeight = 70
$grid.Columns['DifferencePage'].FillWeight = 70
$grid.Columns['SongPage'].FillWeight = 70
foreach ($column in $grid.Columns) { $column.SortMode = 'NotSortable' }

$downloadButton = New-Object System.Windows.Forms.Button
$downloadButton.Text = '未所持をまとめて取得'
$downloadButton.SetBounds(18, 766, 140, 34)
$downloadButton.Anchor = 'Bottom,Left'
$downloadButton.Enabled = $false
$manualInstallButton = New-Object System.Windows.Forms.Button
$manualInstallButton.Text = '手動ファイルを振り分け'
$manualInstallButton.SetBounds(164, 766, 160, 34)
$manualInstallButton.Anchor = 'Bottom,Left'
$manualInstallButton.Enabled = $false
$inboxButton = New-Object System.Windows.Forms.Button
$inboxButton.Text = '受信箱'
$inboxButton.SetBounds(330, 766, 70, 34)
$inboxButton.Anchor = 'Bottom,Left'
$selectAllButton = New-Object System.Windows.Forms.Button
$selectAllButton.Text = '全譜面選択'
$selectAllButton.SetBounds(406, 766, 85, 34)
$selectAllButton.Anchor = 'Bottom,Left'
$clearAllButton = New-Object System.Windows.Forms.Button
$clearAllButton.Text = '全譜面解除'
$clearAllButton.SetBounds(497, 766, 85, 34)
$clearAllButton.Anchor = 'Bottom,Left'
$retryPendingButton = New-Object System.Windows.Forms.Button
$retryPendingButton.Text = '配置待ち再試行'
$retryPendingButton.SetBounds(588, 766, 110, 34)
$retryPendingButton.Anchor = 'Bottom,Left'
$deletePendingButton = New-Object System.Windows.Forms.Button
$deletePendingButton.Text = '配置待ち・キャッシュ削除'
$deletePendingButton.SetBounds(704, 766, 150, 34)
$deletePendingButton.Anchor = 'Bottom,Left'
$logButton = New-Object System.Windows.Forms.Button
$logButton.Text = 'ログを見る'
$logButton.SetBounds(860, 766, 65, 34)
$logButton.Anchor = 'Bottom,Left'
$helpButton = New-Object System.Windows.Forms.Button
$helpButton.Text = '状態の説明'
$helpButton.SetBounds(931, 766, 67, 34)
$helpButton.Anchor = 'Bottom,Left'

$form.Controls.AddRange(@($rootLabel,$playerModeBox,$rootBox,$rootButton,$musicLabel,$musicBox,$musicButton,$importBeatorajaButton,$indexScanButton,$fullIndexScanButton,$tableLabel,$tableBox,$registerTableButton,$removeTableButton,$loadTableButton,$scanButton,$levelLabel,$levelList,$levelAllButton,$levelClearButton,$levelFromBox,$levelToLabel,$levelToBox,$levelRangeButton,$statusLabel,$progressBar,$cancelButton,$dropPanel,$grid,$downloadButton,$manualInstallButton,$inboxButton,$selectAllButton,$clearAllButton,$retryPendingButton,$deletePendingButton,$logButton,$helpButton))

$uiOperationProgress = {
    param($stage, $current, $total)
    $countText = if ($total -gt 0) { "$current / $total" } elseif ($current -gt 0) { "$current 件確認" } else { '準備中' }
    $titleText = if ([string]::IsNullOrWhiteSpace($script:CurrentOperationTitle)) { '' } else { '　' + $script:CurrentOperationTitle }
    $statusLabel.Text = "$stage`: $countText$titleText"
}

function Choose-Folder([string]$Description, [string]$Initial) {
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    if (-not [string]::IsNullOrWhiteSpace($Initial) -and (Test-Path -LiteralPath $Initial -PathType Container)) {
        $dialog.SelectedPath = $Initial
    }
    if ($dialog.ShowDialog($form) -eq 'OK') { return $dialog.SelectedPath }
    return $null
}

function Show-MusicFolderManager {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'BMSフォルダの登録'
    $dialog.Size = New-Object System.Drawing.Size(720, 390)
    $dialog.StartPosition = 'CenterParent'
    $dialog.Font = $form.Font
    $description = New-Object System.Windows.Forms.Label
    $description.Text = '登録したすべてのフォルダを所持確認と配置先検索に使用します。先頭が新しい楽曲の配置先です。'
    $description.SetBounds(14, 12, 675, 36)
    $list = New-Object System.Windows.Forms.ListBox
    $list.SetBounds(14, 52, 675, 220)
    foreach ($path in @(Get-RegisteredMusicPaths)) { [void]$list.Items.Add($path) }
    $add = New-Object System.Windows.Forms.Button
    $add.Text = '追加…'; $add.SetBounds(14, 282, 90, 30)
    $remove = New-Object System.Windows.Forms.Button
    $remove.Text = '削除'; $remove.SetBounds(110, 282, 75, 30)
    $primary = New-Object System.Windows.Forms.Button
    $primary.Text = '先頭へ'; $primary.SetBounds(191, 282, 75, 30)
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = '保存'; $ok.SetBounds(518, 282, 80, 30); $ok.DialogResult = 'OK'
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'キャンセル'; $cancel.SetBounds(604, 282, 85, 30); $cancel.DialogResult = 'Cancel'
    $add.Add_Click({
        $chosen = Choose-Folder '追加するBMSフォルダを選んでください。' $musicBox.Text
        if ($chosen -and -not @($list.Items | Where-Object { $_ -eq $chosen }).Count) { [void]$list.Items.Add($chosen); $list.SelectedIndex = $list.Items.Count - 1 }
    })
    $remove.Add_Click({ if ($list.SelectedIndex -ge 0) { $list.Items.RemoveAt($list.SelectedIndex) } })
    $primary.Add_Click({
        if ($list.SelectedIndex -gt 0) { $value = $list.SelectedItem; $list.Items.RemoveAt($list.SelectedIndex); $list.Items.Insert(0, $value); $list.SelectedIndex = 0 }
    })
    $dialog.Controls.AddRange(@($description,$list,$add,$remove,$primary,$ok,$cancel))
    $dialog.AcceptButton = $ok; $dialog.CancelButton = $cancel
    if ($dialog.ShowDialog($form) -ne 'OK') { return $false }
    $paths = @($list.Items | ForEach-Object { [string]$_ })
    $script:Settings.MusicPaths = $paths
    $script:Settings.MusicPath = if ($paths.Count -gt 0) { $paths[0] } else { '' }
    $musicBox.Text = $script:Settings.MusicPath
    Save-Settings $script:Settings
    return $true
}

function Update-CustomTableDisplayName([string]$Url, [string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
    $normalized = $Url.TrimEnd('/').ToLowerInvariant()
    $updated = $false
    for ($index = 0; $index -lt $tableBox.Items.Count; $index++) {
        $item = $tableBox.Items[$index]
        $urlProperty = $item.PSObject.Properties['Url']
        $customProperty = $item.PSObject.Properties['IsCustom']
        if ($urlProperty -and ([string]$urlProperty.Value).TrimEnd('/').ToLowerInvariant() -eq $normalized -and $customProperty -and [bool]$customProperty.Value) {
            if ([string]$item.Name -ne $Name) {
                $wasSelected = $tableBox.SelectedIndex -eq $index
                $tableBox.Items[$index] = [pscustomobject]@{ Name=$Name; Url=$Url; IsCustom=$true }
                if ($wasSelected) { $tableBox.SelectedIndex = $index }
                $updated = $true
            }
            break
        }
    }
    $customs = New-Object System.Collections.ArrayList
    foreach ($existing in @($script:Settings.CustomTables)) {
        $urlProperty = $existing.PSObject.Properties['Url']
        if ($urlProperty -and ([string]$urlProperty.Value).TrimEnd('/').ToLowerInvariant() -eq $normalized) {
            [void]$customs.Add([pscustomobject]@{ Name=$Name; Url=$Url })
            if (-not $existing.PSObject.Properties['Name'] -or [string]$existing.Name -ne $Name) { $updated = $true }
        } else { [void]$customs.Add($existing) }
    }
    $script:Settings.CustomTables = @($customs.ToArray())
    return $updated
}

function Add-TableUrlToSettings([string]$Url, [string]$Name = '') {
    if ($Url -notmatch '^https?://') { return $false }
    $normalized = $Url.TrimEnd('/').ToLowerInvariant()
    foreach ($item in $tableBox.Items) {
        $property = $item.PSObject.Properties['Url']
        if ($property -and ([string]$property.Value).TrimEnd('/').ToLowerInvariant() -eq $normalized) {
            if ($Name) { [void](Update-CustomTableDisplayName $Url $Name) }
            return $false
        }
    }
    $displayName = if ($Name) { $Name } else { Get-FriendlyTableNameFromUrl $Url }
    [void]$tableBox.Items.Add([pscustomobject]@{ Name=$displayName; Url=$Url; IsCustom=$true })
    $customs = New-Object System.Collections.ArrayList
    foreach ($existing in @($script:Settings.CustomTables)) { [void]$customs.Add($existing) }
    [void]$customs.Add([pscustomobject]@{ Name=$displayName; Url=$Url })
    $script:Settings.CustomTables = @($customs.ToArray())
    return $true
}

function Update-PlayerModeUi {
    $usesBeatorajaDatabase = $playerModeBox.SelectedIndex -eq 0
    $rootBox.Enabled = $usesBeatorajaDatabase
    $rootButton.Enabled = $usesBeatorajaDatabase
    if ($usesBeatorajaDatabase) {
        $rootButton.Text = '選ぶ…'
    } else {
        $rootButton.Text = '不要'
        $statusLabel.Text = 'LR2・その他では、BMS曲フォルダ内の譜面を直接確認します。初回のみ少し時間がかかります。'
    }
}

function Get-SelectedTableUrl {
    if ($tableBox.SelectedIndex -ge 0) {
        $selected = $tableBox.SelectedItem
        $urlProperty = $selected.PSObject.Properties['Url']
        if ($urlProperty -and $urlProperty.Value) { return [string]$urlProperty.Value }
    }
    return $tableBox.Text.Trim()
}

function Get-LevelSortKey([string]$Level) {
    $match = [regex]::Match($Level, '^(.*?)(-?\d+)(.*)$')
    if ($match.Success) {
        return ('0|{0}|{1:D5}|{2}' -f $match.Groups[1].Value, ([int]$match.Groups[2].Value + 1000), $match.Groups[3].Value)
    }
    return '1|' + $Level
}

function Populate-LevelList($Table, $Index = $null) {
    $previousLevels = @()
    if ($script:LevelValueByDisplay.Count -gt 0) {
        $previousLevels = @($levelList.CheckedItems | ForEach-Object { $script:LevelValueByDisplay[[string]$_] } | Where-Object { $_ })
    }
    $levelList.Items.Clear()
    $levelFromBox.Items.Clear()
    $levelToBox.Items.Clear()
    $script:LevelValueByDisplay = @{}
    $levels = @($Table.Entries | ForEach-Object { Get-EntryText $_ 'level' '(未設定)' } | Sort-Object -Unique | Sort-Object { Get-LevelSortKey $_ })
    $savedLevels = if ($previousLevels.Count -gt 0) { $previousLevels } else { @($script:Settings.SelectedLevels) }
    $useSavedLevels = @($levels | Where-Object { $savedLevels -contains $_ }).Count -gt 0
    foreach ($level in $levels) {
        $baseDisplay = if ([string]::IsNullOrWhiteSpace([string]$Table.Symbol)) { $level } elseif ($level.StartsWith([string]$Table.Symbol)) { $level } else { ([string]$Table.Symbol) + $level }
        $display = $baseDisplay
        $script:LevelValueByDisplay[$display] = $level
        $script:LevelValueByDisplay[$baseDisplay] = $level
        $shouldCheck = -not $useSavedLevels -or $savedLevels -contains $level
        [void]$levelList.Items.Add($display, $shouldCheck)
        [void]$levelFromBox.Items.Add($baseDisplay)
        [void]$levelToBox.Items.Add($baseDisplay)
    }
    if ($levels.Count -gt 0) {
        $levelFromBox.SelectedIndex = 0
        $levelToBox.SelectedIndex = $levels.Count - 1
    }
    Write-AppLog 'INFO' 'LEVELS' ("生成: $($levels.Count)レベル / $($levels -join ', ')")
}

function Get-SelectedLevels {
    return @($levelList.CheckedItems | ForEach-Object {
        $display = [string]$_
        if ($script:LevelValueByDisplay.ContainsKey($display)) { [string]$script:LevelValueByDisplay[$display] }
    })
}

function Get-FriendlyFailureState([string]$Message) {
    if ($Message -match '404|410|リンク切れ') { return 'リンク切れ?' }
    if ($Message -match '配布URL|header\.json|譜面データ|難易度表ページ') { return 'URL取得失敗' }
    if ($Message -match 'ダウンロード') { return 'DL失敗' }
    if ($Message -match '書庫|展開|ZIP|RAR|7z|LZH') { return '展開失敗' }
    if ($Message -match '親BMS|親曲') { return '親曲なし' }
    return '失敗'
}

function Set-RowState($Row, [string]$State, [string]$Message = '') {
    $differenceNeededStates = @('元曲所持／差分未導入','楽曲のみ導入済み／差分未導入','元曲候補ファイル保存済み／差分未導入','楽曲のみ導入済み／差分DL失敗','元曲候補ファイル保存済み／差分DL失敗','差分・元曲DL失敗','DL失敗','URL取得失敗','リンク切れ?','配布URLなし','配布ページ','展開不可','展開失敗','譜面なし','譜面不一致','失敗','再試行失敗')
    $songNeededStates = @('差分取得済み／元曲未導入','親曲なし','元曲取得失敗','元曲URLなし','差分・元曲DL失敗','元曲候補・差分保存済み／統合失敗')
    $differenceNeeded = $differenceNeededStates -contains $State
    $songNeeded = $songNeededStates -contains $State
    $guidance = ''
    if ($differenceNeeded -and $songNeeded) { $guidance = '次の操作: 差分ページと楽曲ページを確認し、入手したファイルを「手動ファイルを振り分け」で選んでください。' }
    elseif ($differenceNeeded) { $guidance = '次の操作: 強調表示された差分ページから手動で入手し、「手動ファイルを振り分け」で選んでください。' }
    elseif ($songNeeded) { $guidance = '次の操作: 強調表示された楽曲ページから元曲を入手し、「手動ファイルを振り分け」で選んでください。' }
    if ($guidance -and $Message -notmatch '次の操作:') { $Message = $Message.TrimEnd() + [Environment]::NewLine + $guidance }
    $Row.Cells['State'].Value = $State
    $Row.Cells['State'].ToolTipText = $Message
    if ($Row.Cells['DifferencePage']) {
        $Row.Cells['DifferencePage'].Value = if ($differenceNeeded) { '差分を手動DL' } else { '差分ページ' }
        $differenceColor = if ($differenceNeeded) { [System.Drawing.Color]::FromArgb(255, 210, 85) } else { [System.Drawing.SystemColors]::Control }
        $Row.Cells['DifferencePage'].Style.BackColor = $differenceColor
        $Row.Cells['DifferencePage'].Style.SelectionBackColor = $differenceColor
        $Row.Cells['DifferencePage'].Style.ForeColor = [System.Drawing.Color]::Black
        $Row.Cells['DifferencePage'].Style.SelectionForeColor = [System.Drawing.Color]::Black
    }
    if ($Row.Cells['SongPage']) {
        $hasSongPage = [string]$Row.Cells['SongPage'].Value -ne '登録なし'
        if ($songNeeded -and $hasSongPage) { $Row.Cells['SongPage'].Value = '元曲を手動DL' }
        elseif ($hasSongPage) { $Row.Cells['SongPage'].Value = '楽曲ページ' }
        $songColor = if ($songNeeded -and $hasSongPage) { [System.Drawing.Color]::FromArgb(255, 210, 85) } else { [System.Drawing.SystemColors]::Control }
        $Row.Cells['SongPage'].Style.BackColor = $songColor
        $Row.Cells['SongPage'].Style.SelectionBackColor = $songColor
        $Row.Cells['SongPage'].Style.ForeColor = [System.Drawing.Color]::Black
        $Row.Cells['SongPage'].Style.SelectionForeColor = [System.Drawing.Color]::Black
    }
    switch ($State) {
        '導入済み' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(220, 245, 224) }
        '所持済み' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(225, 240, 255) }
        '元曲所持／差分未導入' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(232, 242, 255) }
        '楽曲のみ導入済み／差分未導入' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(232, 242, 255) }
        '取得可能' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::White }
        'MD5補完で取得可能' { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::White }
        default { $Row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 238, 210) }
    }
    $manualStates = @('差分取得済み／元曲未導入','親曲なし','元曲取得失敗','元曲URLなし','楽曲のみ導入済み／差分未導入','元曲候補ファイル保存済み／差分未導入','楽曲のみ導入済み／差分DL失敗','元曲候補ファイル保存済み／差分DL失敗','元曲候補・差分保存済み／統合失敗','差分・元曲DL失敗','DL失敗','URL取得失敗','リンク切れ?','展開失敗','譜面不一致')
    $manualInstallButton.BackColor = [System.Drawing.SystemColors]::Control
    foreach ($gridRow in $grid.Rows) {
        if ($manualStates -contains [string]$gridRow.Cells['State'].Value) {
            $manualInstallButton.BackColor = [System.Drawing.Color]::FromArgb(198, 239, 206)
            break
        }
    }
}

function Get-EntryDifferencePageUrl($Entry, [string]$DataUrl) {
    $url = ''
    $nameDiff = Get-EntryText $Entry 'name_diff' ''
    if ($nameDiff -match '^https?://') { $url = $nameDiff }
    if (-not $url) { $url = Get-EntryDownloadUrl $Entry 'url_diff' }
    if (-not $url) { return $script:CurrentTableUrl }
    return Resolve-AbsoluteUrl $DataUrl $url
}

function Get-EntrySongPageUrl($Entry, [string]$DataUrl) {
    $url = Get-EntryDownloadUrl $Entry 'url'
    if (-not $url) { return '' }
    return Resolve-AbsoluteUrl $DataUrl $url
}

function Get-EntryManualUrl($Entry, [string]$DataUrl, [string]$State) {
    if ($State -eq '親曲なし' -or $State -eq '元曲取得失敗' -or $State -eq '元曲URLなし') {
        $songUrl = Get-EntrySongPageUrl $Entry $DataUrl
        if ($songUrl) { return $songUrl }
    }
    return Get-EntryDifferencePageUrl $Entry $DataUrl
}

function Show-LogWindow {
    $logForm = New-Object System.Windows.Forms.Form
    $logForm.Text = '処理ログ'
    $logForm.Size = New-Object System.Drawing.Size(900, 560)
    $logForm.StartPosition = 'CenterParent'
    $logForm.Font = $form.Font
    $logBox = New-Object System.Windows.Forms.TextBox
    $logBox.Multiline = $true
    $logBox.ReadOnly = $true
    $logBox.ScrollBars = 'Both'
    $logBox.WordWrap = $false
    $logBox.Dock = 'Fill'
    if (Test-Path -LiteralPath $script:LogPath) { $logBox.Text = Get-Content -LiteralPath $script:LogPath -Raw -Encoding UTF8 }
    $script:LogTextBox = $logBox
    $logForm.Controls.Add($logBox)
    $logForm.Add_FormClosed({ $script:LogTextBox = $null })
    [void]$logForm.Show($form)
}

function Load-SelectedTable {
    $selectedTableUrl = Get-SelectedTableUrl
    if ([string]::IsNullOrWhiteSpace($selectedTableUrl)) { throw '難易度表を選ぶか、URLを入力してください。' }
    $loadTableButton.Enabled = $false
    $scanButton.Enabled = $false
    $statusLabel.Text = '難易度表を読み込んでいます…'
    Set-UiProgress '難易度表を読み込み中' 0 0
    Invoke-UiPulse
    $previousNameCallback = $script:TableNameDetectedCallback
    $script:TableNameDetectedCallback = {
        param($detectedName, $detectedUrl)
        $statusLabel.Text = "難易度表を検出: $detectedName　譜面データを読み込んでいます…"
        [void](Update-CustomTableDisplayName $selectedTableUrl $detectedName)
        Invoke-UiPulse
    }
    try {
        $table = Get-TableEntries $selectedTableUrl
        $resolvedTableName = if ([string]::IsNullOrWhiteSpace([string]$table.Name)) { Get-FriendlyTableNameFromUrl $selectedTableUrl } else { ([string]$table.Name).Trim() }
        $script:TableNameCache[$selectedTableUrl.TrimEnd('/').ToLowerInvariant()] = $resolvedTableName
        $knownTable = $false
        $customTable = $false
        foreach ($item in $tableBox.Items) {
            $urlProperty = $item.PSObject.Properties['Url']
            if ($urlProperty -and ([string]$urlProperty.Value).TrimEnd('/').ToLowerInvariant() -eq $selectedTableUrl.TrimEnd('/').ToLowerInvariant()) {
                $knownTable = $true
                $customProperty = $item.PSObject.Properties['IsCustom']
                $customTable = $customProperty -and [bool]$customProperty.Value
                break
            }
        }
        if ($customTable) { [void](Update-CustomTableDisplayName $selectedTableUrl $resolvedTableName) }
        elseif (-not $knownTable) {
            [void](Add-TableUrlToSettings $selectedTableUrl $resolvedTableName)
            for ($index = 0; $index -lt $tableBox.Items.Count; $index++) {
                if ([string]$tableBox.Items[$index].Url -eq $selectedTableUrl) { $tableBox.SelectedIndex = $index; break }
            }
        }
        $script:CurrentTable = $table
        $script:CurrentTableUrl = $selectedTableUrl
        Populate-LevelList $table
        $script:Settings.Tables = @($selectedTableUrl)
        Save-Settings $script:Settings
        $statusLabel.Text = "$($table.Name): $($table.Entries.Count)譜面。対象レベルを選んで検索してください。"
        Set-UiProgress '難易度表の読み込み完了' 1 1
        $scanButton.Enabled = $true
        return $table
    } finally {
        $script:TableNameDetectedCallback = $previousNameCallback
        $loadTableButton.Enabled = $true
    }
}

$rootButton.Add_Click({
    try {
        $chosen = Choose-Folder 'beatoraja.jar または songdata.db があるフォルダを選んでください。' $rootBox.Text
        if (-not $chosen) { return }
        if (-not (Test-BeatorajaFolder $chosen)) {
            [System.Windows.Forms.MessageBox]::Show($form, 'beatoraja.jar または songdata.db が見つかりません。別のフォルダを選んでください。', '確認', 'OK', 'Warning') | Out-Null
            return
        }
        $rootBox.Text = $chosen
        if ([string]::IsNullOrWhiteSpace($musicBox.Text)) {
            $likely = Find-LikelyMusicFolder $chosen
            if ($likely) { $musicBox.Text = $likely }
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($form, ('フォルダ選択を開けませんでした。' + [Environment]::NewLine + $_.Exception.Message), 'エラー', 'OK', 'Error') | Out-Null
    }
})

$playerModeBox.Add_SelectedIndexChanged({
    Update-PlayerModeUi
    $script:CurrentDatabaseIndex = $null
    $grid.Rows.Clear()
    $script:EntryMap.Clear()
    $downloadButton.Enabled = $false
    $manualInstallButton.Enabled = $false
})
Update-PlayerModeUi

$musicButton.Add_Click({
    try {
        if (Show-MusicFolderManager) {
            $script:CurrentDatabaseIndex = $null
            $statusLabel.Text = '登録フォルダを変更しました。「索引を更新」で次回用の情報へ反映してください。'
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($form, ('フォルダ選択を開けませんでした。' + [Environment]::NewLine + $_.Exception.Message), 'エラー', 'OK', 'Error') | Out-Null
    }
})

$importBeatorajaButton.Add_Click({
    try {
        if (-not (Test-BeatorajaFolder $rootBox.Text)) { throw '先にbeatorajaの本体フォルダを選んでください。' }
        $imported = Import-BeatorajaConfiguration $rootBox.Text
        $mergedRoots = New-Object System.Collections.Generic.List[string]
        foreach ($path in @(Get-RegisteredMusicPaths) + @($imported.MusicPaths)) {
            if ($path -and -not @($mergedRoots | Where-Object { $_ -eq $path }).Count) { [void]$mergedRoots.Add($path) }
        }
        $script:Settings.BeatorajaPath = $rootBox.Text
        $script:Settings.MusicPaths = [string[]]$mergedRoots.ToArray()
        if ([string]::IsNullOrWhiteSpace([string]$script:Settings.MusicPath) -and $mergedRoots.Count -gt 0) { $script:Settings.MusicPath = $mergedRoots[0] }
        $musicBox.Text = $script:Settings.MusicPath
        $addedTables = 0
        $importUrls = @($imported.TableUrls)
        $tableNumber = 0
        foreach ($url in $importUrls) {
            $tableNumber++
            $needsName = $true
            foreach ($item in $tableBox.Items) {
                $urlProperty = $item.PSObject.Properties['Url']
                if (-not $urlProperty -or ([string]$urlProperty.Value).TrimEnd('/').ToLowerInvariant() -ne ([string]$url).TrimEnd('/').ToLowerInvariant()) { continue }
                $customProperty = $item.PSObject.Properties['IsCustom']
                if (-not $customProperty -or -not [bool]$customProperty.Value -or (-not [string]::IsNullOrWhiteSpace([string]$item.Name) -and [string]$item.Name -ne [string]$url)) { $needsName = $false }
                break
            }
            $tableName = ''
            if ($needsName) {
                $statusLabel.Text = "難易度表名を確認中: $tableNumber / $($importUrls.Count)"
                Set-UiProgress 'beatorajaの難易度表名を取得中' $tableNumber $importUrls.Count
                Invoke-UiPulse
                $tableName = Get-TableDisplayNameOnline ([string]$url)
            }
            if (Add-TableUrlToSettings ([string]$url) $tableName) { $addedTables++ }
        }
        Save-Settings $script:Settings
        $statusLabel.Text = "beatorajaからBMSフォルダ $($imported.MusicPaths.Count)件、未登録の難易度表 $addedTables 件を読み込みました。"
        $continueScan = [System.Windows.Forms.MessageBox]::Show($form, "beatorajaの設定を読み込みました。`nBMSフォルダ: $($imported.MusicPaths.Count)件`n追加した難易度表: $addedTables 件`n`n続けて高速索引を作成しますか？", '読込完了', 'YesNo', 'Question')
        if ($continueScan -eq 'Yes') { & $runLibraryScan $false }
    } catch {
        Write-AppLog 'ERROR' 'BEATORAJA_IMPORT' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, 'beatoraja設定の読込エラー', 'OK', 'Error') | Out-Null
    }
})

$runLibraryScan = {
    param([bool]$Full)
    try {
        $roots = @(Get-RegisteredMusicPaths)
        if ($roots.Count -eq 0) { throw '「登録フォルダ…」または「beatorajaから読込」でBMSフォルダを登録してください。' }
        $message = if ($Full) { '全譜面のハッシュを再計算して索引を作り直します。時間がかかります。続けますか？' } elseif (Test-LibraryIndexAvailable $roots) { '追加・更新・削除を確認します。変更されていない譜面のハッシュは再利用します。続けますか？' } else { '初回の高速索引を作成します。ライブラリが大きい場合は時間がかかります。続けますか？' }
        if ([System.Windows.Forms.MessageBox]::Show($form, $message, 'BMSライブラリのスキャン', 'YesNo', 'Question') -ne 'Yes') { return }
        $indexScanButton.Enabled = $false; $fullIndexScanButton.Enabled = $false; $importBeatorajaButton.Enabled = $false; $musicButton.Enabled = $false
        $scanButton.Enabled = $false; $downloadButton.Enabled = $false; $manualInstallButton.Enabled = $false
        $cancelButton.Text = '中止する'; $cancelButton.Enabled = $true; $script:CancelRequested = $false
        Start-PerformanceTrace $(if ($Full) { 'BMSライブラリ完全再スキャン' } else { 'BMSライブラリ変更スキャン' })
        $progress = {
            param($stage, $current, $total)
            $statusLabel.Text = if ($total -gt 0) { "$stage`: $current / $total" } else { "$stage`: $current ファイル確認" }
            Set-UiProgress $stage $current $total
        }
        $script:CurrentDatabaseIndex = Update-LibraryIndex $roots $progress -Full:$Full
        $statusLabel.Text = "高速索引を更新しました: $($script:CurrentDatabaseIndex.Rows.Count)譜面 / $($script:CurrentDatabaseIndex.Directories.Count)フォルダ"
        [System.Windows.Forms.MessageBox]::Show($form, $statusLabel.Text, 'スキャン完了') | Out-Null
    } catch {
        Write-AppLog 'ERROR' 'LIBRARY_INDEX' $_.Exception.Message
        if ($script:CancelRequested -or $_.Exception.Message -match '中止') { $statusLabel.Text = 'BMSライブラリのスキャンを中止しました。以前の索引は維持されています。' }
        else { $statusLabel.Text = 'BMSライブラリのスキャンに失敗しました。'; [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, 'スキャンエラー', 'OK', 'Error') | Out-Null }
    } finally {
        Complete-PerformanceTrace
        Reset-UiProgress '高速索引の更新完了。次の操作を選べます。'
        $indexScanButton.Enabled = $true; $fullIndexScanButton.Enabled = $true; $importBeatorajaButton.Enabled = $true; $musicButton.Enabled = $true
        $loadTableButton.Enabled = $true; $registerTableButton.Enabled = $true; $removeTableButton.Enabled = $true; $tableBox.Enabled = $true
        $retryPendingButton.Enabled = $true; $deletePendingButton.Enabled = $true
        $scanButton.Enabled = $null -ne $script:CurrentTable
        $downloadButton.Enabled = $grid.Rows.Count -gt 0
        $manualInstallButton.Enabled = $script:EntryMap.Count -gt 0
        $cancelButton.Enabled = $false; $cancelButton.Text = '中止する'; $script:CancelRequested = $false
        $script:OperationProgressCallback = $null; $script:CurrentOperationTitle = ''
    }
}
$indexScanButton.Add_Click({ & $runLibraryScan $false })
$fullIndexScanButton.Add_Click({ & $runLibraryScan $true })

$loadTableButton.Add_Click({
    try { [void](Load-SelectedTable) }
    catch {
        Write-AppLog 'ERROR' 'TABLE' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, '難易度表の取得エラー', 'OK', 'Error') | Out-Null
        $statusLabel.Text = '難易度表を読み込めませんでした。ログを確認してください。'
    }
})

$registerTableButton.Add_Click({
    $tableUrl = Get-SelectedTableUrl
    if ($tableUrl -notmatch '^https?://') {
        [System.Windows.Forms.MessageBox]::Show($form, '難易度表のページURLを入力してから「表を登録」を押してください。', '確認', 'OK', 'Warning') | Out-Null
        return
    }
    for ($itemIndex = 0; $itemIndex -lt $tableBox.Items.Count; $itemIndex++) {
        $urlProperty = $tableBox.Items[$itemIndex].PSObject.Properties['Url']
        if ($urlProperty -and [string]$urlProperty.Value -eq $tableUrl) {
            $tableBox.SelectedIndex = $itemIndex
            [System.Windows.Forms.MessageBox]::Show($form, 'この難易度表はすでに一覧へ登録されています。', '確認') | Out-Null
            return
        }
    }
    $registerTableButton.Enabled = $false
    $removeTableButton.Enabled = $false
    $loadTableButton.Enabled = $false
    $statusLabel.Text = '登録する難易度表を確認しています…'
    Invoke-UiPulse
    $previousNameCallback = $script:TableNameDetectedCallback
    $script:TableNameDetectedCallback = {
        param($detectedName, $detectedUrl)
        $statusLabel.Text = "難易度表を検出: $detectedName　譜面データを確認しています…"
        Invoke-UiPulse
    }
    try {
        $table = Get-TableEntries $tableUrl
        $tableName = if ([string]::IsNullOrWhiteSpace([string]$table.Name)) { $tableUrl } else { [string]$table.Name }
        $customItem = [pscustomobject]@{ Name=$tableName; Url=$tableUrl; IsCustom=$true }
        $customList = New-Object System.Collections.ArrayList
        foreach ($existing in @($script:Settings.CustomTables)) { [void]$customList.Add($existing) }
        [void]$customList.Add([pscustomobject]@{ Name=$tableName; Url=$tableUrl })
        $script:Settings.CustomTables = @($customList.ToArray())
        $script:Settings.Tables = @($tableUrl)
        $newIndex = $tableBox.Items.Add($customItem)
        $tableBox.SelectedIndex = $newIndex
        $script:CurrentTable = $table
        $script:CurrentTableUrl = $tableUrl
        Populate-LevelList $table
        Save-Settings $script:Settings
        $scanButton.Enabled = $true
        $statusLabel.Text = "$tableName を登録しました。$($table.Entries.Count)譜面。対象レベルを選んで検索してください。"
    } catch {
        Write-AppLog 'ERROR' 'TABLE_REGISTER' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, ('難易度表を登録できませんでした。' + [Environment]::NewLine + $_.Exception.Message), '登録エラー', 'OK', 'Error') | Out-Null
        $statusLabel.Text = '難易度表を登録できませんでした。URLを確認してください。'
    } finally {
        $script:TableNameDetectedCallback = $previousNameCallback
        $registerTableButton.Enabled = $true
        $removeTableButton.Enabled = $true
        $loadTableButton.Enabled = $true
    }
})

$removeTableButton.Add_Click({
    $selectedCustom = $null
    if ($tableBox.SelectedIndex -ge 0) {
        $candidate = $tableBox.SelectedItem
        $customProperty = $candidate.PSObject.Properties['IsCustom']
        if ($customProperty -and [bool]$customProperty.Value) { $selectedCustom = $candidate }
    }
    if (-not $selectedCustom) {
        $typedUrl = Get-SelectedTableUrl
        foreach ($candidate in $tableBox.Items) {
            $customProperty = $candidate.PSObject.Properties['IsCustom']
            $urlProperty = $candidate.PSObject.Properties['Url']
            if ($customProperty -and [bool]$customProperty.Value -and $urlProperty -and [string]$urlProperty.Value -eq $typedUrl) { $selectedCustom = $candidate; break }
        }
    }
    if (-not $selectedCustom) {
        [System.Windows.Forms.MessageBox]::Show($form, '削除できるのは「表を登録」で追加した難易度表だけです。', '確認') | Out-Null
        return
    }
    $answer = [System.Windows.Forms.MessageBox]::Show($form, "「$($selectedCustom.Name)」を登録一覧から削除しますか？", '登録削除', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { return }
    $removedUrl = [string]$selectedCustom.Url
    $remainingCustoms = New-Object System.Collections.ArrayList
    foreach ($existing in @($script:Settings.CustomTables)) {
        $urlProperty = $existing.PSObject.Properties['Url']
        if (-not $urlProperty -or [string]$urlProperty.Value -ne $removedUrl) { [void]$remainingCustoms.Add($existing) }
    }
    $script:Settings.CustomTables = @($remainingCustoms.ToArray())
    [void]$tableBox.Items.Remove($selectedCustom)
    if ($script:CurrentTableUrl -eq $removedUrl) {
        $script:CurrentTable = $null
        $script:CurrentTableUrl = ''
        $scanButton.Enabled = $false
        $manualInstallButton.Enabled = $false
    }
    if ($tableBox.Items.Count -gt 2) { $tableBox.SelectedIndex = 2 }
    $script:Settings.Tables = @((Get-SelectedTableUrl))
    Save-Settings $script:Settings
    $statusLabel.Text = '登録した難易度表を一覧から削除しました。'
})

$levelAllButton.Add_Click({
    for ($i = 0; $i -lt $levelList.Items.Count; $i++) { $levelList.SetItemChecked($i, $true) }
})

$levelClearButton.Add_Click({
    for ($i = 0; $i -lt $levelList.Items.Count; $i++) { $levelList.SetItemChecked($i, $false) }
})

$levelRangeButton.Add_Click({
    if ($levelFromBox.SelectedIndex -lt 0 -or $levelToBox.SelectedIndex -lt 0) { return }
    $first = [Math]::Min($levelFromBox.SelectedIndex, $levelToBox.SelectedIndex)
    $last = [Math]::Max($levelFromBox.SelectedIndex, $levelToBox.SelectedIndex)
    for ($i = 0; $i -lt $levelList.Items.Count; $i++) { $levelList.SetItemChecked($i, ($i -ge $first -and $i -le $last)) }
})

$tableBox.Add_TextChanged({
    $selectedUrlNow = Get-SelectedTableUrl
    if ($script:CurrentTableUrl -and $selectedUrlNow -ne $script:CurrentTableUrl) {
        $scanButton.Enabled = $false
        $manualInstallButton.Enabled = $false
    }
})

$scanButton.Add_Click({
    try {
        $selectedTableUrl = Get-SelectedTableUrl
        $usesBeatorajaDatabase = $playerModeBox.SelectedIndex -eq 0
        $registeredRoots = @(Get-RegisteredMusicPaths)
        $hasLibraryIndex = Test-LibraryIndexAvailable $registeredRoots
        if ($usesBeatorajaDatabase -and -not $hasLibraryIndex -and -not (Test-BeatorajaFolder $rootBox.Text)) { throw 'beatorajaの保存場所を選ぶか、BMSライブラリの高速索引を作成してください。' }
        if (-not (Test-Path -LiteralPath $musicBox.Text -PathType Container)) { throw 'BMS曲フォルダを選んでください。' }
        if ([string]::IsNullOrWhiteSpace($selectedTableUrl)) { throw '難易度表を選ぶか、URLを入力してください。' }
        $script:CurrentMusicPath = $musicBox.Text
        Start-PerformanceTrace '所持確認・一覧作成'
        if (-not $script:CurrentTable -or $script:CurrentTableUrl -ne $selectedTableUrl) { [void](Load-SelectedTable) }
        $selectedLevels = @(Get-SelectedLevels)
        if ($selectedLevels.Count -eq 0) { throw '検索するレベルを1つ以上選んでください。' }
        $scanButton.Enabled = $false
        $playerModeBox.Enabled = $false
        $musicButton.Enabled = $false
        $importBeatorajaButton.Enabled = $false
        $indexScanButton.Enabled = $false
        $fullIndexScanButton.Enabled = $false
        $downloadButton.Enabled = $false
        $manualInstallButton.Enabled = $false
        $grid.Rows.Clear()
        $script:EntryMap.Clear()
        $script:ManualEntryMap.Clear()
        $script:FolderFileCache = @{}
        $manualInstallButton.BackColor = [System.Drawing.SystemColors]::Control
        if ($hasLibraryIndex) {
            $statusLabel.Text = '高速ライブラリ索引から所持譜面を読み取っています…'
            Invoke-UiPulse
            $index = Get-PersistentLibraryIndex $registeredRoots
            $ownershipSource = '高速ライブラリ索引'
        } elseif ($usesBeatorajaDatabase) {
            $statusLabel.Text = 'beatorajaのsongdata.dbを読み取っています…'
            Invoke-UiPulse
            $index = Get-SongDatabaseIndex $rootBox.Text
            $ownershipSource = 'songdata.db'
        } else {
            $statusLabel.Text = 'BMS曲フォルダの譜面を確認しています…'
            $script:CancelRequested = $false
            $cancelButton.Enabled = $true
            $index = Get-LocalChartIndex $musicBox.Text {
                param($current, $total, $name)
                $statusLabel.Text = "BMS曲フォルダを確認中: $current / $total　$name"
                Set-UiProgress 'BMS曲フォルダを確認中' $current $total
                Invoke-UiPulse
                if ($script:CancelRequested) { throw 'ユーザー操作で中止しました。' }
            }
            $ownershipSource = 'BMS曲フォルダ'
        }
        $script:CurrentDatabaseIndex = $index
        $table = $script:CurrentTable
        $missing = 0
        $ownedInTable = 0
        $ownedBaseSongs = 0
        $targetEntries = @($table.Entries | Where-Object { $selectedLevels -contains (Get-EntryText $_ 'level' '(未設定)') })
        Write-AppLog 'INFO' 'SEARCH' ("対象レベル: $($selectedLevels -join ', ') / $($targetEntries.Count)譜面")
        $displayItems = @()
        $originalOrder = 0
        $entryNumber = 0
        foreach ($entry in $targetEntries) {
            $entryNumber++
            if (($entryNumber % 25) -eq 0 -or $entryNumber -eq 1 -or $entryNumber -eq $targetEntries.Count) {
                Set-UiProgress '難易度表と所持譜面を照合中' $entryNumber $targetEntries.Count
                Invoke-UiPulse
            }
            $url = Get-EntryDownloadUrl $entry
            $level = Get-EntryText $entry 'level' ''
            $title = Get-EntryText $entry 'title' '(タイトル不明)'
            $artist = Get-EntryText $entry 'artist' ''
            $databaseInstalled = Test-EntryInIndex $entry $index
            $recordedInstalled = Test-EntryRecordedInstalled $entry
            $installed = $databaseInstalled -or $recordedInstalled
            $baseFolder = ''
            $partial = Get-PartialInstall $entry
            if ($partial -and $partial.BaseFolder -and -not (Test-EntryMatchesBaseFolderTitle $entry ([string]$partial.BaseFolder))) {
                Write-AppLog 'WARN' 'PARTIAL' ("対象曲とタイトルが一致しない元曲記録を解除: $title -> $($partial.BaseFolder)")
                Set-PartialInstall $entry -ClearBaseFolder
                $partial = Get-PartialInstall $entry
            }
            $wantedUrl = $url
            $sourcePlan = $null
            if ($installed) {
                Clear-PartialInstall $entry -RemovePendingFolder
                $ownedInTable++; $state = if ($databaseInstalled) { '所持済み' } else { '導入済み' }
            }
            else {
                if ($partial -and $partial.PendingFolder) {
                    $state = '差分取得済み／元曲未導入'
                    $sourcePlan = Get-PreflightSourceUrl $entry $table.DataUrl 'url'
                    $wantedUrl = $sourcePlan.Url
                } else {
                    $sourcePlan = Get-PreflightSourceUrl $entry $table.DataUrl ''
                    $wantedUrl = $sourcePlan.Url
                    if ($partial -and $partial.BaseFolder) { $baseFolder = $partial.BaseFolder }
                    if (-not $baseFolder) { $baseFolder = Find-OwnedSongFolderByTitle $entry $index }
                    if ($baseFolder) { $state = $(if ($partial -and $partial.BaseFolder) { '楽曲のみ導入済み／差分未導入' } else { '元曲所持／差分未導入' }); $ownedBaseSongs++ }
                    elseif ($partial -and $partial.BasePackagePath) { $state = '元曲候補ファイル保存済み／差分未導入' }
                    else { $state = if ($wantedUrl) { $(if ($sourcePlan.Complemented) { 'MD5補完で取得可能' } else { '取得可能' }) } else { '配布URLなし' } }
                }
                $missing++
            }
            $displayItems += [pscustomobject]@{
                Entry=$entry; Url=$wantedUrl; Level=$level; Title=$title; Artist=$artist
                Installed=$installed; DatabaseInstalled=$databaseInstalled; BaseFolder=$baseFolder; Partial=$partial; SourcePlan=$sourcePlan; State=$state; OwnedRank=$(if ($installed) { 1 } else { 0 }); OriginalOrder=$originalOrder
            }
            $originalOrder++
        }
        foreach ($item in @(Get-DefaultChartDisplayOrder $displayItems)) {
            $songPageUrl = Get-EntrySongPageUrl $item.Entry $table.DataUrl
            $songPageText = if ($songPageUrl) { '楽曲ページ' } else { '登録なし' }
            $rowIndex = $grid.Rows.Add((-not $item.Installed -and [bool]$item.Url), $item.Level, $item.Title, $item.Artist, $item.State, '差分ページ', $songPageText)
            Set-RowState $grid.Rows[$rowIndex] $item.State $(if ($item.DatabaseInstalled) { "対象の差分譜面を元から所持しています。$ownershipSource に同じMD5またはSHA-256があります。" } elseif ($item.Installed) { 'このツールで差分を配置済みとして記録されています。使用ソフト側で楽曲一覧を更新すると所持済みになります。' } elseif ($item.Partial -and $item.Partial.PendingFolder) { "差分は取得済みです: $($item.Partial.PendingFolder)`n元曲だけを取得またはD&Dすると、自動的に組み合わせて導入を完了します。" } elseif ($item.BaseFolder) { "元の楽曲はすでに所持しています: $($item.BaseFolder)`n楽曲本体を再取得せず、差分のみ自動取得します。" } elseif ($item.Partial -and $item.Partial.BasePackagePath) { "元曲URLから取得した候補ファイルを保存しています: $($item.Partial.BasePackagePath)`n親曲としては未確認・未配置です。差分を取得すると再照合します。" } elseif ($item.SourcePlan -and $item.SourcePlan.Complemented) { "難易度表のURLをMD5→URLマップで補完しました。`n$($item.SourcePlan.Reason): $($item.Url)" } elseif (-not $item.Url) { '難易度表にもMD5補完データにも配布URLがありません。' } else { '自動取得を試せます。' })
            $key = [string]$rowIndex
            $script:EntryMap[$key] = [pscustomobject]@{ Entry=$item.Entry; DataUrl=$table.DataUrl; DownloadUrlOverride=$(if ($item.SourcePlan -and $item.SourcePlan.Complemented) { [string]$item.SourcePlan.Url } else { '' }) }
        }
        $rowByHash = @{}
        foreach ($pair in $script:EntryMap.GetEnumerator()) {
            $md5 = Get-EntryHash $pair.Value.Entry 'md5'
            $sha = Get-EntryHash $pair.Value.Entry 'sha256'
            if ($md5) { $rowByHash['md5:' + $md5] = [int]$pair.Key }
            if ($sha) { $rowByHash['sha:' + $sha] = [int]$pair.Key }
        }
        $manualNumber = 0
        foreach ($manualEntry in @($table.Entries)) {
            $manualMd5 = Get-EntryHash $manualEntry 'md5'
            $manualSha = Get-EntryHash $manualEntry 'sha256'
            $manualRowIndex = -1
            if ($manualMd5 -and $rowByHash.ContainsKey('md5:' + $manualMd5)) { $manualRowIndex = [int]$rowByHash['md5:' + $manualMd5] }
            elseif ($manualSha -and $rowByHash.ContainsKey('sha:' + $manualSha)) { $manualRowIndex = [int]$rowByHash['sha:' + $manualSha] }
            $manualKey = if ($manualMd5) { 'md5:' + $manualMd5 } elseif ($manualSha) { 'sha:' + $manualSha } else { 'entry:' + $manualNumber }
            $script:ManualEntryMap[$manualKey] = [pscustomobject]@{ Entry=$manualEntry; DataUrl=$table.DataUrl; RowIndex=$manualRowIndex }
            $manualNumber++
        }
        $script:Settings.BeatorajaPath = $rootBox.Text
        $script:Settings.MusicPath = $musicBox.Text
        if (@($script:Settings.MusicPaths).Count -eq 0) { $script:Settings.MusicPaths = @($musicBox.Text) }
        $script:Settings.PlayerMode = $(if ($usesBeatorajaDatabase) { 'beatoraja' } else { 'folder' })
        $script:Settings.Tables = @($selectedTableUrl)
        $script:Settings.SelectedLevels = @($selectedLevels)
        Save-Settings $script:Settings
        Populate-LevelList $table $index
        $statusLabel.Text = "$($table.Name): $($targetEntries.Count)譜面 / 差分所持 $ownedInTable / 元曲所持・差分なし $ownedBaseSongs / 未所持 $missing（確認済み $($index.Rows.Count)）"
        $downloadButton.Enabled = $missing -gt 0
        $manualInstallButton.Enabled = $true
    } catch {
        Write-AppLog 'ERROR' 'SEARCH' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, 'エラー', 'OK', 'Error') | Out-Null
        $statusLabel.Text = '確認に失敗しました。'
    } finally {
        Complete-PerformanceTrace
        $scanButton.Enabled = $true
        $playerModeBox.Enabled = $true
        $musicButton.Enabled = $true
        $importBeatorajaButton.Enabled = $true
        $indexScanButton.Enabled = $true
        $fullIndexScanButton.Enabled = $true
        Update-PlayerModeUi
        $cancelButton.Enabled = $false
        $cancelButton.Text = '中止する'
        $script:CancelRequested = $false
    }
})

$script:DroppedManualFiles = @()
$manualInstallButton.Add_Click({
    if (@($script:DroppedManualFiles).Count -gt 0) {
        $files = @($script:DroppedManualFiles)
        $script:DroppedManualFiles = @()
        Write-AppLog 'INFO' 'MANUAL_DROP' ("ドラッグ＆ドロップから受付: $($files.Count)ファイル")
    } else {
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Title = '手動で入手した楽曲・差分ファイルをまとめて選択'
        $dialog.Filter = 'BMS楽曲・差分・書庫|*.bms;*.bme;*.bml;*.pms;*.bmson;*.zip;*.rar;*.7z;*.lzh;*.lha;*.gca;*.exe;*.tar;*.gz;*.bz2;*.xz|すべてのファイル|*.*'
        $dialog.Multiselect = $true
        if ($dialog.ShowDialog($form) -ne 'OK') { return }
        $files = @($dialog.FileNames)
    }
    if ($files.Count -eq 0) { return }
    $answer = [System.Windows.Forms.MessageBox]::Show($form, "$($files.Count)個のファイルの中身を確認し、楽曲本体・差分を安全に振り分けます。元のファイルは移動も削除もしません。判定できないものは配置しません。続けますか？", '手動ファイルの振り分け', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { return }
    $installed = 0
    $unmatched = 0
    $failed = 0
    $baseInstalled = 0
    $alreadyOwned = 0
    $pendingStored = 0
    $newPendingFolders = New-Object System.Collections.Generic.List[string]
    try {
        if (-not $script:CurrentDatabaseIndex -or $script:EntryMap.Count -eq 0) { throw '先に難易度表を読み込み、「選択レベルを検索」を実行してください。' }
        if (-not (Test-Path -LiteralPath $musicBox.Text -PathType Container)) { throw 'BMS曲フォルダを選んでください。' }
        $script:CurrentMusicPath = $musicBox.Text
        Start-PerformanceTrace 'D&D・手動ファイル振り分け'
        $manualInstallButton.Enabled = $false
        $downloadButton.Enabled = $false
        $scanButton.Enabled = $false
        $musicButton.Enabled = $false
        $importBeatorajaButton.Enabled = $false
        $indexScanButton.Enabled = $false
        $fullIndexScanButton.Enabled = $false
        $retryPendingButton.Enabled = $false
        $deletePendingButton.Enabled = $false
        $script:CancelRequested = $false
        $cancelButton.Text = '中止する'
        $cancelButton.Enabled = $true
        $manualFileTotal = $files.Count
        $fileNumber = 0
        $script:OperationProgressCallback = {
            param($stage, $current, $total)
            $insideText = if ($total -gt 0) { "$current / $total" } elseif ($current -gt 0) { "$current 件確認" } else { '準備中' }
            $statusLabel.Text = "手動振り分け $fileNumber / $manualFileTotal　$stage`: $insideText　$($script:CurrentOperationTitle)"
        }
        $manualHashIndex = New-ManualEntryHashIndex $script:ManualEntryMap
        Write-AppLog 'INFO' 'MANUAL_INDEX' ("難易度表の照合索引を1回だけ作成: MD5 $($manualHashIndex.Md5.Count)件 / SHA-256 $($manualHashIndex.Sha256.Count)件")
        foreach ($file in $files) {
            $fileNumber++
            if ($script:CancelRequested) { break }
            $script:CurrentOperationTitle = [System.IO.Path]::GetFileName($file)
            $statusLabel.Text = "手動ファイルを確認中: $fileNumber / $($files.Count)  $($script:CurrentOperationTitle)"
            Set-UiProgress '手動ファイルを処理中' $fileNumber $files.Count
            Invoke-UiPulse
            try {
                $matches = @(Get-ManualPackageMatches $file $script:ManualEntryMap $manualHashIndex)
                if ($matches.Count -eq 0) {
                    $standalone = Install-ManualStandalonePackage $file $musicBox.Text $script:CurrentDatabaseIndex
                    $baseInstalled += [int]$standalone.Installed
                    $alreadyOwned += [int]$standalone.AlreadyOwned
                    $pendingStored += [int]$standalone.Pending
                    foreach ($pendingFolder in @($standalone.PendingFolders)) { [void]$newPendingFolders.Add([string]$pendingFolder) }
                    if ($standalone.Installed -eq 0 -and $standalone.AlreadyOwned -eq 0 -and $standalone.Pending -eq 0) { $unmatched++ }
                    $failed += [int]$standalone.Ambiguous
                    foreach ($detail in @($standalone.Details)) { Write-AppLog 'INFO' 'MANUAL_PACKAGE' ("$file / $detail") }
                    continue
                }
                foreach ($match in $matches) {
                    Assert-NotCancelled
                    $rowIndex = if ($match.Mapped.PSObject.Properties['RowIndex']) { [int]$match.Mapped.RowIndex } else { -1 }
                    $result = Install-DownloadedEntry $match.Mapped.Entry $file $musicBox.Text $script:CurrentDatabaseIndex
                    if ($result.Status -eq '導入済み') { Register-EntryInstalled $match.Mapped.Entry }
                    if ($rowIndex -ge 0 -and $rowIndex -lt $grid.Rows.Count) {
                        Set-RowState $grid.Rows[$rowIndex] $result.Status $result.Message
                        if ($result.Status -eq '導入済み') { $grid.Rows[$rowIndex].Cells['Get'].Value = $false }
                    }
                    if ($result.Status -eq '導入済み') { $installed++ } else { $failed++ }
                    Write-AppLog 'INFO' 'MANUAL_INSTALL' ("$file -> $($result.Status)")
                }
            } catch {
                if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { break }
                $failed++
                Write-AppLog 'ERROR' 'MANUAL_INSTALL' ("$file / $($_.Exception.Message)")
            } finally {
                Clear-ManualPackageCache $file
            }
        }
        if (-not $script:CancelRequested -and $baseInstalled -gt 0) {
            $statusLabel.Text = "追加した楽曲本体と配置待ち差分を高速索引で照合中…"
            Set-UiProgress '追加した楽曲本体と配置待ち差分を照合中' 0 0
            Invoke-UiPulse
            $pendingRetry = Retry-PendingAfterManualPlacement $script:ManualEntryMap $musicBox.Text $script:CurrentDatabaseIndex
            foreach ($rowResult in @($pendingRetry.RowResults)) {
                $rowIndex = if ($rowResult.Mapped.PSObject.Properties['RowIndex']) { [int]$rowResult.Mapped.RowIndex } else { -1 }
                if ($rowIndex -ge 0 -and $rowIndex -lt $grid.Rows.Count) {
                    Set-RowState $grid.Rows[$rowIndex] $rowResult.Result.Status $rowResult.Result.Message
                    $grid.Rows[$rowIndex].Cells['Get'].Value = $false
                }
            }
            $installed += [int]$pendingRetry.Installed
        } elseif (-not $script:CancelRequested) {
            Write-AppLog 'INFO' 'PENDING_RETRY' '新しい楽曲本体の配置がないため、受信箱全体の配置待ち再試行を省略しました。'
        }
        $pendingRemaining = @($newPendingFolders | Where-Object { Test-Path -LiteralPath $_ -PathType Container }).Count
        if ($script:CancelRequested) {
            $statusLabel.Text = "手動ファイルの振り分けを中止しました: 差分導入 $installed / 楽曲配置 $baseInstalled / 受信箱へ保留 $pendingRemaining / 要確認 $($unmatched + $failed)"
        } else {
            $statusLabel.Text = "手動ファイルの振り分け完了: 差分導入 $installed / 楽曲配置 $baseInstalled / 元から所持 $alreadyOwned / 受信箱へ保留 $pendingRemaining / 要確認 $($unmatched + $failed)"
            [System.Windows.Forms.MessageBox]::Show($form, "手動ファイルの振り分けが完了しました。`n差分導入: $installed`n楽曲本体を配置: $baseInstalled`n元から所持: $alreadyOwned`n受信箱へ保留: $pendingRemaining`nBMSを確認できず未配置: $($unmatched + $failed)`n`n保留した譜面は、親曲を追加したあと「配置待ち再試行」で再確認できます。元のダウンロードファイルは変更していません。", '完了') | Out-Null
        }
    } catch {
        Write-AppLog 'ERROR' 'MANUAL_INSTALL' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, '手動ファイルの振り分けエラー', 'OK', 'Error') | Out-Null
    } finally {
        Complete-PerformanceTrace
        $manualInstallButton.Enabled = $script:EntryMap.Count -gt 0
        $downloadButton.Enabled = $grid.Rows.Count -gt 0
        $scanButton.Enabled = $true
        $musicButton.Enabled = $true
        $importBeatorajaButton.Enabled = $true
        $indexScanButton.Enabled = $true
        $fullIndexScanButton.Enabled = $true
        $retryPendingButton.Enabled = $true
        $deletePendingButton.Enabled = $true
        $cancelButton.Enabled = $false
        $cancelButton.Text = '中止する'
        $script:CancelRequested = $false
        $script:OperationProgressCallback = $null
        $script:CurrentOperationTitle = ''
    }
})

$dropIdleColor = [System.Drawing.Color]::FromArgb(235, 245, 252)
$dropReadyColor = [System.Drawing.Color]::FromArgb(198, 239, 206)
$manualDragEnter = {
    param($sender, $eventArgs)
    if ($eventArgs.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop) -and $manualInstallButton.Enabled -and -not $script:OperationProgressCallback) {
        $eventArgs.Effect = [System.Windows.Forms.DragDropEffects]::Copy
        $dropPanel.BackColor = $dropReadyColor
        $dropLabel.Text = 'ここで離すと手動ファイルの振り分けを開始します'
    } else {
        $eventArgs.Effect = [System.Windows.Forms.DragDropEffects]::None
    }
}
$manualDragLeave = {
    $dropPanel.BackColor = $dropIdleColor
    $dropLabel.Text = 'ZIP・RAR・7z・GCA・自己解凍EXE・BMS、またはフォルダをここへドラッグ＆ドロップ'
}
$manualDragDrop = {
    param($sender, $eventArgs)
    & $manualDragLeave
    try {
        if (-not $manualInstallButton.Enabled -or $script:OperationProgressCallback) { throw '現在の処理が終わってからファイルをドロップしてください。' }
        $rawPaths = [string[]]$eventArgs.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
        $dropResult = Get-DroppedManualFiles $rawPaths 500
        $dropFiles = @($dropResult.Files)
        if ($dropFiles.Count -eq 0) { throw '対応するBMS・ZIP・RAR・7z・GCA・自己解凍EXEなどのファイルが見つかりませんでした。' }
        $script:DroppedManualFiles = [string[]]$dropFiles
        if ($dropResult.Skipped -gt 0) {
            $statusLabel.Text = "$($dropFiles.Count)ファイルを受け付けました。対象外 $($dropResult.Skipped)ファイルは省略します。"
        } else {
            $statusLabel.Text = "$($dropFiles.Count)ファイルを受け付けました。内容を確認します。"
        }
        Invoke-UiPulse
        $manualInstallButton.PerformClick()
    } catch {
        $script:DroppedManualFiles = @()
        Write-AppLog 'ERROR' 'MANUAL_DROP' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, 'ドラッグ＆ドロップ', 'OK', 'Information') | Out-Null
    }
}
foreach ($dropTarget in @($form,$dropPanel,$dropLabel,$grid)) {
    $dropTarget.AllowDrop = $true
    $dropTarget.Add_DragEnter($manualDragEnter)
    $dropTarget.Add_DragLeave($manualDragLeave)
    $dropTarget.Add_DragDrop($manualDragDrop)
}

$selectAllButton.Add_Click({
    foreach ($row in $grid.Rows) {
        $mapped = $script:EntryMap[[string]$row.Index]
        $partial = if ($mapped) { Get-PartialInstall $mapped.Entry } else { $null }
        $overrideProperty = if ($mapped) { $mapped.PSObject.Properties['DownloadUrlOverride'] } else { $null }
        $availableUrl = if ($overrideProperty -and $overrideProperty.Value) { [string]$overrideProperty.Value } elseif ($partial -and $partial.PendingFolder) { Get-EntryDownloadUrl $mapped.Entry 'url' } elseif ($mapped) { Get-EntryDownloadUrl $mapped.Entry } else { '' }
        $canDownload = $mapped -and $availableUrl -and $row.Cells['State'].Value -ne '所持済み' -and $row.Cells['State'].Value -ne '導入済み'
        if ($canDownload) { $row.Cells['Get'].Value = $true }
    }
})

$clearAllButton.Add_Click({
    foreach ($row in $grid.Rows) { $row.Cells['Get'].Value = $false }
})

$grid.Add_CellContentClick({
    param($sender, $eventArgs)
    if ($eventArgs.RowIndex -lt 0) { return }
    $columnName = $grid.Columns[$eventArgs.ColumnIndex].Name
    if ($columnName -ne 'DifferencePage' -and $columnName -ne 'SongPage') { return }
    try {
        $mapped = $script:EntryMap[[string]$eventArgs.RowIndex]
        if (-not $mapped) { throw 'この行の配布情報が見つかりません。難易度表を読み込み直してください。' }
        if ($columnName -eq 'SongPage') {
            $url = Get-EntrySongPageUrl $mapped.Entry $mapped.DataUrl
            $pageKind = '楽曲ページ'
        } else {
            $url = Get-EntryDifferencePageUrl $mapped.Entry $mapped.DataUrl
            $pageKind = '差分ページ'
        }
        if ([string]::IsNullOrWhiteSpace($url)) { throw "$pageKind のURLが難易度表に登録されていません。" }
        Write-AppLog 'INFO' 'MANUAL' ("$pageKind を既定ブラウザで開く: $url")
        Start-Process $url
    } catch {
        Write-AppLog 'ERROR' 'MANUAL' $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, '配布ページを開けません', 'OK', 'Error') | Out-Null
    }
})

$logButton.Add_Click({ Show-LogWindow })

$helpButton.Add_Click({
    $message = @"
導入済み：差分または元曲一式を曲フォルダへ配置済み
所持済み：対象の差分譜面を元から所持
元曲所持／差分未導入：元の楽曲は所持済み。楽曲本体を再取得せず差分だけを取得
DL失敗：配布ファイルを取得できませんでした
URL取得失敗：難易度表や配布URLを取得できませんでした
リンク切れ?：HTTP 404/410などが返されました
展開失敗：書庫形式・暗号化・破損などで展開できませんでした
譜面不一致：難易度表のハッシュと配布譜面が一致しません
親曲なし：差分は取得済みですが対応する元曲を特定できません
差分取得済み／元曲未導入：差分は受信箱に保存済み。元曲だけを自動取得またはD&Dすると導入を完了
楽曲のみ導入済み／差分未導入：元曲は曲フォルダへ配置済みですが差分は未導入です
元曲候補ファイル保存済み／差分未導入：元曲URLからファイルは取得しましたが、親曲として未確認・未配置です。差分D&D時に再照合します
楽曲のみ導入済み／差分DL失敗：差分取得は失敗しましたが元曲は配置済みです
元曲候補ファイル保存済み／差分DL失敗：差分取得に失敗し、元曲URLから得たファイルも親曲として未確認です
元曲候補・差分保存済み／統合失敗：両方のファイルは保持していますが、安全に同じ楽曲と判定できませんでした
中止：ユーザー操作で処理を止めました。取得済みファイルは次回再利用します

自動導入できない行は、次に必要な「差分を手動DL」「元曲を手動DL」が黄色で表示されます。
入手後は「手動ファイルを振り分け」で複数ファイルをまとめて選択できます。元ファイルは移動・削除しません。
本体だけ・差分だけの途中状態は再起動後も保存され、不足側を自動取得またはD&Dすると保存済み側と組み合わせて導入完了まで進みます。
"@
    [System.Windows.Forms.MessageBox]::Show($form, $message.Trim(), '状態の説明', 'OK', 'Information') | Out-Null
})

$cancelButton.Add_Click({
    $script:CancelRequested = $true
    $cancelButton.Enabled = $false
    $cancelButton.Text = '中止中…'
    $statusLabel.Text = '中止を要求しました。進行中の通信またはファイル処理を停止しています…'
    Write-AppLog 'WARN' 'CANCEL' 'ユーザーが中止ボタンを押しました。'
})

$retryPendingButton.Add_Click({
    try {
        if (-not $script:CurrentDatabaseIndex -or $script:EntryMap.Count -eq 0) { throw '先に「未所持を調べる」を実行してください。' }
        if (-not (Test-Path -LiteralPath $musicBox.Text -PathType Container)) { throw 'BMS曲フォルダを選んでください。' }
        $pendingFolders = @(Get-PendingFolders)
        if ($pendingFolders.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($form, '再試行できる配置待ちフォルダはありません。', '確認') | Out-Null
            return
        }
        $script:CurrentMusicPath = $musicBox.Text
        Start-PerformanceTrace '配置待ち再試行'
        $entryByMd5 = @{}
        $entryBySha = @{}
        foreach ($pair in $script:EntryMap.GetEnumerator()) {
            $candidate = [pscustomobject]@{ RowIndex = [int]$pair.Key; Mapped = $pair.Value }
            $md5 = Get-EntryHash $pair.Value.Entry 'md5'
            $sha = Get-EntryHash $pair.Value.Entry 'sha256'
            if ($md5) { $entryByMd5[$md5] = $candidate }
            if ($sha) { $entryBySha[$sha] = $candidate }
        }
        $retryPendingButton.Enabled = $false
        $deletePendingButton.Enabled = $false
        $downloadButton.Enabled = $false
        $manualInstallButton.Enabled = $false
        $scanButton.Enabled = $false
        $musicButton.Enabled = $false
        $importBeatorajaButton.Enabled = $false
        $indexScanButton.Enabled = $false
        $fullIndexScanButton.Enabled = $false
        $script:CancelRequested = $false
        $cancelButton.Text = '中止する'
        $cancelButton.Enabled = $true
        $script:OperationProgressCallback = $uiOperationProgress
        $installed = 0
        $remaining = 0
        $unmatched = 0
        $number = 0
        foreach ($folder in $pendingFolders) {
            $number++
            $script:CurrentOperationTitle = $folder.Name
            $statusLabel.Text = "配置待ちを再試行中: $number / $($pendingFolders.Count)  $($folder.Name)"
            Set-UiProgress '配置待ちを再試行中' $number $pendingFolders.Count
            Invoke-UiPulse
            if ($script:CancelRequested) { break }
            $candidate = $null
            foreach ($chart in @(Get-ChartFiles $folder.FullName)) {
                Assert-NotCancelled
                $md5 = (Get-FileHash -LiteralPath $chart.FullName -Algorithm MD5).Hash.ToLowerInvariant()
                Add-PerformanceCounter '配置待ちMD5計算回数'
                if ($entryByMd5.ContainsKey($md5)) { $candidate = $entryByMd5[$md5]; break }
                $sha = (Get-FileHash -LiteralPath $chart.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                Add-PerformanceCounter '配置待ちSHA256計算回数'
                if ($entryBySha.ContainsKey($sha)) { $candidate = $entryBySha[$sha]; break }
            }
            if (-not $candidate) { $unmatched++; continue }
            try {
                $mapped = $candidate.Mapped
                $result = Install-PendingFolder $mapped.Entry $folder.FullName $musicBox.Text $script:CurrentDatabaseIndex
                $pendingProperty = $result.PSObject.Properties['PendingFolder']
                if ($result.Status -eq '親曲なし' -and $pendingProperty -and $pendingProperty.Value) {
                    $baseUrl = Get-EntryDownloadUrl $mapped.Entry 'url'
                    $differenceUrl = Get-EntryDownloadUrl $mapped.Entry 'url_diff'
                    if ($baseUrl -and $differenceUrl -and $baseUrl -ne $differenceUrl) {
                        $baseDownloaded = ''
                        try {
                            $baseDownloaded = Download-Entry $mapped.Entry $mapped.DataUrl 'url'
                        } catch {
                            $result.Status = '元曲取得失敗'
                            $result.Message += ([Environment]::NewLine + '元曲の取得に失敗しました: ' + $_.Exception.Message)
                            Write-AppLog 'ERROR' 'BASE_DOWNLOAD' ("$($folder.Name): $($_.Exception.Message)")
                        }
                        if ($baseDownloaded) {
                            try {
                                $result = Install-PendingWithBasePackage $mapped.Entry $baseDownloaded $folder.FullName $musicBox.Text
                            } catch {
                                if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw 'ユーザー操作で中止しました。' }
                                $differenceError = $_.Exception.Message
                                Write-AppLog 'ERROR' 'DIFFERENCE_INSTALL' ("$($folder.Name): 元曲取得済み / $differenceError")
                                try {
                                    $baseOnlyResult = Install-BasePackageOnly $mapped.Entry $baseDownloaded $musicBox.Text
                                    $result.Status = $baseOnlyResult.Status
                                    $result.Message = $baseOnlyResult.Message + [Environment]::NewLine + '差分の照合または配置には失敗しました: ' + $differenceError
                                } catch {
                                    Set-PartialInstall $mapped.Entry -BasePackagePath $baseDownloaded
                                    $result.Status = '元曲候補ファイル保存済み／差分未導入'
                                    $result.Message += ([Environment]::NewLine + '元曲URLから取得したファイルは親曲として未確認・未配置です。ファイルを保存し、差分と再照合できるようにしました。差分側の失敗: ' + $differenceError + [Environment]::NewLine + '元曲候補の確認結果: ' + $_.Exception.Message)
                                }
                            }
                        }
                    }
                }
                if ($result.Status -eq '導入済み') {
                    Register-EntryInstalled $mapped.Entry
                    $inboxRoot = [System.IO.Path]::GetFullPath($script:InboxDir).TrimEnd('\') + '\'
                    $folderFull = [System.IO.Path]::GetFullPath($folder.FullName)
                    if ($folderFull.StartsWith($inboxRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                        Remove-Item -LiteralPath $folderFull -Recurse -Force
                    }
                    $installed++
                } else { $remaining++ }
                if ($candidate.RowIndex -ge 0 -and $candidate.RowIndex -lt $grid.Rows.Count) {
                    Set-RowState $grid.Rows[$candidate.RowIndex] $result.Status $result.Message
                }
            } catch {
                if ($_.Exception.Message -match 'ユーザー操作で中止') { break }
                $remaining++
                Write-AppLog 'ERROR' 'RETRY' ("$($folder.Name): $($_.Exception.Message)")
                if ($candidate.RowIndex -ge 0 -and $candidate.RowIndex -lt $grid.Rows.Count) {
                    Set-RowState $grid.Rows[$candidate.RowIndex] '再試行失敗' $_.Exception.Message
                }
            }
        }
        if ($script:CancelRequested) {
            $statusLabel.Text = "配置待ちの再試行を中止しました: 導入 $installed"
        } else {
            $statusLabel.Text = "配置待ちの再試行完了: 導入 $installed / 未解決 $remaining / 現在の表と一致なし $unmatched"
            [System.Windows.Forms.MessageBox]::Show($form, "再試行が完了しました。`n導入: $installed`n未解決: $remaining`n現在の難易度表と一致しないフォルダ: $unmatched", '完了') | Out-Null
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, 'エラー', 'OK', 'Error') | Out-Null
    } finally {
        Complete-PerformanceTrace
        $retryPendingButton.Enabled = $true
        $deletePendingButton.Enabled = $true
        $downloadButton.Enabled = $grid.Rows.Count -gt 0
        $manualInstallButton.Enabled = $script:EntryMap.Count -gt 0
        $scanButton.Enabled = $true
        $musicButton.Enabled = $true
        $importBeatorajaButton.Enabled = $true
        $indexScanButton.Enabled = $true
        $fullIndexScanButton.Enabled = $true
        $cancelButton.Enabled = $false
        $cancelButton.Text = '中止する'
        $script:CancelRequested = $false
        $script:OperationProgressCallback = $null
        $script:CurrentOperationTitle = ''
    }
})

$deletePendingButton.Add_Click({
    try {
        $pendingItems = @(Get-ChildItem -LiteralPath $script:InboxDir -Force -ErrorAction SilentlyContinue)
        $downloadFiles = @(Get-ChildItem -LiteralPath $script:DownloadDir -Recurse -File -Force -ErrorAction SilentlyContinue)
        $downloadBytes = [long](($downloadFiles | Measure-Object Length -Sum).Sum)
        $downloadMb = [math]::Round($downloadBytes / 1MB, 1)
        if ($pendingItems.Count -eq 0 -and $downloadFiles.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show($form, '削除できる配置待ち・ダウンロードキャッシュはありません。', '確認') | Out-Null
            return
        }
        $answer = [System.Windows.Forms.MessageBox]::Show($form, "配置待ちと関連キャッシュをまとめて削除します。`n`n受信箱: $($pendingItems.Count)件`nダウンロード: $($downloadFiles.Count)ファイル（$downloadMb MB）`n`nBMS曲フォルダへ導入済みの曲・差分は削除しません。続けますか？", '削除の確認', 'YesNo', 'Warning')
        if ($answer -ne 'Yes') { return }
        $cleanup = Clear-PendingAndDownloadStorage
        $statusLabel.Text = "配置待ち $($cleanup.InboxItems)件、ダウンロード $($cleanup.DownloadFiles)ファイルを削除しました。"
        [System.Windows.Forms.MessageBox]::Show($form, "$($statusLabel.Text)`n解放: $([math]::Round($cleanup.DownloadBytes / 1MB, 1)) MB`n途中状態: $($cleanup.PartialStates)件を整理", '削除完了') | Out-Null
    } catch {
        [System.Windows.Forms.MessageBox]::Show($form, $_.Exception.Message, '削除エラー', 'OK', 'Error') | Out-Null
    }
})

$downloadButton.Add_Click({
    $targets = @($grid.Rows | Where-Object { $_.Cells['Get'].Value -eq $true -and $_.Cells['State'].Value -ne '所持済み' -and $_.Cells['State'].Value -ne '導入済み' })
    if ($targets.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show($form, '取得する譜面にチェックを入れてください。', '確認') | Out-Null; return }
    $answer = [System.Windows.Forms.MessageBox]::Show($form, "$($targets.Count)件を配布元から取得します。ダウンロードは最大10件ずつ並行し、配置は安全のため1件ずつ行います。既存ファイルは上書きしません。続けますか？", '取得の確認', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { return }
    $done = 0
    $successCount = 0
    $failureCount = 0
    $cancelledCount = 0
    try {
        $script:CurrentMusicPath = $musicBox.Text
        Start-PerformanceTrace '自動ダウンロード・導入'
        $downloadButton.Enabled = $false
        $manualInstallButton.Enabled = $false
        $scanButton.Enabled = $false
        $loadTableButton.Enabled = $false
        $registerTableButton.Enabled = $false
        $removeTableButton.Enabled = $false
        $selectAllButton.Enabled = $false
        $clearAllButton.Enabled = $false
        $retryPendingButton.Enabled = $false
        $deletePendingButton.Enabled = $false
        $playerModeBox.Enabled = $false
        $rootButton.Enabled = $false
        $musicButton.Enabled = $false
        $importBeatorajaButton.Enabled = $false
        $indexScanButton.Enabled = $false
        $fullIndexScanButton.Enabled = $false
        $script:CancelRequested = $false
        $cancelButton.Text = '中止する'
        $cancelButton.Enabled = $true
        $script:OperationProgressCallback = $uiOperationProgress
        $targetArray = @($targets)
        for ($batchOffset = 0; $batchOffset -lt $targetArray.Count; $batchOffset += 10) {
        $batchLast = [Math]::Min($batchOffset + 9, $targetArray.Count - 1)
        $batchRows = @($targetArray[$batchOffset..$batchLast])
        $downloadRequests = New-Object System.Collections.Generic.List[object]
        foreach ($row in $batchRows) {
            Set-RowState $row 'DL待ち' 'この10件を並行してダウンロードします。'
            $mapped = $script:EntryMap[[string]$row.Index]
            $partial = Get-PartialInstall $mapped.Entry
            $preferredProperty = if ($partial -and $partial.PendingFolder) { 'url' } else { '' }
            $overrideProperty = $mapped.PSObject.Properties['DownloadUrlOverride']
            $overrideUrl = if ($overrideProperty) { [string]$overrideProperty.Value } else { '' }
            [void]$downloadRequests.Add([pscustomobject]@{ Key=[string]$row.Index; Entry=$mapped.Entry; DataUrl=$mapped.DataUrl; PreferredProperty=$preferredProperty; OverrideUrl=$overrideUrl })
        }
        $batchFrom = $batchOffset + 1
        $batchTo = $batchLast + 1
        $statusLabel.Text = "ダウンロード中: $batchFrom～$batchTo / $($targetArray.Count)（最大10件並行）"
        Invoke-UiPulse
        $progressAction = {
            param($finishedUrls, $totalUrls, $activeUrls, $receivedBytes)
            $receivedMb = [math]::Round(([double]$receivedBytes / 1MB), 1)
            $statusLabel.Text = "ダウンロード中: 譜面 $batchFrom～$batchTo / $($targetArray.Count)　URL $finishedUrls/$totalUrls　通信中 $activeUrls　受信 $receivedMb MB"
            Set-UiProgress 'ダウンロード中' ($batchOffset + $finishedUrls) $targetArray.Count
        }
        if ($script:CancelRequested) {
            $downloadResults = @{}
        } else {
            $requestArray = [object[]]$downloadRequests.ToArray()
            $downloadResults = Download-EntriesParallel $requestArray 10 $progressAction
        }
        foreach ($row in $batchRows) {
        try {
            $done++
            if ($script:CancelRequested) {
                Set-RowState $row '中止' 'ユーザー操作で中止しました。取得済みファイルは次回再利用します。'
                $cancelledCount++
                continue
            }
            Set-RowState $row '配置中' 'ダウンロード済みファイルを確認し、親曲へ配置しています。'
            $script:CurrentOperationTitle = [string]$row.Cells['Title'].Value
            $statusLabel.Text = "配置中: $done / $($targets.Count)  $($row.Cells['Title'].Value)"
            Set-UiProgress 'ダウンロード済みファイルを配置中' $done $targets.Count
            Invoke-UiPulse
            $mapped = $script:EntryMap[[string]$row.Index]
            $downloadResult = $downloadResults[[string]$row.Index]
            if (-not $downloadResult) { throw 'ダウンロード結果を取得できませんでした。' }
            $downloaded = ''
            $effectiveSourceUrl = if ($downloadResult.PSObject.Properties['Url']) { [string]$downloadResult.Url } else { '' }
            $partialBeforeInstall = Get-PartialInstall $mapped.Entry
            $isBaseCompletion = $partialBeforeInstall -and $partialBeforeInstall.PendingFolder
            if ($isBaseCompletion) {
                if (-not [string]::IsNullOrWhiteSpace([string]$downloadResult.Error)) {
                    Set-RowState $row '元曲取得失敗' ("差分は保存済みですが、元曲を自動取得できませんでした。差分は削除していません。`n" + [string]$downloadResult.Error)
                    $failureCount++
                    continue
                }
                $result = Install-PendingWithBasePackage $mapped.Entry ([string]$downloadResult.Path) ([string]$partialBeforeInstall.PendingFolder) $musicBox.Text
                Set-RowState $row $result.Status $result.Message
                $row.Cells['Get'].Value = $false
                if ($result.Status -eq '導入済み') { Register-EntryInstalled $mapped.Entry; $successCount++ } else { $failureCount++ }
                continue
            }
            if (-not [string]::IsNullOrWhiteSpace([string]$downloadResult.Error)) {
                $differenceDownloadError = [string]$downloadResult.Error
                if (Test-EntryInIndex $mapped.Entry $script:CurrentDatabaseIndex) {
                    Set-RowState $row '所持済み' '通常取得は失敗しましたが、ローカル索引に同じMD5またはSHA-256の譜面が見つかりました。'
                    $row.Cells['Get'].Value = $false
                    $successCount++
                    continue
                }
                $statusLabel.Text = "通常取得失敗／MD5から別の入手先を確認中: $done / $($targets.Count)  $($row.Cells['Title'].Value)"
                Invoke-UiPulse
                $alternative = Download-EntryFromAlternatives $mapped.Entry $mapped.DataUrl 'url_diff'
                if ($alternative) {
                    $downloaded = [string]$alternative.Path
                    $effectiveSourceUrl = [string]$alternative.Url
                    Write-AppLog 'INFO' 'ALTERNATIVE_SOURCE' ("代替取得成功: $($row.Cells['Title'].Value) / $effectiveSourceUrl")
                } else {
                    $statusLabel.Text = "差分取得失敗／元曲を確認中: $done / $($targets.Count)  $($row.Cells['Title'].Value)"
                    Invoke-UiPulse
                    $baseFallback = Install-BaseAfterDifferenceDownloadFailure $mapped.Entry $mapped.DataUrl $musicBox.Text $differenceDownloadError
                    if ($baseFallback) {
                        Set-RowState $row $baseFallback.Status $baseFallback.Message
                        $row.Cells['Get'].Value = $false
                        $failureCount++
                        continue
                    }
                    throw $differenceDownloadError
                }
            } else {
                $downloaded = [string]$downloadResult.Path
            }
            $result = Install-DownloadedEntry $mapped.Entry $downloaded $musicBox.Text $script:CurrentDatabaseIndex
            if ($result.Status -in @('譜面不一致','譜面なし')) {
                $baseFallback = Install-BaseAfterDifferenceDownloadFailure $mapped.Entry $mapped.DataUrl $musicBox.Text ("取得物を確認しましたが対象差分ではありませんでした: " + $result.Status)
                if ($baseFallback) { $result = $baseFallback; $effectiveSourceUrl = '' }
            }
            if ($result.Status -notin @('譜面不一致','譜面なし','展開不可','配布ページ') -and $effectiveSourceUrl) { Register-SuccessfulSourceUrl $mapped.Entry $effectiveSourceUrl }
            $pendingProperty = $result.PSObject.Properties['PendingFolder']
            if ($result.Status -eq '親曲なし' -and $pendingProperty -and $pendingProperty.Value) {
                $baseUrl = Get-EntryDownloadUrl $mapped.Entry 'url'
                $differenceUrl = Get-EntryDownloadUrl $mapped.Entry 'url_diff'
                if ($baseUrl -and $differenceUrl -and $baseUrl -ne $differenceUrl) {
                    $statusLabel.Text = "元曲も取得中: $done / $($targets.Count)  $($row.Cells['Title'].Value)"
                    Invoke-UiPulse
                    $baseDownloaded = ''
                    try {
                        $baseDownloaded = Download-Entry $mapped.Entry $mapped.DataUrl 'url'
                    } catch {
                        $result.Status = '元曲取得失敗'
                        $result.Message += ([Environment]::NewLine + '元曲の取得に失敗しました: ' + $_.Exception.Message)
                        Write-AppLog 'ERROR' 'BASE_DOWNLOAD' ("$($row.Cells['Title'].Value): $($_.Exception.Message)")
                    }
                    if ($baseDownloaded) {
                        try {
                            $result = Install-PendingWithBasePackage $mapped.Entry $baseDownloaded ([string]$pendingProperty.Value) $musicBox.Text
                        } catch {
                            if ($script:CancelRequested -or $_.Exception.Message -match 'ユーザー操作で中止') { throw 'ユーザー操作で中止しました。' }
                            $differenceError = $_.Exception.Message
                            Write-AppLog 'ERROR' 'DIFFERENCE_INSTALL' ("$($row.Cells['Title'].Value): 元曲取得済み / $differenceError")
                            try {
                                $baseOnlyResult = Install-BasePackageOnly $mapped.Entry $baseDownloaded $musicBox.Text
                                $result.Status = $baseOnlyResult.Status
                                $result.Message = $baseOnlyResult.Message + [Environment]::NewLine + '差分の照合または配置には失敗しました: ' + $differenceError
                            } catch {
                                Set-PartialInstall $mapped.Entry -BasePackagePath $baseDownloaded
                                $result.Status = '元曲候補ファイル保存済み／差分未導入'
                                $result.Message += ([Environment]::NewLine + '元曲URLから取得したファイルは親曲として未確認・未配置です。ファイルを保存し、差分と再照合できるようにしました。差分側の失敗: ' + $differenceError + [Environment]::NewLine + '元曲候補の確認結果: ' + $_.Exception.Message)
                            }
                        }
                    }
                } elseif ($differenceUrl -and -not $baseUrl) {
                    $result.Status = '元曲URLなし'
                    $result.Message += ([Environment]::NewLine + '難易度表に元曲の配布URLが登録されていません。')
                }
            }
            Set-RowState $row $result.Status $result.Message
            $row.Cells['Get'].Value = $false
            if ($result.Status -eq '導入済み') { Register-EntryInstalled $mapped.Entry; $successCount++ } else { $failureCount++ }
        } catch {
            if ($_.Exception.Message -match 'ユーザー操作で中止') {
                Set-RowState $row '中止' 'ユーザー操作で中止しました。取得済みファイルは次回再利用します。'
                $cancelledCount++
                continue
            }
            $failureState = Get-FriendlyFailureState $_.Exception.Message
            Set-RowState $row $failureState $_.Exception.Message
            Write-AppLog 'ERROR' 'ENTRY' ("$($row.Cells['Title'].Value): $failureState / $($_.Exception.Message)")
            $failureCount++
        }
        }
        }
        if ($script:CancelRequested) {
            $statusLabel.Text = "取得処理を中止しました: 導入 $successCount / 中止 $cancelledCount / 要確認 $failureCount。取得済みファイルは次回再利用します。"
        } else {
            $statusLabel.Text = "取得処理完了: 導入 $successCount / 要確認 $failureCount。詳細は状態欄またはログを確認してください。"
            [System.Windows.Forms.MessageBox]::Show($form, "処理が完了しました。`n導入: $successCount`n要確認: $failureCount`n`n状態欄またはログで原因を確認できます。自動導入できない行は「ページを開く」を使用してください。", '完了') | Out-Null
        }
    } catch {
        $message = $_.Exception.Message
        Write-AppLog 'ERROR' 'DOWNLOAD_HANDLER' $message
        if ($script:CancelRequested -or $message -match 'ユーザー操作で中止') {
            $statusLabel.Text = "取得処理を中止しました: 導入 $successCount / 中止 $cancelledCount / 要確認 $failureCount。取得済みファイルは次回再利用します。"
        } else {
            $statusLabel.Text = "取得処理を停止しました: $message"
            [System.Windows.Forms.MessageBox]::Show($form, $message, '取得処理エラー', 'OK', 'Error') | Out-Null
        }
    } finally {
        Complete-PerformanceTrace
        $downloadButton.Enabled = $grid.Rows.Count -gt 0
        $manualInstallButton.Enabled = $script:EntryMap.Count -gt 0
        $scanButton.Enabled = $true
        $loadTableButton.Enabled = $true
        $registerTableButton.Enabled = $true
        $removeTableButton.Enabled = $true
        $selectAllButton.Enabled = $true
        $clearAllButton.Enabled = $true
        $retryPendingButton.Enabled = $true
        $deletePendingButton.Enabled = $true
        $playerModeBox.Enabled = $true
        Update-PlayerModeUi
        $musicButton.Enabled = $true
        $importBeatorajaButton.Enabled = $true
        $indexScanButton.Enabled = $true
        $fullIndexScanButton.Enabled = $true
        $cancelButton.Enabled = $false
        $cancelButton.Text = '中止する'
        $script:OperationProgressCallback = $null
        $script:CurrentOperationTitle = ''
        $script:CancelRequested = $false
    }
})

$inboxButton.Add_Click({ Start-Process explorer.exe -ArgumentList ('"' + $script:InboxDir + '"') })
$form.Add_FormClosing({
    param($sender, $eventArgs)
    $script:Settings.BeatorajaPath = $rootBox.Text
    $script:Settings.MusicPath = $musicBox.Text
    $closingRoots = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($musicBox.Text)) { [void]$closingRoots.Add($musicBox.Text) }
    foreach ($path in @($script:Settings.MusicPaths)) { if ($path -and -not @($closingRoots | Where-Object { $_ -eq $path }).Count) { [void]$closingRoots.Add([string]$path) } }
    $script:Settings.MusicPaths = [string[]]$closingRoots.ToArray()
    $script:Settings.PlayerMode = $(if ($playerModeBox.SelectedIndex -eq 0) { 'beatoraja' } else { 'folder' })
    $closingTableUrl = Get-SelectedTableUrl
    if (-not [string]::IsNullOrWhiteSpace($closingTableUrl)) { $script:Settings.Tables = @($closingTableUrl) }
    $script:Settings.SelectedLevels = @(Get-SelectedLevels)
    Save-Settings $script:Settings
    if ($script:SessionIndexDirty -and -not $UiSmokeTest) {
        $folderCount = $script:SessionIndexedFolders.Count
        $choice = [System.Windows.Forms.MessageBox]::Show(
            $form,
            "今回の操作で追加・更新した曲フォルダが $folderCount 件あります。`n次回起動後も親曲検索に使えるよう、終了前に索引を更新しますか？`n`n「はい」: 索引を更新して終了`n「いいえ」: 今回は更新せず終了`n「キャンセル」: 終了を取り消す`n`n大規模ライブラリでは数十秒ほどかかる場合があります。",
            '今回の追加内容を索引へ保存',
            'YesNoCancel',
            'Question'
        )
        if ($choice -eq 'Cancel') { $eventArgs.Cancel = $true; return }
        if ($choice -eq 'Yes') {
            try {
                $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
                $statusLabel.Text = '終了前に今回の追加内容を索引へ保存しています…'
                Start-PerformanceTrace '終了前のBMSライブラリ変更スキャン'
                $progress = {
                    param($stage, $current, $total)
                    $statusLabel.Text = if ($total -gt 0) { "終了前の索引保存: $stage $current / $total" } else { "終了前の索引保存: $stage $current ファイル確認" }
                    Set-UiProgress $stage $current $total
                }
                $roots = @(Get-RegisteredMusicPaths)
                $script:CurrentDatabaseIndex = Update-LibraryIndex $roots $progress
                Write-AppLog 'INFO' 'INDEX_EXIT_SAVE' ("終了前の索引保存完了: $folderCount フォルダ")
            } catch {
                Write-AppLog 'ERROR' 'INDEX_EXIT_SAVE' $_.Exception.Message
                $leaveAnyway = [System.Windows.Forms.MessageBox]::Show($form, "索引へ保存できませんでした。`n$($_.Exception.Message)`n`n保存せず終了しますか？", '索引保存エラー', 'YesNo', 'Error')
                if ($leaveAnyway -ne 'Yes') { $eventArgs.Cancel = $true }
            } finally {
                Complete-PerformanceTrace
                Reset-UiProgress '待機中'
                $form.Cursor = [System.Windows.Forms.Cursors]::Default
            }
        }
    }
})

if ($UiSmokeTest) {
    if ([string]::IsNullOrWhiteSpace($UiTestBeatorajaPath) -or [string]::IsNullOrWhiteSpace($UiTestMusicPath)) {
        throw 'UIテストにはbeatorajaとBMS曲フォルダのパスが必要です。'
    }
    [void]$form.Show()
    Invoke-UiPulse
    if ($playerModeBox.Items.Count -ne 2 -or $playerModeBox.SelectedIndex -ne 0) { throw '所持譜面の確認方法を選択できません。' }
    $rootBox.Text = $UiTestBeatorajaPath
    $musicBox.Text = $UiTestMusicPath
    $tableBox.SelectedIndex = 1
    [void](Load-SelectedTable)
    if ($script:DefaultTables.Count -lt 13 -or $tableBox.Items.Count -lt 13) { throw 'デフォルト難易度表が不足しています。' }
    if ($registerTableButton.Text -ne '表を登録' -or $removeTableButton.Text -ne '登録削除') { throw '難易度表の登録・削除ボタンを判読できません。' }
    if ($importBeatorajaButton.Text -ne 'beatorajaから読込' -or $indexScanButton.Text -ne '索引を更新' -or $fullIndexScanButton.Text -ne '索引を再作成') { throw 'beatoraja取込または索引更新ボタンを判読できません。' }
    if ([System.Windows.Forms.TextRenderer]::MeasureText($indexScanButton.Text, $indexScanButton.Font).Width -gt ($indexScanButton.ClientSize.Width - 8) -or [System.Windows.Forms.TextRenderer]::MeasureText($fullIndexScanButton.Text, $fullIndexScanButton.Font).Width -gt ($fullIndexScanButton.ClientSize.Width - 8)) { throw '索引更新ボタンの文字が表示領域に収まりません。' }
    if ($downloadButton.Text -ne '未所持をまとめて取得') { throw '未所持取得ボタンを判読できません。' }
    $savedCustomCount = @($script:Settings.CustomTables).Count
    $displayedCustomCount = @($tableBox.Items | Where-Object { $_.PSObject.Properties['IsCustom'] -and [bool]$_.IsCustom }).Count
    if ($displayedCustomCount -ne $savedCustomCount) { throw '手動登録した難易度表を一覧へ復元できませんでした。' }
    $customsBeforeNameTest = @($script:Settings.CustomTables)
    $temporaryTableUrl = 'https://example.invalid/tables/automatic-name/'
    if (-not (Add-TableUrlToSettings $temporaryTableUrl)) { throw '難易度表名テスト用の表を追加できません。' }
    if (-not (Update-CustomTableDisplayName $temporaryTableUrl '自動取得した難易度表名')) { throw '読み込み済み難易度表の名前を更新できません。' }
    $temporaryTableIndex = -1
    for ($index = 0; $index -lt $tableBox.Items.Count; $index++) { if ([string]$tableBox.Items[$index].Url -eq $temporaryTableUrl) { $temporaryTableIndex = $index; break } }
    if ($temporaryTableIndex -lt 0 -or [string]$tableBox.Items[$temporaryTableIndex].Name -ne '自動取得した難易度表名') { throw '難易度表名を一覧に反映できません。' }
    $tableBox.Items.RemoveAt($temporaryTableIndex)
    $script:Settings.CustomTables = $customsBeforeNameTest
    if ($cancelButton.Text -ne '中止する' -or $cancelButton.Enabled) { throw '中止ボタンの初期状態が正しくありません。' }
    if (-not $form.Icon) { throw 'アプリアイコンをウィンドウに設定できません。' }
    if (-not $form.Controls.Contains($progressBar) -or $progressBar.Minimum -ne 0 -or $progressBar.Maximum -ne 100 -or $progressBar.Height -lt 8) { throw '進捗バーが正しく表示されません。' }
    Set-UiProgress 'UI進捗テスト' 1 4
    if ($progressBar.Style -ne 'Continuous' -or $progressBar.Value -ne 25 -or $progressBar.AccessibleDescription -notmatch '1 / 4') { throw '進捗バーの進行率更新テストに失敗しました。' }
    Reset-UiProgress '索引更新後テスト'
    if ($progressBar.Style -ne 'Continuous' -or $progressBar.Value -ne 0 -or $progressBar.AccessibleDescription -ne '索引更新後テスト') { throw '索引更新後に進捗バーを待機状態へ戻せません。' }
    if ($manualInstallButton.Text -ne '手動ファイルを振り分け' -or $manualInstallButton.Width -lt 150) { throw '手動ファイル振り分けボタンを判読できません。' }
    if ($deletePendingButton.Text -ne '配置待ち・キャッシュ削除' -or $deletePendingButton.Width -lt 140) { throw '配置待ち・キャッシュ削除ボタンを判読できません。' }
    if (-not $form.AllowDrop -or -not $dropPanel.AllowDrop -or -not $dropLabel.AllowDrop -or -not $grid.AllowDrop) { throw 'ドラッグ＆ドロップの受付範囲が不足しています。' }
    if ($dropLabel.Text -notmatch 'ドラッグ＆ドロップ') { throw 'ドラッグ＆ドロップの案内が表示されません。' }
    if ($levelList.Items.Count -lt 20) { throw "レベル一覧が不足しています: $($levelList.Items.Count)" }
    if ([string]$levelList.Items[0] -match '^@\{') { throw 'レベル一覧に内部データが表示されています。' }
    if (@($levelList.Items | Where-Object { [string]$_ -match '\d+\s*/\s*\d+' }).Count -gt 0) { throw 'レベル選択欄に所持数が混在しています。' }
    if ($levelRangeButton.Text -ne '範囲を選択' -or $levelRangeButton.Width -lt 85) { throw '範囲選択ボタンを判読できません。' }
    for ($i = 0; $i -lt $levelList.Items.Count; $i++) {
        $display = [string]$levelList.Items[$i]
        $value = [string]$script:LevelValueByDisplay[$display]
        $levelList.SetItemChecked($i, ($value -eq '1' -or $value -eq '2'))
    }
    $scanButton.PerformClick()
    Invoke-UiPulse
    if ($grid.Rows.Count -eq 0) { throw '選択レベルの検索結果が表示されませんでした。' }
    $dropData = New-Object System.Windows.Forms.DataObject
    $dropData.SetData([System.Windows.Forms.DataFormats]::FileDrop, [string[]]@((Join-Path $script:AppDir 'sample.zip')))
    $dropArgs = New-Object System.Windows.Forms.DragEventArgs($dropData, 0, 0, 0, [System.Windows.Forms.DragDropEffects]::Copy, [System.Windows.Forms.DragDropEffects]::None)
    & $manualDragEnter $dropPanel $dropArgs
    if ($dropArgs.Effect -ne [System.Windows.Forms.DragDropEffects]::Copy -or $dropPanel.BackColor.ToArgb() -ne $dropReadyColor.ToArgb()) { throw 'ドラッグ中の受付表示を切り替えられませんでした。' }
    & $manualDragLeave
    $unexpected = @($grid.Rows | Where-Object { $_.Cells['Level'].Value -notin @('1','2') })
    if ($unexpected.Count -gt 0) { throw '選択していないレベルが検索結果へ混入しました。' }
    if (-not $grid.Columns['DifferencePage'] -or -not $grid.Columns['SongPage']) { throw '差分ページまたは楽曲ページの列がありません。' }
    $mappedFirst = $script:EntryMap['0']
    $differenceUrl = Get-EntryDifferencePageUrl $mappedFirst.Entry $mappedFirst.DataUrl
    $songUrl = Get-EntrySongPageUrl $mappedFirst.Entry $mappedFirst.DataUrl
    if ($differenceUrl -notmatch '^https?://') { throw '差分ページURLを作成できませんでした。' }
    if ($songUrl -notmatch '^https?://') { throw '楽曲ページURLを作成できませんでした。' }
    if ($script:ManualEntryMap.Count -lt $script:EntryMap.Count) { throw '手動振り分け用の難易度表索引を作成できませんでした。' }
    $firstRow = $grid.Rows[0]
    $originalState = [string]$firstRow.Cells['State'].Value
    Set-RowState $firstRow '楽曲のみ導入済み／差分DL失敗' 'UI確認'
    if ([string]$firstRow.Cells['DifferencePage'].Value -ne '差分を手動DL') { throw '部分失敗時に差分ページを強調できませんでした。' }
    if ($grid.Columns['DifferencePage'].FlatStyle -ne 'Flat' -or $grid.Columns['SongPage'].FlatStyle -ne 'Flat') { throw '誘導ボタンの背景を全面表示できません。' }
    if ($firstRow.Cells['DifferencePage'].Style.BackColor.ToArgb() -ne $firstRow.Cells['DifferencePage'].Style.SelectionBackColor.ToArgb()) { throw '行選択時に差分ページの誘導色を維持できません。' }
    if ($manualInstallButton.BackColor.ToArgb() -eq [System.Drawing.SystemColors]::Control.ToArgb()) { throw '部分失敗時に手動振り分けを強調できませんでした。' }
    Set-RowState $firstRow $originalState 'UI確認後に状態を復元'
    $verifiedRowCount = $grid.Rows.Count
    $verifiedStatus = $statusLabel.Text
    $playerModeBox.SelectedIndex = 1
    Invoke-UiPulse
    if ($rootBox.Enabled -or $rootButton.Enabled -or -not $musicBox.Enabled -or $statusLabel.Text -notmatch 'LR2') { throw 'LR2・その他モードへ切り替えられませんでした。' }
    $playerModeBox.SelectedIndex = 0
    Invoke-UiPulse
    if (-not $rootBox.Enabled -or -not $rootButton.Enabled) { throw 'beatorajaモードへ戻せませんでした。' }
    $form.Close()
    $reloadedSettings = Load-Settings
    $savedLevels = @($reloadedSettings.SelectedLevels | Sort-Object)
    if (($savedLevels -join ',') -ne '1,2') { throw 'レベル選択設定を再読み込みできませんでした。' }
    if (@($reloadedSettings.MusicPaths).Count -lt 1) { throw '複数BMSフォルダ設定を保存できませんでした。' }
    [pscustomobject]@{
        Result = 'UI SMOKE TEST OK'
        Table = $script:CurrentTable.Name
        LevelCount = $levelList.Items.Count
        LevelDisplay = [string]$levelList.Items[0]
        SelectedLevels = $savedLevels -join ', '
        ResultRows = $verifiedRowCount
        RangeButton = $levelRangeButton.Text
        CancelButton = '中止する（処理中のみ有効）'
        ManualInstallButton = $manualInstallButton.Text
        LibraryButtons = "$($indexScanButton.Text) / $($fullIndexScanButton.Text)"
        DownloadButton = $downloadButton.Text
        PlayerModes = $playerModeBox.Items.Count
        DefaultTableCount = $script:DefaultTables.Count
        CustomTableCount = $displayedCustomCount
        TableRegisterButtons = $registerTableButton.Text + ' / ' + $removeTableButton.Text
        DifferenceUrl = $differenceUrl
        SongUrl = $songUrl
        Status = $verifiedStatus
    } | Format-List
    Clear-ExtractedPackageCache
    exit 0
}

[void]$form.ShowDialog()
Clear-ExtractedPackageCache
